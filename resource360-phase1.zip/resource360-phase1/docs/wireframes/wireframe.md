# Wireframe — Resource 360
## TEG AI Adoption Pilot | Phase 1 Deliverable 02

> This document is the **visual contract** between design and development.
> Every screen listed here is IN SCOPE. No screen not listed here should be built in Phase 2.
> The interactive HTML prototype is in `docs/wireframes/resource360-wireframe.html`.

---

## Screen Inventory

| ID | Screen Name | Role | Route |
|---|---|---|---|
| S01 | Login | All | `/login` |
| S02 | Operations Dashboard | RM, OM | `/dashboard` |
| S03 | Bench View | RM, OM | `/bench` |
| S04 | Roll-off Tracker | RM, OM | `/rolloffs` |
| S05 | Employee Profile — 360° View | RM (edit), OM/SO (read) | `/employees/:id` |
| S06 | Demand Request — Form | SO | `/demand/new` |
| S07 | Demand Request — My Requests | SO | `/demand/mine` |
| S08 | AI Candidate Suggestions | RM | `/demand/:id/suggestions` |
| S09 | Skill Matrix | RM, OM | `/skills/matrix` |
| S10 | Settings | RM, OM | `/settings` |

---

## Screen Descriptions

### S01 — Login
- Email + password form
- Role is embedded in JWT — no role selector visible to user
- Redirect to Dashboard on success
- Error state: invalid credentials

### S02 — Operations Dashboard
**Visible to:** Resource Manager, Operations Manager

**Top row — 4 metric cards:**
- On bench (count + weekly delta)
- Rolling off in 30 days (count + unconfirmed count)
- Over-allocated (count + action required indicator)
- Open demand requests (count + urgent count)

**Left column:**
- Over-allocation alerts list (employee name, total %, affected projects)
- Bench trend mini bar chart (last 8 weeks)
- Skill availability horizontal bar chart (top 6 skills by bench count)

**Right column:**
- Open demand request cards (role, project, skills tags, priority badge)
- Upcoming roll-offs (7-day view, days-remaining pill, criticality badge)

### S03 — Bench View
**Visible to:** Resource Manager, Operations Manager

- Search bar (name or skill)
- Filters: Grade, Status (Available / Rolling off)
- Data table: Employee name + email | Grade | Skills (tag chips) | Bench since | Location | Status badge | View button
- "Raise demand" button (RM only)

### S04 — Roll-off Tracker
**Visible to:** Resource Manager, Operations Manager

- Three tabs: Next 30 days / 31–60 days / 61–90 days
- Each row: Avatar | Employee name + project | End date | Days remaining pill (colour-coded) | Criticality badge | "Find replacement" button → navigates to AI Suggestions

### S05 — Employee Profile (360° View)
**Visible to:** All roles (SO gets limited fields)

**Left column:**
- Large avatar + name + grade + department
- Status badge (bench status)
- Field grid: Department, Location, Allocation %, Bench status, Roll-off date, Joined date
- Skills panel with tag chips (+ Add skill button — RM only)
- Certifications list (name, expiry, status badge)

**Right column:**
- Current allocations list (project name, dates, allocation % with visual bar)
- Over-allocation warning banner (if total > 100%)
- Project history list (past projects with completion badge)
- Action buttons: Update allocation (RM only), Export profile

### S06 — Demand Request Form
**Visible to:** Solution Owner only

- Form fields: Project name, Required role, Start date, Duration (dropdown), Allocation % (dropdown), Grade (dropdown), Priority (dropdown), Required skills (tag input), Notes (textarea)
- Submit and Save draft buttons
- Demand workflow steps panel (visual 4-step guide)

### S07 — Demand Request Status
**Visible to:** Solution Owner (own requests only)

- List of own demand request cards
- Status badge per request: OPEN / PENDING / FULFILLED / DECLINED
- Fulfilled requests show which employee was assigned
- Declined requests show decline reason

### S08 — AI Candidate Suggestions
**Visible to:** Resource Manager only

- Demand summary card at top (role, project, skills, priority)
- Left: AI-ranked candidate list with score bar (click to select)
- Left: Skill gap analysis (required skill vs available count)
- Right: Readiness summary panel for selected candidate (AI text + info table)
- Confirm Allocation button → opens confirmation modal
- Dismiss button

### S09 — Skill Matrix
**Visible to:** Resource Manager, Operations Manager

- Cross-employee vs skill grid
- Cells: Expert (dark fill) / Proficient (mid fill) / Beginner (light fill) / None (empty)
- Legend below grid
- Filter by department

### S10 — Settings
**Visible to:** Resource Manager, Operations Manager

- My profile form (name, email, role selector for demo purposes)
- Notification preferences toggles
- System info (version, environment, employee count)

---

## Navigation Structure

```
Sidebar (always visible after login):
  Overview
    ├── Dashboard         (S02) — RM, OM
    ├── Bench view        (S03) — RM, OM
    └── Roll-off tracker  (S04) — RM, OM
  Resources
    ├── Employee profile  (S05) — All
    ├── Demand request    (S06/S07) — SO
    └── AI suggestions    (S08) — RM
  Admin
    ├── Skill matrix      (S09) — RM, OM
    └── Settings          (S10) — RM, OM
```

---

## UI Component Standards

| Component | Standard |
|---|---|
| Primary button | Purple (#5b4fcf), white text, 8px radius |
| Ghost button | Transparent, border, secondary text |
| Status badge | Colour-coded pill: green=success, amber=warn, red=danger, blue=info, grey=muted |
| Metric card | Secondary background, muted label, large number, delta sub-text |
| Data table | 0.5px border, alternating hover, sticky header |
| Allocation bar | 6px height, green < 80%, amber 80–99%, red ≥ 100% |
| Avatar | Circle, initials, colour-coded by role |

---

*Document owner: Architect | Status: APPROVED — this is the design contract for Phase 2*
