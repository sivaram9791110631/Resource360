# TDD: Employee Profile Management
## Resource 360 — Technical Design Document
## TEG AI Adoption Pilot | Phase 1 Implementation

---

## 1. Overview

**Feature:** Complete employee profile management with 360° view  
**Scope:** CRUD operations for employees, skills, and certifications  
**Primary Actor:** Resource Manager (RBAC: RESOURCE_MANAGER only for create/edit)  
**Core Components:** Employee data, skills matrix, certifications, allocation history  
**Key Constraint:** Email uniqueness, soft-delete only, no PII in logs  

---

## 2. Sequence Diagram

### GET /employees/{id} — 360° Profile View

```mermaid
sequenceDiagram
    participant User as User (RM/OM/SO)
    participant UI as React EmployeeProfilePage
    participant API as FastAPI /employees/{id}
    participant JWT as JWT Middleware
    participant DB as SQLite Database

    User->>UI: Navigate to employee profile
    UI->>API: GET /employees/{id}
    
    API->>JWT: Validate JWT token
    JWT->>JWT: Extract role claim
    
    alt Invalid token
        JWT-->>API: 401 Unauthorized
        API-->>UI: Error response
        UI-->>User: Show login prompt
    else Valid token
        JWT->>API: Proceed with authorized user
        
        API->>DB: SELECT employee + JOIN skills + JOIN certifications + JOIN allocations
        Note right of DB: Complex query with multiple JOINs<br/>to build complete 360° view
        
        alt Employee not found or is_deleted=1
            DB-->>API: No results
            API-->>UI: 404 Not Found
            UI-->>User: Show not found message
        else Employee exists
            DB-->>API: Employee object with relations
            Note right of API: {employee: {...}, skills: [...], certifications: [...],<br/>allocations: [...], allocation_history: [...]}
            
            API->>API: Apply role-based field filtering
            Note right of API: Solution Owner gets limited fields<br/>RM/OM get full profile
            
            API->>DB: SELECT project history (completed allocations)
            DB-->>API: Historical allocation data
            
            API->>API: Calculate derived fields
            Note right of API: current_allocation_pct, bench_since_date,<br/>certification statuses (Active/Expiring/Expired)
            
            API-->>UI: 200 {complete employee profile}
            UI->>UI: Render 360° view
            UI-->>User: Display profile with all sections
        end
    end
```

---

## 3. API Specifications

### POST /employees

**Request Schema:**
```json
{
  "name": "Sneha Krishnan",
  "email": "sneha.k@teg.com",
  "grade": "Senior",
  "department": "Engineering", 
  "location": "Hyderabad"
}
```

**Success Response (201):**
```json
{
  "id": 42,
  "name": "Sneha Krishnan",
  "email": "sneha.k@teg.com",
  "grade": "Senior",
  "department": "Engineering",
  "location": "Hyderabad",
  "bench_status": "BENCH",
  "is_deleted": false,
  "created_at": "2026-05-22T10:30:00Z"
}
```

### GET /employees/{id}

**Success Response (200):**
```json
{
  "id": 42,
  "name": "Sneha Krishnan",
  "email": "sneha.k@teg.com",
  "grade": "Senior", 
  "department": "Engineering",
  "location": "Hyderabad",
  "bench_status": "ALLOCATED",
  "current_allocation_pct": 80,
  "bench_since": null,
  "is_deleted": false,
  "created_at": "2026-05-22T10:30:00Z",
  "skills": [
    {
      "id": 15,
      "skill_name": "React",
      "proficiency": "Expert"
    },
    {
      "id": 16, 
      "skill_name": "TypeScript",
      "proficiency": "Proficient"
    }
  ],
  "certifications": [
    {
      "id": 8,
      "cert_name": "AWS Solutions Architect",
      "expires_on": "2026-12-31",
      "status": "Active",
      "days_until_expiry": 223
    }
  ],
  "allocations": [
    {
      "id": 23,
      "project_id": 10,
      "project_name": "Customer Portal Rebuild",
      "project_role": "Senior Developer",
      "allocation_pct": 80,
      "start_date": "2026-05-01",
      "end_date": "2026-08-31",
      "is_active": true
    }
  ],
  "allocation_history": [
    {
      "project_name": "Legacy System Migration",
      "project_role": "Tech Lead",
      "allocation_pct": 100,
      "start_date": "2026-01-15",
      "end_date": "2026-04-30",
      "duration_days": 105
    }
  ]
}
```

### PATCH /employees/{id}

**Request Schema (partial updates):**
```json
{
  "grade": "Principal",
  "location": "Remote",
  "bench_status": "ROLLING_OFF"
}
```

**Success Response (200):**
```json
{
  "id": 42,
  "name": "Sneha Krishnan",
  "grade": "Principal",
  "location": "Remote", 
  "bench_status": "ROLLING_OFF"
}
```

### POST /employees/{id}/skills

**Request Schema:**
```json
{
  "skill_name": "React",
  "proficiency": "Expert"
}
```

**Success Response (201):**
```json
{
  "id": 15,
  "employee_id": 42,
  "skill_name": "React", 
  "proficiency": "Expert",
  "created_at": "2026-05-22T10:30:00Z"
}
```

### POST /employees/{id}/certifications

**Request Schema:**
```json
{
  "cert_name": "AWS Solutions Architect",
  "expires_on": "2026-12-31",
  "status": "Active"
}
```

**Success Response (201):**
```json
{
  "id": 8,
  "employee_id": 42,
  "cert_name": "AWS Solutions Architect",
  "expires_on": "2026-12-31", 
  "status": "Active",
  "created_at": "2026-05-22T10:30:00Z"
}
```

---

## 4. RBAC Matrix

| Action | Resource Manager | Operations Manager | Solution Owner |
|---|---|---|---|
| POST /employees | ✅ | ❌ (403) | ❌ (403) |
| GET /employees/{id} | ✅ (full profile) | ✅ (full profile) | ✅ (limited fields) |
| PATCH /employees/{id} | ✅ | ❌ (403) | ❌ (403) |
| DELETE /employees/{id} | ✅ | ❌ (403) | ❌ (403) |
| POST /employees/{id}/skills | ✅ | ❌ (403) | ❌ (403) |
| DELETE /employees/{id}/skills/{skill_id} | ✅ | ❌ (403) | ❌ (403) |
| POST /employees/{id}/certifications | ✅ | ❌ (403) | ❌ (403) |

**Field Restrictions for Solution Owner:**
- ✅ Allowed: name, grade, department, location, skills, certifications (cert names only)
- ❌ Hidden: email, bench_status, allocation details, allocation history, PII fields

**Enforcement Point:** `middleware/auth.py` + response field filtering in routers

---

## 5. Database Operations

### 5.1 Employee 360° Profile Query (Complete JOIN)

```sql
-- Main employee data with all related entities
SELECT 
    e.id, e.name, e.email, e.grade, e.department, e.location,
    e.bench_status, e.is_deleted, e.created_at,
    
    -- Skills
    s.id as skill_id, s.skill_name, s.proficiency,
    
    -- Certifications with calculated status
    c.id as cert_id, c.cert_name, c.expires_on, c.status,
    CASE 
        WHEN c.expires_on IS NULL THEN NULL
        WHEN c.expires_on <= CURRENT_DATE THEN 'Expired'
        WHEN c.expires_on <= DATE(CURRENT_DATE, '+30 days') THEN 'Expiring'
        ELSE 'Active'
    END as calculated_status,
    
    -- Active allocations
    a.id as allocation_id, a.project_id, a.project_role,
    a.allocation_pct, a.start_date, a.end_date, a.is_active,
    p.name as project_name,
    
    -- Calculate current total allocation
    (SELECT COALESCE(SUM(a2.allocation_pct), 0) 
     FROM allocations a2 
     WHERE a2.employee_id = e.id 
       AND a2.is_active = 1
       AND (a2.end_date IS NULL OR a2.end_date >= CURRENT_DATE)
    ) as current_allocation_pct

FROM employees e
LEFT JOIN skills s ON e.id = s.employee_id
LEFT JOIN certifications c ON e.id = c.employee_id  
LEFT JOIN allocations a ON e.id = a.employee_id AND a.is_active = 1
LEFT JOIN projects p ON a.project_id = p.id

WHERE e.id = ? AND e.is_deleted = 0;
```

### 5.2 Employee Creation

```sql
-- Insert new employee with default bench status
INSERT INTO employees (
    name, 
    email, 
    grade, 
    department, 
    location, 
    bench_status,
    is_deleted,
    created_at
) VALUES (?, ?, ?, ?, ?, 'BENCH', 0, CURRENT_TIMESTAMP);
```

### 5.3 Employee Update (Partial PATCH)

```sql
-- Update only provided fields (dynamic query construction)
UPDATE employees 
SET grade = COALESCE(?, grade),
    department = COALESCE(?, department),
    location = COALESCE(?, location),
    bench_status = COALESCE(?, bench_status)
WHERE id = ? AND is_deleted = 0;
```

### 5.4 Employee Soft Delete

```sql
-- Soft delete - never hard delete employee records
UPDATE employees 
SET is_deleted = 1, 
    email = CONCAT(email, '_deleted_', DATETIME('now'))
WHERE id = ?;

-- Check for active allocations before soft delete
SELECT COUNT(*) as active_allocations
FROM allocations 
WHERE employee_id = ? 
  AND is_active = 1 
  AND (end_date IS NULL OR end_date >= CURRENT_DATE);
```

### 5.5 Skills Management

```sql
-- Add skill to employee
INSERT INTO skills (
    employee_id,
    skill_name, 
    proficiency,
    created_at
) VALUES (?, ?, ?, CURRENT_TIMESTAMP);

-- Remove skill from employee  
DELETE FROM skills 
WHERE id = ? AND employee_id = ?;

-- Check skill uniqueness per employee
SELECT COUNT(*) FROM skills 
WHERE employee_id = ? AND skill_name = ?;
```

### 5.6 Certifications Management

```sql
-- Add certification to employee
INSERT INTO certifications (
    employee_id,
    cert_name,
    expires_on,
    status,
    created_at
) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP);

-- Update certification status based on expiry (batch job)
UPDATE certifications 
SET status = CASE 
    WHEN expires_on <= CURRENT_DATE THEN 'Expired'
    WHEN expires_on <= DATE(CURRENT_DATE, '+30 days') THEN 'Expiring'
    ELSE 'Active'
END
WHERE expires_on IS NOT NULL;
```

### 5.7 Employee Listing with Filters

```sql
-- Employee list with optional filters for dashboard
SELECT 
    e.id, e.name, e.email, e.grade, e.department, e.location,
    e.bench_status,
    COUNT(DISTINCT s.id) as skills_count,
    COUNT(DISTINCT CASE WHEN a.is_active = 1 THEN a.id END) as active_allocations_count,
    COALESCE(SUM(CASE WHEN a.is_active = 1 THEN a.allocation_pct ELSE 0 END), 0) as current_allocation_pct
FROM employees e
LEFT JOIN skills s ON e.id = s.employee_id
LEFT JOIN allocations a ON e.id = a.employee_id
WHERE e.is_deleted = 0
  AND (?1 IS NULL OR e.bench_status = ?1)  -- Optional bench_status filter
  AND (?2 IS NULL OR e.grade = ?2)         -- Optional grade filter
  AND (?3 IS NULL OR e.department = ?3)    -- Optional department filter
GROUP BY e.id, e.name, e.email, e.grade, e.department, e.location, e.bench_status
ORDER BY e.name;
```

---

## 6. Validation Rules

| Rule | Implementation | Error Response |
|---|---|---|
| name: required, non-empty | Pydantic schema validation | 422 + field validation error |
| email: required, unique, valid format | Pydantic + DB constraint | 422 + "DUPLICATE_EMAIL" |
| grade: required, non-empty | Pydantic schema validation | 422 + field validation error |
| department: required, non-empty | Pydantic schema validation | 422 + field validation error |
| location: required, non-empty | Pydantic schema validation | 422 + field validation error |
| bench_status: valid enum | Pydantic enum validation | 422 + "Invalid bench status" |
| skill_name: unique per employee | DB constraint + business logic | 422 + "DUPLICATE_SKILL" |
| proficiency: valid enum | Pydantic enum validation | 422 + "Invalid proficiency level" |
| cert_name: non-empty | Pydantic schema validation | 422 + field validation error |
| expires_on: valid date format | Pydantic schema validation | 422 + field validation error |

---

## 7. Error Handling

### 7.1 Application-Level Exception Classes

```python
class EmployeeError(Exception):
    """Employee-specific business logic errors"""
    pass

class DuplicateEmailError(EmployeeError):
    def __init__(self, email: str):
        self.email = email
        super().__init__(f"Employee with email {email} already exists")

class DuplicateSkillError(EmployeeError):
    def __init__(self, employee_id: int, skill_name: str):
        self.employee_id = employee_id
        self.skill_name = skill_name
        super().__init__(f"Employee {employee_id} already has skill {skill_name}")

class EmployeeHasActiveAllocationsError(EmployeeError):
    def __init__(self, employee_id: int, allocation_count: int):
        self.employee_id = employee_id
        self.allocation_count = allocation_count
        super().__init__(f"Cannot delete employee {employee_id}: has {allocation_count} active allocations")

class EmployeeNotFoundError(EmployeeError):
    def __init__(self, employee_id: int):
        super().__init__(f"Employee {employee_id} not found or has been deleted")
```

### 7.2 HTTP Error Responses

| Error Scenario | HTTP Code | Error Code | Description |
|---|---|---|---|
| **Duplicate email on CREATE** | 422 | DUPLICATE_EMAIL | Email address already exists |
| **Employee not found** | 404 | EMPLOYEE_NOT_FOUND | Employee does not exist or is deleted |
| **Duplicate skill for employee** | 422 | DUPLICATE_SKILL | Skill already exists for this employee |
| **Invalid proficiency level** | 422 | VALIDATION_ERROR | Proficiency must be Beginner/Proficient/Expert |
| **Soft delete with active allocations** | 409 | HAS_ACTIVE_ALLOCATIONS | Cannot delete employee with active projects |
| **RBAC violation** | 403 | FORBIDDEN | Insufficient permissions for this action |
| **Missing required field** | 422 | VALIDATION_ERROR | Required field is missing or invalid |

### 7.3 Error Response Examples

```json
// 422 Duplicate Email
{
  "error": "Employee with email sneha.k@teg.com already exists",
  "code": "DUPLICATE_EMAIL",
  "field": "email",
  "details": {
    "existing_employee_id": 15,
    "conflicting_email": "sneha.k@teg.com"
  }
}

// 409 Active Allocations
{
  "error": "Cannot delete employee: has 2 active project allocations",
  "code": "HAS_ACTIVE_ALLOCATIONS", 
  "field": null,
  "details": {
    "employee_id": 42,
    "active_allocation_count": 2,
    "suggestion": "End active allocations before deleting employee"
  }
}

// 403 RBAC Violation
{
  "error": "Only Resource Managers can create employee profiles",
  "code": "FORBIDDEN",
  "field": null,
  "details": {
    "required_role": "RESOURCE_MANAGER",
    "user_role": "SOLUTION_OWNER"
  }
}
```

---

## 8. React Frontend Integration

### 8.1 EmployeeProfilePage Component

```typescript
interface Employee {
  id: number;
  name: string;
  email: string;
  grade: string;
  department: string;
  location: string;
  bench_status: 'ALLOCATED' | 'BENCH' | 'ROLLING_OFF' | 'ON_LEAVE';
  current_allocation_pct: number;
  bench_since?: string;
  skills: Skill[];
  certifications: Certification[];
  allocations: Allocation[];
  allocation_history: AllocationHistory[];
}

interface Skill {
  id: number;
  skill_name: string;
  proficiency: 'Beginner' | 'Proficient' | 'Expert';
}

interface Certification {
  id: number;
  cert_name: string;
  expires_on?: string;
  status: 'Active' | 'Expiring' | 'Expired';
  days_until_expiry?: number;
}
```

### 8.2 React Query Hooks

```typescript
// Fetch employee profile
const useEmployeeProfile = (employeeId: number) => {
  return useQuery({
    queryKey: ['employees', employeeId],
    queryFn: () => api.get(`/employees/${employeeId}`),
    staleTime: 2 * 60 * 1000, // 2 minutes
    refetchOnWindowFocus: false
  });
};

// Create employee
const useCreateEmployee = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: (data: CreateEmployeeRequest) =>
      api.post('/employees', data),
    onSuccess: () => {
      queryClient.invalidateQueries(['employees']);
      queryClient.invalidateQueries(['dashboard', 'metrics']);
    },
    onError: (error: ApiError) => {
      if (error.code === 'DUPLICATE_EMAIL') {
        setFieldError('email', 'This email address is already in use');
      }
    }
  });
};

// Add skill to employee
const useAddSkill = (employeeId: number) => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: (skill: AddSkillRequest) =>
      api.post(`/employees/${employeeId}/skills`, skill),
    onSuccess: () => {
      queryClient.invalidateQueries(['employees', employeeId]);
    },
    onError: (error: ApiError) => {
      if (error.code === 'DUPLICATE_SKILL') {
        showToast('Employee already has this skill', 'warning');
      }
    }
  });
};
```

### 8.3 Role-Based Field Filtering

```typescript
const EmployeeProfile: React.FC<{employee: Employee}> = ({employee}) => {
  const { user } = useAuth();
  
  // Solution Owner gets limited view
  const showSensitiveFields = user.role !== 'SOLUTION_OWNER';
  
  return (
    <div className="employee-profile">
      <div className="basic-info">
        <h2>{employee.name}</h2>
        <p>{employee.grade} • {employee.department}</p>
        <p>{employee.location}</p>
      </div>
      
      {showSensitiveFields && (
        <div className="sensitive-info">
          <p>Email: {employee.email}</p>
          <p>Status: {employee.bench_status}</p>
          <p>Current Allocation: {employee.current_allocation_pct}%</p>
        </div>
      )}
      
      <SkillsSection skills={employee.skills} />
      <CertificationsSection certifications={employee.certifications} />
      
      {showSensitiveFields && (
        <>
          <AllocationsSection allocations={employee.allocations} />
          <AllocationHistorySection history={employee.allocation_history} />
        </>
      )}
    </div>
  );
};
```

---

## 9. Edge Cases

### 9.1 Email and Data Integrity Edge Cases

| Test Case | Input | Expected Result | Status Code |
|---|---|---|---|
| **Duplicate email on CREATE** | email: "existing@teg.com" | ❌ Block with error | 422 DUPLICATE_EMAIL |
| **Empty email field** | email: "" | ❌ Block validation | 422 VALIDATION_ERROR |
| **Invalid email format** | email: "invalid-email" | ❌ Block validation | 422 VALIDATION_ERROR |
| **Case-sensitive email check** | existing: "user@TEG.com", new: "user@teg.com" | ❌ Should block (normalize) | 422 DUPLICATE_EMAIL |
| **Email with special characters** | email: "user+test@teg.com" | ✅ Allow if valid format | 201 |

### 9.2 Soft Delete Edge Cases

| Test Case | Employee State | Expected Result | Status Code |
|---|---|---|---|
| **Soft delete with active allocations** | has 2 active allocations | ❓ Block or warn? | 409 HAS_ACTIVE_ALLOCATIONS |
| **Soft delete bench employee** | bench_status = 'BENCH' | ✅ Allow soft delete | 204 |
| **Soft delete already deleted** | is_deleted = 1 | ❌ Return 404 | 404 EMPLOYEE_NOT_FOUND |
| **Re-create with deleted email** | email from soft-deleted employee | ✅ Allow (email suffix added) | 201 |
| **Access deleted employee profile** | GET /employees/{deleted_id} | ❌ Return 404 | 404 EMPLOYEE_NOT_FOUND |

### 9.3 Certification Expiry Edge Cases

| Test Case | Expiry Date | Calculated Status | Days Until Expiry |
|---|---|---|---|
| **Active certification** | expires_on: "2027-06-01" | "Active" | 375 |
| **Expiring soon (< 30 days)** | expires_on: "2026-06-15" | "Expiring" | 24 |
| **Expired yesterday** | expires_on: "2026-05-21" | "Expired" | -1 |
| **No expiry date** | expires_on: null | "Active" | null |
| **Expiring exactly in 30 days** | expires_on: "2026-06-21" | "Expiring" | 30 |

**Certification Status Auto-Calculation Logic:**
```python
def calculate_certification_status(expires_on: date | None) -> str:
    if expires_on is None:
        return "Active"
    
    today = date.today()
    days_until_expiry = (expires_on - today).days
    
    if days_until_expiry < 0:
        return "Expired"
    elif days_until_expiry <= 30:
        return "Expiring"
    else:
        return "Active"
```

### 9.4 Employee with Zero Skills Edge Case

| Test Case | Employee State | Expected Result | Notes |
|---|---|---|---|
| **Employee with zero skills** | skills: [] | ✅ Profile renders normally | Shows "No skills added" placeholder |
| **Employee with zero certifications** | certifications: [] | ✅ Profile renders normally | Shows "No certifications" placeholder |
| **Employee with zero allocations** | allocations: [] | ✅ Profile renders normally | Shows bench status prominently |
| **Completely new employee** | all relations empty | ✅ Profile renders with placeholders | Ready for Resource Manager to add data |

### 9.5 Concurrency Edge Cases

| Test Case | Scenario | Expected Result | Mitigation |
|---|---|---|---|
| **Duplicate email race condition** | Two CREATE requests with same email | Only one succeeds | DB UNIQUE constraint |
| **Simultaneous skill addition** | Two requests add same skill | Second request gets 422 DUPLICATE_SKILL | Application-level validation |
| **Employee update during allocation** | PATCH employee while allocation being created | Both succeed independently | No conflict |
| **Soft delete during allocation** | DELETE employee while allocation in progress | Block delete until allocation completes | Check active allocations first |

---

## 10. Performance Considerations

### 10.1 Database Indexes

```sql
-- Critical for employee profile queries
CREATE INDEX idx_employees_email ON employees(email) WHERE is_deleted = 0;
CREATE INDEX idx_employees_is_deleted ON employees(is_deleted);

-- Critical for 360° view performance  
CREATE INDEX idx_skills_employee ON skills(employee_id);
CREATE INDEX idx_certifications_employee ON certifications(employee_id);
CREATE INDEX idx_allocations_employee_active ON allocations(employee_id, is_active);

-- Critical for dashboard and filtering
CREATE INDEX idx_employees_bench_status ON employees(bench_status) WHERE is_deleted = 0;
CREATE INDEX idx_employees_department ON employees(department) WHERE is_deleted = 0;
CREATE INDEX idx_employees_grade ON employees(grade) WHERE is_deleted = 0;
```

### 10.2 Query Optimisation

- **360° Profile:** Single complex query with JOINs vs multiple queries
- **Employee List:** Use aggregation to avoid N+1 queries  
- **Certification Status:** Calculate in SQL vs application logic
- **Field Filtering:** Apply in API layer, not database layer

### 10.3 Caching Strategy

- **Employee Profile:** 2-minute React Query cache (moderate update frequency)
- **Employee List:** 1-minute cache for dashboard view
- **Skills/Certifications:** 5-minute cache (infrequent changes)
- **No server-side caching:** Data changes frequently, avoid stale data

---

## 11. Testing Strategy

### 11.1 Unit Tests (pytest)

```python
# tests/test_employee_service.py
def test_create_employee_success():
    """Test successful employee creation"""

def test_create_employee_duplicate_email():
    """Test duplicate email validation"""

def test_employee_360_profile_query():
    """Test complex JOIN query for profile view"""

def test_soft_delete_employee():
    """Test soft delete functionality"""

def test_certification_status_calculation():
    """Test expiry status auto-calculation"""

def test_skill_uniqueness_per_employee():
    """Test skill duplication prevention"""
```

### 11.2 Integration Tests (pytest + httpx)

```python
# tests/test_employee_api.py
def test_post_employee_success():
    """Test complete employee creation flow"""

def test_get_employee_360_profile():
    """Test 360° profile endpoint with all JOINs"""

def test_employee_rbac_restrictions():
    """Test role-based access control"""

def test_soft_delete_with_active_allocations():
    """Test soft delete validation"""

def test_add_skill_and_certification():
    """Test skill and certification management"""
```

### 11.3 Frontend Tests (Vitest + React Testing Library)

```typescript
// components/EmployeeProfile.test.tsx
describe('EmployeeProfile', () => {
  test('renders full profile for Resource Manager');
  test('hides sensitive fields for Solution Owner');
  test('shows placeholders for empty data');
  test('handles certification expiry status display');
  test('displays over-allocation warning');
});

// components/EmployeeForm.test.tsx
describe('EmployeeForm', () => {
  test('validates required fields');
  test('handles duplicate email error');
  test('submits form successfully');
  test('shows field validation errors');
});
```

---

## 12. Implementation Checklist

### Backend Implementation

- [ ] **models/employee.py** — SQLAlchemy employee, skill, certification models
- [ ] **schemas/employee.py** — Pydantic request/response schemas with validation
- [ ] **routers/employees.py** — FastAPI endpoints with RBAC
- [ ] **routers/skills.py** — Skills management endpoints
- [ ] **services/employee_service.py** — Business logic and complex queries
- [ ] **middleware/auth.py** — Role-based field filtering
- [ ] **tests/test_employees.py** — Complete test suite

### Frontend Implementation  

- [ ] **components/EmployeeProfile.tsx** — 360° profile view component
- [ ] **components/EmployeeForm.tsx** — Create/edit employee form
- [ ] **components/SkillsSection.tsx** — Skills management component
- [ ] **components/CertificationsSection.tsx** — Certifications display/management
- [ ] **api/employees.ts** — React Query hooks
- [ ] **types/employee.ts** — TypeScript interfaces
- [ ] **tests/EmployeeProfile.test.tsx** — Component tests

### Database & Business Logic

- [ ] **schema.sql** — Employee, skills, certifications tables with constraints
- [ ] **seed/employee_seed.py** — Comprehensive test employee data
- [ ] **Database indexes** — Performance optimisation for complex queries
- [ ] **Certification expiry batch job** — Auto-update expired certifications
- [ ] **Email uniqueness validation** — Prevent duplicate registrations

---

**Document Status:** APPROVED for implementation  
**Owner:** Architect  
**Reviewed:** 2026-05-22  
**Implementation Target:** Phase 2