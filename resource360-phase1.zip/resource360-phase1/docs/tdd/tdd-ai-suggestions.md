# TDD: AI Candidate Suggestions
## Resource 360 — Technical Design Document
## TEG AI Adoption Pilot | Phase 1 Implementation

---

## 1. Overview

**Feature:** AI-powered candidate ranking for demand fulfilment  
**Scope:** Claude API integration for skill matching and readiness assessment  
**Primary Actor:** Resource Manager (RBAC: RESOURCE_MANAGER only)  
**AI Model:** claude-sonnet-4-20250514 via Anthropic SDK  
**Core Value:** Accelerate candidate identification through intelligent skill matching  
**Human Oversight:** AI suggests, human confirms — no autonomous allocation decisions  

---

## 2. Sequence Diagram

### GET /ai/suggestions/{demand_id} — AI Candidate Ranking Flow

```mermaid
sequenceDiagram
    participant RM as Resource Manager
    participant UI as React CandidateSuggestions
    participant API as FastAPI /ai/suggestions/{demand_id}
    participant JWT as JWT Middleware
    participant DB as SQLite Database
    participant AI as ai_service.py
    participant Claude as Claude API (claude-sonnet-4-20250514)

    RM->>UI: Navigate to demand suggestions
    UI->>API: GET /ai/suggestions/{demand_id}
    
    API->>JWT: Validate JWT token
    JWT->>JWT: Extract role claim
    
    alt Invalid token or wrong role
        JWT-->>API: 401 Unauthorized / 403 Forbidden
        API-->>UI: Error response
        UI-->>RM: Show access denied
    else Valid RESOURCE_MANAGER
        JWT->>API: Proceed with authorized user
        
        API->>DB: SELECT demand_request WHERE id = ? AND status = 'OPEN'
        
        alt Demand not found or not OPEN
            DB-->>API: No results / wrong status
            API-->>UI: 404 DEMAND_NOT_OPEN
            UI-->>RM: Show demand unavailable message
        else Demand exists and OPEN
            DB-->>API: Demand details with required_skills JSON
            
            API->>DB: SELECT bench employees with matching skills
            Note right of DB: Complex query: JOIN skills table,<br/>filter by bench_status='BENCH',<br/>JSON skill matching
            
            alt No bench employees match
                DB-->>API: Empty result set
                API-->>UI: 200 {empty suggestions list}
                UI-->>RM: Show "No candidates available" message
            else Candidates found
                DB-->>API: List of potential candidates with skills
                
                API->>AI: build_prompt(demand, candidates)
                AI->>AI: Construct system + user prompts
                Note right of AI: System: Role as recruitment expert<br/>User: Demand details + candidate profiles
                
                AI->>Claude: POST /v1/messages
                Note right of Claude: Model: claude-sonnet-4-20250514<br/>Max tokens: 4000<br/>Temperature: 0.1
                
                alt Claude API timeout/error
                    Claude-->>AI: 500 / Timeout
                    AI-->>API: AIServiceError
                    API-->>UI: 503 Service Unavailable
                    UI-->>RM: Show "AI temporarily unavailable" + fallback list
                else Claude API success
                    Claude-->>AI: JSON response with rankings
                    
                    AI->>AI: Parse and validate JSON
                    Note right of AI: Extract: match_score, matched_skills,<br/>missing_skills, readiness_summary
                    
                    AI-->>API: Ranked candidate list
                    
                    API-->>UI: 200 {ranked suggestions with scores}
                    UI->>UI: Render score bars and readiness summaries
                    UI-->>RM: Display ranked candidates with AI insights
                end
            end
        end
    end
```

---

## 3. API Specifications

### GET /ai/suggestions/{demand_id}

**Path Parameters:**
- `demand_id` (integer): ID of the open demand request

**Success Response (200):**
```json
{
  "demand_id": 1,
  "total_candidates": 3,
  "processing_time_ms": 1250,
  "ai_model": "claude-sonnet-4-20250514",
  "suggestions": [
    {
      "employee_id": 15,
      "employee_name": "Sneha Krishnan",
      "match_score": 92,
      "matched_skills": ["React", "TypeScript"],
      "missing_skills": [],
      "grade": "Senior",
      "availability": "Available immediately",
      "current_allocation": 0,
      "bench_since": "2026-04-15",
      "readiness_summary": "Excellent fit with strong React and TypeScript expertise. Ready for immediate deployment with no skill gaps."
    },
    {
      "employee_id": 8,
      "employee_name": "Arun Kumar",
      "match_score": 78,
      "matched_skills": ["React"],
      "missing_skills": ["TypeScript"],
      "grade": "Senior",
      "availability": "Available in 2 weeks",
      "current_allocation": 60,
      "bench_since": null,
      "readiness_summary": "Strong React experience but will need TypeScript upskilling. Partial availability due to current 60% allocation."
    }
  ],
  "skill_gap_analysis": {
    "required_skills": ["React", "TypeScript"],
    "skill_availability": {
      "React": {"available_count": 5, "expert_count": 2},
      "TypeScript": {"available_count": 3, "expert_count": 1}
    }
  }
}
```

### GET /ai/readiness/{employee_id}/{demand_id}

**Success Response (200):**
```json
{
  "employee_id": 15,
  "demand_id": 1,
  "match_score": 92,
  "skill_gaps": [],
  "summary": "Sneha is an excellent candidate for this Senior React Developer role. Her expertise in React and TypeScript directly matches the requirements, with 3+ years experience building enterprise applications. She's immediately available and has worked on similar customer portal projects. No upskilling required - ready for immediate deployment.",
  "recommendations": [
    "Ideal match - proceed with allocation",
    "Consider for team lead role given experience"
  ],
  "risk_factors": []
}
```

**Error Responses:**
```json
// 404 Demand Not Open
{
  "error": "Demand request not found or not in OPEN status",
  "code": "DEMAND_NOT_OPEN",
  "field": null,
  "details": {
    "demand_id": 1,
    "current_status": "FULFILLED"
  }
}

// 503 AI Service Unavailable
{
  "error": "AI suggestion service temporarily unavailable. Please try again in a few minutes.",
  "code": "AI_SERVICE_UNAVAILABLE", 
  "field": null,
  "details": {
    "fallback_message": "You can still view available employees manually in the Employee section."
  }
}
```

---

## 4. RBAC Matrix

| Action | Resource Manager | Operations Manager | Solution Owner |
|---|---|---|---|
| GET /ai/suggestions/{demand_id} | ✅ | ❌ (403) | ❌ (403) |
| GET /ai/readiness/{employee_id}/{demand_id} | ✅ | ❌ (403) | ❌ (403) |
| View AI model details | ✅ | ❌ | ❌ |

**Enforcement Point:** `middleware/auth.py` — JWT role claim validation  
**Business Rationale:** Only Resource Managers make allocation decisions, so only they need AI assistance

---

## 5. Database Operations

### 5.1 Demand Request Details Query

```sql
-- Get demand request with parsed required_skills JSON
SELECT 
    dr.id,
    dr.project_name,
    dr.required_role,
    dr.required_skills,  -- JSON array: ["React","TypeScript"]
    dr.start_date,
    dr.allocation_pct,
    dr.grade_required,
    dr.priority,
    dr.status,
    u.name as raised_by_name
FROM demand_requests dr
LEFT JOIN users u ON dr.raised_by_user_id = u.id
WHERE dr.id = ? 
  AND dr.status = 'OPEN';
```

### 5.2 Bench Employee Skill Matching Query

```sql
-- Find bench employees with at least one matching skill
-- Note: required_skills is stored as JSON array in demand_requests table
WITH required_skills_table AS (
    SELECT json_each.value as skill_name
    FROM demand_requests dr, json_each(dr.required_skills)
    WHERE dr.id = ?
),
matching_employees AS (
    SELECT DISTINCT
        e.id as employee_id,
        e.name as employee_name,
        e.grade,
        e.bench_status,
        e.created_at as bench_since_date,
        
        -- Calculate current allocation
        COALESCE(SUM(a.allocation_pct), 0) as current_allocation,
        
        -- Count matching skills for this employee
        COUNT(DISTINCT s.skill_name) as matching_skills_count
        
    FROM employees e
    LEFT JOIN allocations a ON e.id = a.employee_id AND a.is_active = 1
    INNER JOIN skills s ON e.id = s.employee_id
    INNER JOIN required_skills_table rst ON s.skill_name = rst.skill_name
    
    WHERE e.is_deleted = 0
      AND e.bench_status IN ('BENCH', 'ROLLING_OFF')  -- Available candidates
      AND (100 - COALESCE(SUM(a.allocation_pct), 0)) >= 
          (SELECT allocation_pct FROM demand_requests WHERE id = ?)  -- Has capacity
    
    GROUP BY e.id, e.name, e.grade, e.bench_status, e.created_at
    HAVING matching_skills_count > 0  -- At least one skill match
)
SELECT 
    me.*,
    GROUP_CONCAT(s.skill_name) as all_skills,
    GROUP_CONCAT(CASE WHEN rst.skill_name IS NOT NULL THEN s.skill_name END) as matched_skills
FROM matching_employees me
LEFT JOIN skills s ON me.employee_id = s.employee_id
LEFT JOIN required_skills_table rst ON s.skill_name = rst.skill_name
GROUP BY me.employee_id
ORDER BY me.matching_skills_count DESC, me.current_allocation ASC;
```

### 5.3 Individual Employee Skills Query

```sql
-- Get complete skill profile for a specific employee (for AI prompt)
SELECT 
    e.id,
    e.name,
    e.grade,
    e.department,
    e.location,
    e.bench_status,
    GROUP_CONCAT(s.skill_name || ':' || s.proficiency) as skills_with_proficiency,
    GROUP_CONCAT(c.cert_name || ':' || c.status) as certifications
FROM employees e
LEFT JOIN skills s ON e.id = s.employee_id  
LEFT JOIN certifications c ON e.id = c.employee_id
WHERE e.id = ?
  AND e.is_deleted = 0
GROUP BY e.id;
```

### 5.4 Skill Availability Analysis

```sql
-- Analyze skill availability across all bench employees
WITH required_skills_table AS (
    SELECT json_each.value as skill_name
    FROM demand_requests dr, json_each(dr.required_skills)
    WHERE dr.id = ?
)
SELECT 
    rst.skill_name,
    COUNT(DISTINCT e.id) as available_count,
    COUNT(DISTINCT CASE WHEN s.proficiency = 'Expert' THEN e.id END) as expert_count,
    COUNT(DISTINCT CASE WHEN s.proficiency = 'Proficient' THEN e.id END) as proficient_count,
    COUNT(DISTINCT CASE WHEN s.proficiency = 'Beginner' THEN e.id END) as beginner_count
FROM required_skills_table rst
LEFT JOIN skills s ON rst.skill_name = s.skill_name
LEFT JOIN employees e ON s.employee_id = e.id 
WHERE e.is_deleted = 0 
  AND e.bench_status IN ('BENCH', 'ROLLING_OFF')
GROUP BY rst.skill_name;
```

---

## 6. AI Prompt Design

### 6.1 System Prompt Template

```python
SYSTEM_PROMPT = """
You are an expert technical recruiter and resource allocation specialist. Your task is to analyze employee candidates against specific project requirements and rank them by fit.

Instructions:
1. Evaluate each candidate against the required skills, role, and grade
2. Consider both technical skill match and experience level
3. Assign a match score from 0-100 (100 = perfect fit)
4. Identify matched skills and missing skills for each candidate
5. Provide a concise readiness summary (2-3 sentences max)
6. Rank candidates by overall fit, not just skill count

Evaluation Criteria:
- Skill Match (40%): Direct alignment with required skills
- Experience Level (30%): Grade/seniority match with required role  
- Availability (20%): Current allocation and bench status
- Additional Skills (10%): Relevant skills beyond requirements

Return results as valid JSON only, no additional text.
"""
```

### 6.2 User Prompt Template

```python
def build_user_prompt(demand: DemandRequest, candidates: List[Employee]) -> str:
    return f"""
DEMAND REQUIREMENTS:
- Project: {demand.project_name}
- Role: {demand.required_role}
- Required Skills: {', '.join(demand.required_skills)}
- Grade Required: {demand.grade_required}
- Allocation: {demand.allocation_pct}%
- Priority: {demand.priority}

CANDIDATE POOL:
{format_candidates(candidates)}

Please rank these candidates and return a JSON response with this exact schema:

{{
  "suggestions": [
    {{
      "employee_id": int,
      "match_score": int (0-100),
      "matched_skills": ["skill1", "skill2"],
      "missing_skills": ["skill3"],
      "readiness_summary": "Brief assessment in 2-3 sentences"
    }}
  ]
}}

Focus on finding the best overall fit, not just the candidate with the most skills.
"""

def format_candidates(candidates: List[Employee]) -> str:
    formatted = []
    for candidate in candidates:
        skills_str = ", ".join([f"{s.skill_name} ({s.proficiency})" for s in candidate.skills])
        certs_str = ", ".join([c.cert_name for c in candidate.certifications if c.status == 'Active'])
        
        formatted.append(f"""
Employee ID: {candidate.id}
Name: {candidate.name}
Grade: {candidate.grade}
Department: {candidate.department}
Current Allocation: {candidate.current_allocation}%
Skills: {skills_str}
Active Certifications: {certs_str}
Bench Since: {candidate.bench_since or 'Currently allocated'}
""")
    
    return "\n".join(formatted)
```

### 6.3 Claude API Request Configuration

```python
async def call_claude_api(prompt: str) -> dict:
    try:
        client = anthropic.AsyncAnthropic(api_key=settings.CLAUDE_API_KEY)
        
        response = await client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4000,
            temperature=0.1,  # Low temperature for consistent results
            system=SYSTEM_PROMPT,
            messages=[
                {"role": "user", "content": prompt}
            ]
        )
        
        # Parse JSON response
        content = response.content[0].text
        return json.loads(content)
        
    except anthropic.APITimeoutError:
        raise AIServiceTimeoutError("Claude API request timed out")
    except anthropic.APIError as e:
        raise AIServiceError(f"Claude API error: {e}")
    except json.JSONDecodeError:
        raise AIServiceError("Invalid JSON response from Claude")
```

### 6.4 Response Validation Schema

```python
class AISuggestionResponse(BaseModel):
    suggestions: List[AISuggestion]

class AISuggestion(BaseModel):
    employee_id: int
    match_score: int = Field(ge=0, le=100)
    matched_skills: List[str]
    missing_skills: List[str]
    readiness_summary: str = Field(min_length=10, max_length=500)
    
    @validator('match_score')
    def validate_score(cls, v):
        if not 0 <= v <= 100:
            raise ValueError('match_score must be between 0 and 100')
        return v
```

### 6.5 Fallback Strategy (AI Unavailable)

```python
def generate_fallback_suggestions(candidates: List[Employee], demand: DemandRequest) -> List[dict]:
    """
    Simple rule-based ranking when Claude API is unavailable
    """
    suggestions = []
    
    for candidate in candidates:
        # Count skill matches
        matched_skills = [skill for skill in candidate.skills 
                         if skill.skill_name in demand.required_skills]
        missing_skills = [skill for skill in demand.required_skills
                         if skill not in [s.skill_name for s in matched_skills]]
        
        # Simple scoring algorithm
        skill_match_score = (len(matched_skills) / len(demand.required_skills)) * 70
        grade_match_score = 20 if candidate.grade == demand.grade_required else 10
        availability_score = 10 if candidate.current_allocation == 0 else 5
        
        total_score = min(100, skill_match_score + grade_match_score + availability_score)
        
        suggestions.append({
            "employee_id": candidate.id,
            "match_score": int(total_score),
            "matched_skills": [s.skill_name for s in matched_skills],
            "missing_skills": missing_skills,
            "readiness_summary": f"Basic skill match analysis. Has {len(matched_skills)} of {len(demand.required_skills)} required skills. AI analysis unavailable."
        })
    
    return sorted(suggestions, key=lambda x: x['match_score'], reverse=True)
```

---

## 7. Error Handling

### 7.1 Application-Level Exception Classes

```python
class AIServiceError(Exception):
    """AI service-related errors"""
    pass

class AIServiceTimeoutError(AIServiceError):
    def __init__(self, timeout_seconds: int = 30):
        self.timeout_seconds = timeout_seconds
        super().__init__(f"AI service request timed out after {timeout_seconds} seconds")

class DemandNotOpenError(Exception):
    def __init__(self, demand_id: int, current_status: str):
        self.demand_id = demand_id
        self.current_status = current_status
        super().__init__(f"Demand {demand_id} is {current_status}, not OPEN")

class InvalidAIResponseError(AIServiceError):
    def __init__(self, response_content: str):
        self.response_content = response_content
        super().__init__(f"Invalid or unparseable AI response")
```

### 7.2 HTTP Error Responses

| Error Scenario | HTTP Code | Error Code | Fallback Strategy |
|---|---|---|---|
| **No bench employees match** | 200 | N/A | Return empty suggestions list |
| **Claude API timeout** | 503 | AI_SERVICE_UNAVAILABLE | Use rule-based fallback |
| **demand_id does not exist** | 404 | DEMAND_NOT_FOUND | N/A |
| **demand is FULFILLED** | 404 | DEMAND_NOT_OPEN | N/A |
| **Invalid Claude response** | 503 | AI_SERVICE_ERROR | Use rule-based fallback |
| **RBAC violation** | 403 | FORBIDDEN | N/A |

### 7.3 Error Response Examples

```json
// 503 AI Service Unavailable (with fallback)
{
  "error": "AI suggestion service is temporarily unavailable. Showing basic skill matching instead.",
  "code": "AI_SERVICE_UNAVAILABLE",
  "field": null,
  "suggestions": [
    // Fallback rule-based suggestions
  ],
  "fallback_mode": true,
  "retry_after_seconds": 60
}

// 404 Demand Not Open
{
  "error": "Cannot provide suggestions: demand request is already fulfilled",
  "code": "DEMAND_NOT_OPEN",
  "field": null,
  "details": {
    "demand_id": 1,
    "current_status": "FULFILLED",
    "fulfilled_by_employee_id": 5
  }
}
```

---

## 8. React Frontend Integration

### 8.1 CandidateSuggestions Component

```typescript
interface AISuggestion {
  employee_id: number;
  employee_name: string;
  match_score: number;
  matched_skills: string[];
  missing_skills: string[];
  grade: string;
  availability: string;
  current_allocation: number;
  bench_since?: string;
  readiness_summary: string;
}

interface AISuggestionsResponse {
  demand_id: number;
  total_candidates: number;
  processing_time_ms: number;
  ai_model: string;
  suggestions: AISuggestion[];
  skill_gap_analysis: SkillGapAnalysis;
  fallback_mode?: boolean;
}

interface CandidateSuggestionsProps {
  demandId: number;
  onCandidateSelect: (candidate: AISuggestion) => void;
}
```

### 8.2 React Query Hook

```typescript
const useAISuggestions = (demandId: number) => {
  return useQuery({
    queryKey: ['ai-suggestions', demandId],
    queryFn: () => api.get(`/ai/suggestions/${demandId}`),
    staleTime: 5 * 60 * 1000, // 5 minutes (AI analysis is expensive)
    retry: (failureCount, error) => {
      // Don't retry 404s (demand not found/not open)
      if (error.response?.status === 404) return false;
      // Retry 503s (AI service unavailable) up to 2 times
      if (error.response?.status === 503) return failureCount < 2;
      return failureCount < 3;
    },
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000)
  });
};

const useAIReadiness = (employeeId: number, demandId: number) => {
  return useQuery({
    queryKey: ['ai-readiness', employeeId, demandId],
    queryFn: () => api.get(`/ai/readiness/${employeeId}/${demandId}`),
    enabled: !!employeeId && !!demandId,
    staleTime: 10 * 60 * 1000 // 10 minutes (detailed analysis)
  });
};
```

### 8.3 Score Bar Visualization

```typescript
const MatchScoreBar: React.FC<{
  score: number;
  candidateName: string;
}> = ({ score, candidateName }) => {
  const getScoreColor = (score: number) => {
    if (score >= 90) return 'bg-green-500';
    if (score >= 75) return 'bg-blue-500';
    if (score >= 60) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getScoreLabel = (score: number) => {
    if (score >= 90) return 'Excellent Fit';
    if (score >= 75) return 'Good Fit';
    if (score >= 60) return 'Moderate Fit';
    return 'Poor Fit';
  };

  return (
    <div className="score-bar-container">
      <div className="flex justify-between mb-1">
        <span className="text-sm font-medium">{candidateName}</span>
        <span className="text-sm text-gray-600">{score}/100</span>
      </div>
      
      <div className="w-full bg-gray-200 rounded-full h-3">
        <div 
          className={`h-3 rounded-full transition-all duration-500 ${getScoreColor(score)}`}
          style={{width: `${score}%`}}
        />
      </div>
      
      <div className="text-xs text-gray-500 mt-1">
        {getScoreLabel(score)}
      </div>
    </div>
  );
};
```

### 8.4 Fallback Mode Display

```typescript
const AIStatusIndicator: React.FC<{
  fallbackMode?: boolean;
  processingTime?: number;
}> = ({ fallbackMode, processingTime }) => {
  if (fallbackMode) {
    return (
      <div className="ai-status fallback">
        <Icon name="warning" className="text-yellow-500" />
        <span>AI analysis unavailable - showing basic matching</span>
        <button className="retry-btn">Retry AI Analysis</button>
      </div>
    );
  }

  return (
    <div className="ai-status success">
      <Icon name="ai" className="text-blue-500" />
      <span>AI-powered ranking ({processingTime}ms)</span>
      <span className="model-info">claude-sonnet-4</span>
    </div>
  );
};
```

---

## 9. Edge Cases

### 9.1 No Candidates Edge Cases

| Test Case | Scenario | Expected Result | UI Display |
|---|---|---|---|
| **No bench employees match** | All employees allocated or wrong skills | ✅ Return 200 with empty list | "No available candidates" message |
| **All employees over-allocated** | Everyone at 100%+ allocation | ✅ Return 200 with empty list | "All employees fully allocated" |
| **Skills don't match at all** | Required ["Python"], bench has ["Java"] | ✅ Return 200 with empty list | "No candidates with matching skills" |
| **Grade requirements too high** | Require "Principal", only "Junior" available | ✅ Return 200 with empty list | "No candidates at required level" |

### 9.2 AI Service Edge Cases

| Test Case | Scenario | Expected Result | Fallback Strategy |
|---|---|---|---|
| **Claude API timeout (30s)** | API call exceeds timeout | ❌ 503 AI_SERVICE_UNAVAILABLE | Use rule-based ranking algorithm |
| **Claude API rate limit** | Too many requests | ❌ 503 AI_SERVICE_UNAVAILABLE | Exponential backoff + fallback |
| **Invalid JSON response** | Claude returns malformed JSON | ❌ 503 AI_SERVICE_ERROR | Parse what's possible + fallback |
| **Claude API key expired** | Authentication fails | ❌ 503 AI_SERVICE_UNAVAILABLE | Log error + use fallback |
| **Empty AI response** | Claude returns `{"suggestions": []}` | ✅ Accept as valid response | Show "AI found no matches" |

### 9.3 Demand State Edge Cases

| Test Case | Demand Status | Expected Result | Error Code |
|---|---|---|---|
| **demand_id does not exist** | Non-existent ID 9999 | ❌ 404 DEMAND_NOT_FOUND | Standard 404 |
| **demand is FULFILLED** | status = 'FULFILLED' | ❌ 404 DEMAND_NOT_OPEN | Cannot suggest for closed demand |
| **demand is DECLINED** | status = 'DECLINED' | ❌ 404 DEMAND_NOT_OPEN | Cannot suggest for closed demand |
| **demand is PENDING** | status = 'PENDING' | ✅ 200 (allow suggestions) | May help with pending decision |

### 9.4 AI Response Quality Edge Cases

| Test Case | AI Response Issue | System Behavior | Mitigation |
|---|---|---|---|
| **Match scores outside 0-100 range** | Claude returns score: 150 | ❌ Validation error → fallback | Clamp to 0-100 range |
| **Missing required fields** | No `readiness_summary` field | ❌ Schema validation → fallback | Use default summary |
| **Unrealistic skill matches** | Claims skill not in employee profile | ⚠️ Log warning, accept response | Validate against actual skills |
| **Inconsistent ranking** | Lower score ranked higher | ⚠️ Log warning, re-sort by score | Override AI ranking |

### 9.5 Performance Edge Cases

| Test Case | Scenario | Expected Result | Performance Impact |
|---|---|---|---|
| **Large candidate pool (50+ employees)** | Many bench employees match | ✅ Process all, may take 10-15s | Consider pagination |
| **Complex skill requirements (10+ skills)** | Very specific role requirements | ✅ Longer prompt, may take 8-12s | Optimize prompt length |
| **Concurrent AI requests** | Multiple RMs use AI simultaneously | ✅ Each request handled independently | Monitor API rate limits |
| **Repeated requests for same demand** | RM refreshes suggestions | ✅ Return cached if < 5 minutes old | Use React Query caching |

### 9.6 Data Consistency Edge Cases

| Test Case | Scenario | Expected Result | Detection Method |
|---|---|---|---|
| **Employee skills updated after query** | Skills changed between DB query and AI call | ⚠️ AI analyzes stale data | Accept eventual consistency |
| **Employee allocation changed mid-request** | Allocation updated during AI processing | ⚠️ May suggest unavailable employee | Validate allocation before fulfilment |
| **Demand requirements changed** | required_skills updated after AI call | ⚠️ Suggestions may be outdated | Cache invalidation on demand update |
| **JSON skill parsing fails** | Malformed required_skills JSON | ❌ 500 error | Validate JSON on demand creation |

---

## 10. Performance Considerations

### 10.1 Database Query Optimization

```sql
-- Optimized indexes for AI suggestion queries
CREATE INDEX idx_demand_requests_status ON demand_requests(status, id);
CREATE INDEX idx_employees_bench_status ON employees(bench_status, is_deleted);
CREATE INDEX idx_skills_employee_skill ON skills(employee_id, skill_name);
CREATE INDEX idx_allocations_active_employee ON allocations(is_active, employee_id);

-- JSON function optimization for required_skills matching
-- SQLite json_each is performant for small arrays (typical: 2-8 skills)
```

### 10.2 AI Service Performance

- **Request timeout:** 30 seconds (Claude API can take 5-15 seconds)
- **Prompt optimization:** Keep candidate descriptions concise (< 3000 tokens)
- **Response caching:** 5-minute cache for expensive AI calls
- **Concurrent requests:** Handle multiple Resource Managers using AI
- **Fallback performance:** Rule-based ranking executes in < 100ms

### 10.3 Caching Strategy

- **AI suggestions:** 5-minute cache (expensive Claude API calls)
- **Employee skills data:** 2-minute cache (moderately dynamic)
- **Demand details:** 1-minute cache (can change during processing)
- **No server-side caching:** All caching via React Query on frontend

---

## 11. Testing Strategy

### 11.1 Unit Tests (pytest)

```python
# tests/test_ai_service.py
def test_build_candidate_prompt():
    """Test AI prompt construction"""

def test_parse_claude_response():
    """Test JSON response parsing and validation"""

def test_fallback_ranking_algorithm():
    """Test rule-based fallback when AI unavailable"""

def test_skill_matching_logic():
    """Test database skill matching query"""

def test_ai_service_timeout_handling():
    """Test graceful timeout handling"""

# tests/test_ai_prompt_engineering.py
def test_prompt_with_various_candidate_counts():
    """Test prompts with 1, 5, 20+ candidates"""

def test_prompt_with_complex_skill_requirements():
    """Test prompts with 10+ required skills"""

def test_response_score_validation():
    """Test match score range validation"""
```

### 11.2 Integration Tests (pytest + httpx + Claude API)

```python
# tests/test_ai_integration.py
async def test_ai_suggestions_end_to_end():
    """Test complete AI suggestion flow with real Claude API"""

async def test_ai_suggestions_with_mock_claude():
    """Test AI flow with mocked Claude responses"""

def test_ai_suggestions_rbac():
    """Test role-based access control"""

def test_ai_suggestions_demand_not_found():
    """Test 404 handling for invalid demand IDs"""

def test_ai_suggestions_empty_candidates():
    """Test empty candidate pool handling"""

# tests/test_ai_fallback.py
def test_fallback_when_claude_unavailable():
    """Test fallback ranking when Claude API down"""

def test_fallback_performance():
    """Test fallback executes quickly"""
```

### 11.3 Frontend Tests (Vitest + React Testing Library)

```typescript
// components/CandidateSuggestions.test.tsx
describe('CandidateSuggestions', () => {
  test('renders AI suggestions with score bars');
  test('handles AI service unavailable gracefully');
  test('shows fallback mode indicator');
  test('displays skill gap analysis');
  test('handles empty candidate list');
});

// components/MatchScoreBar.test.tsx
describe('MatchScoreBar', () => {
  test('displays correct score colors');
  test('shows score labels correctly');
  test('animates score bar fill');
});
```

---

## 12. Implementation Checklist

### Backend Implementation

- [ ] **services/ai_service.py** — Claude API integration and prompt engineering
- [ ] **routers/ai.py** — AI suggestion and readiness endpoints
- [ ] **schemas/ai.py** — Pydantic models for AI requests/responses
- [ ] **models/ai_cache.py** — Optional: AI response caching model
- [ ] **config/ai_settings.py** — Claude API configuration
- [ ] **tests/test_ai.py** — Comprehensive AI service tests

### Frontend Implementation

- [ ] **components/CandidateSuggestions.tsx** — Main AI suggestions display
- [ ] **components/MatchScoreBar.tsx** — Score visualization component
- [ ] **components/SkillGapAnalysis.tsx** — Skill availability analysis
- [ ] **components/ReadinessSummary.tsx** — AI readiness assessment display
- [ ] **api/ai.ts** — React Query hooks for AI endpoints
- [ ] **types/ai.ts** — TypeScript interfaces for AI responses
- [ ] **tests/CandidateSuggestions.test.tsx** — Component tests

### AI & Data Pipeline

- [ ] **Prompt engineering** — Optimize Claude prompts for accuracy
- [ ] **Response validation** — Schema validation for AI responses
- [ ] **Fallback algorithms** — Rule-based ranking when AI unavailable
- [ ] **Performance monitoring** — Track AI response times and accuracy
- [ ] **Error handling** — Graceful degradation for all AI failure modes

### Environment & Security

- [ ] **Claude API key management** — Secure configuration
- [ ] **Rate limiting** — Handle Claude API quotas
- [ ] **Audit logging** — Log all AI interactions for compliance
- [ ] **Cost monitoring** — Track Claude API usage and costs

---

**Document Status:** APPROVED for implementation  
**Owner:** Architect  
**Reviewed:** 2026-05-22  
**Implementation Target:** Phase 2