# TDD: Bench Dashboard
## Resource 360 — Technical Design Document
## TEG AI Adoption Pilot | Phase 1 Implementation

---

## 1. Overview

**Feature:** Real-time dashboard for bench health and capacity management  
**Scope:** Multi-panel dashboard showing bench metrics, over-allocations, and demand  
**Primary Actors:** Resource Manager, Operations Manager (RBAC: no access for Solution Owner)  
**Core Value:** Proactive resource visibility to prevent capacity gaps and over-allocation  
**Performance Target:** Dashboard loads in < 2 seconds with parallel API calls  
**Update Frequency:** Real-time metrics with 30-second auto-refresh  

---

## 2. Sequence Diagram

### Dashboard Load Sequence — Parallel React Query Calls

```mermaid
sequenceDiagram
    participant User as User (RM/OM)
    participant React as React DashboardPage
    participant Query1 as React Query (/dashboard/metrics)
    participant Query2 as React Query (/dashboard/bench)
    participant Query3 as React Query (/dashboard/over-allocations) 
    participant Query4 as React Query (/demand-requests?status=OPEN)
    participant API as FastAPI Backend
    participant DB as SQLite Database

    User->>React: Navigate to Dashboard
    React->>React: Initialize dashboard components
    
    Note over React: Fire 4 parallel API calls simultaneously
    
    par Dashboard Metrics
        React->>Query1: useQuery(['dashboard', 'metrics'])
        Query1->>API: GET /dashboard/metrics
        API->>DB: SELECT bench counts, over-allocations, rolloffs
        DB-->>API: Aggregated metrics
        API-->>Query1: 200 {bench_count, rolling_off_30d, over_allocated_count, open_demand_count}
        Query1-->>React: Metrics data
    
    and Bench Employees
        React->>Query2: useQuery(['dashboard', 'bench'])
        Query2->>API: GET /dashboard/bench
        API->>DB: SELECT employees JOIN skills WHERE bench_status IN ('BENCH', 'ROLLING_OFF')
        DB-->>API: Bench employee list with skills
        API-->>Query2: 200 [employee list]
        Query2-->>React: Bench data
    
    and Over-Allocations
        React->>Query3: useQuery(['dashboard', 'over-allocations'])
        Query3->>API: GET /dashboard/over-allocations
        API->>DB: SELECT employees + SUM(allocation_pct) GROUP BY employee HAVING SUM > 100
        DB-->>API: Over-allocated employees
        API-->>Query3: 200 [over-allocation list]
        Query3-->>React: Over-allocation data
    
    and Open Demands
        React->>Query4: useQuery(['demand-requests', 'OPEN'])
        Query4->>API: GET /demand-requests?status=OPEN
        API->>DB: SELECT demand_requests WHERE status='OPEN'
        DB-->>API: Open demand requests
        API-->>Query4: 200 [demand list]
        Query4-->>React: Demand data
    end
    
    React->>React: Render metric cards (as data arrives)
    React->>React: Render bench panel (when bench data loads)
    React->>React: Render over-allocation alerts (when data loads)
    React->>React: Render demand panel (when demand data loads)
    React-->>User: Complete dashboard with all panels populated
    
    Note over React: Auto-refresh every 30 seconds
    loop Every 30 seconds
        React->>Query1: Refetch metrics
        React->>Query2: Refetch bench data
        React->>Query3: Refetch over-allocations
        React->>Query4: Refetch open demands
    end
```

---

## 3. API Specifications

### GET /dashboard/metrics

**Success Response (200):**
```json
{
  "bench_count": 14,
  "bench_trend_7d": {
    "current": 14,
    "previous": 12,
    "change": 2,
    "percentage": 16.7
  },
  "rolling_off_30d": 8,
  "rolling_off_critical": 3,
  "over_allocated_count": 4,
  "over_allocated_critical": 1,
  "open_demand_count": 6,
  "open_demand_urgent": 2,
  "skill_availability": [
    {"skill_name": "React", "available_count": 5, "expert_count": 2},
    {"skill_name": "Python", "available_count": 8, "expert_count": 3},
    {"skill_name": "Java", "available_count": 6, "expert_count": 1}
  ],
  "last_updated": "2026-05-22T10:30:00Z"
}
```

### GET /dashboard/bench

**Query Parameters:**
- `skill` (optional): Filter by skill name (case-insensitive partial match)
- `grade` (optional): Filter by employee grade
- `location` (optional): Filter by location

**Success Response (200):**
```json
[
  {
    "id": 15,
    "name": "Sneha Krishnan",
    "email": "sneha.k@teg.com",
    "grade": "Senior",
    "department": "Engineering",
    "location": "Hyderabad",
    "bench_status": "BENCH",
    "bench_since": "2026-04-15",
    "bench_days": 37,
    "current_allocation": 0,
    "skills": [
      {"skill_name": "React", "proficiency": "Expert"},
      {"skill_name": "TypeScript", "proficiency": "Proficient"}
    ],
    "certifications": [
      {"cert_name": "AWS Solutions Architect", "status": "Active"}
    ],
    "last_project": {
      "project_name": "Customer Portal",
      "end_date": "2026-04-14",
      "role": "Senior Developer"
    }
  }
]
```

### GET /dashboard/over-allocations

**Success Response (200):**
```json
[
  {
    "employee_id": 8,
    "employee_name": "Arun Kumar",
    "email": "arun.k@teg.com",
    "total_allocation_pct": 120,
    "over_by": 20,
    "affected_projects_count": 3,
    "allocations": [
      {
        "project_id": 10,
        "project_name": "Customer Portal",
        "allocation_pct": 50,
        "end_date": "2026-08-31"
      },
      {
        "project_id": 12,
        "project_name": "Legacy Migration",
        "allocation_pct": 40,
        "end_date": "2026-07-15"
      },
      {
        "project_id": 15,
        "project_name": "Analytics Dashboard",
        "allocation_pct": 30,
        "end_date": "2026-06-30"
      }
    ],
    "urgency": "HIGH"
  }
]
```

---

## 4. RBAC Matrix

| Action | Resource Manager | Operations Manager | Solution Owner |
|---|---|---|---|
| GET /dashboard/metrics | ✅ | ✅ | ❌ (403) |
| GET /dashboard/bench | ✅ | ✅ | ❌ (403) |
| GET /dashboard/over-allocations | ✅ | ✅ | ❌ (403) |
| GET /dashboard/rolloffs | ✅ | ✅ | ❌ (403) |
| View skill availability analysis | ✅ | ✅ | ❌ (403) |

**Enforcement Point:** `middleware/auth.py` — JWT role claim validation  
**Business Rationale:** Solution Owners manage project requests, not internal capacity planning

---

## 5. Database Operations

### 5.1 Dashboard Metrics Query

```sql
-- Complete dashboard metrics in single query for performance
WITH bench_metrics AS (
    SELECT 
        COUNT(CASE WHEN bench_status IN ('BENCH', 'ROLLING_OFF') THEN 1 END) as bench_count,
        COUNT(CASE WHEN bench_status = 'BENCH' THEN 1 END) as pure_bench_count,
        COUNT(CASE WHEN bench_status = 'ROLLING_OFF' THEN 1 END) as rolling_off_count
    FROM employees 
    WHERE is_deleted = 0
),
over_allocation_metrics AS (
    SELECT COUNT(*) as over_allocated_count
    FROM (
        SELECT 
            e.id,
            SUM(a.allocation_pct) as total_allocation
        FROM employees e
        INNER JOIN allocations a ON e.id = a.employee_id
        WHERE e.is_deleted = 0 
          AND a.is_active = 1
          AND (a.end_date IS NULL OR a.end_date >= CURRENT_DATE)
        GROUP BY e.id
        HAVING SUM(a.allocation_pct) > 100
    ) over_allocated
),
rolloff_metrics AS (
    SELECT 
        COUNT(CASE WHEN a.end_date BETWEEN CURRENT_DATE AND DATE(CURRENT_DATE, '+30 days') THEN 1 END) as rolling_off_30d,
        COUNT(CASE WHEN a.end_date BETWEEN CURRENT_DATE AND DATE(CURRENT_DATE, '+7 days') THEN 1 END) as rolling_off_critical
    FROM allocations a
    INNER JOIN employees e ON a.employee_id = e.id
    WHERE a.is_active = 1 
      AND a.end_date IS NOT NULL
      AND e.is_deleted = 0
),
demand_metrics AS (
    SELECT 
        COUNT(*) as open_demand_count,
        COUNT(CASE WHEN priority = 'Urgent' THEN 1 END) as open_demand_urgent
    FROM demand_requests 
    WHERE status = 'OPEN'
)
SELECT 
    bm.bench_count,
    bm.pure_bench_count,
    bm.rolling_off_count,
    oam.over_allocated_count,
    rm.rolling_off_30d,
    rm.rolling_off_critical,
    dm.open_demand_count,
    dm.open_demand_urgent
FROM bench_metrics bm, over_allocation_metrics oam, rolloff_metrics rm, demand_metrics dm;
```

### 5.2 Bench Count Query

```sql
-- Simple bench count for metric cards
SELECT COUNT(*) as bench_count
FROM employees 
WHERE bench_status IN ('BENCH', 'ROLLING_OFF') 
  AND is_deleted = 0;
```

### 5.3 Over-allocation Detection Query

```sql
-- Employees with total allocation > 100%
SELECT 
    e.id as employee_id,
    e.name as employee_name,
    e.email,
    SUM(a.allocation_pct) as total_allocation_pct,
    (SUM(a.allocation_pct) - 100) as over_by,
    COUNT(a.id) as affected_projects_count,
    
    -- Urgency classification
    CASE 
        WHEN SUM(a.allocation_pct) >= 150 THEN 'CRITICAL'
        WHEN SUM(a.allocation_pct) >= 120 THEN 'HIGH'
        ELSE 'MEDIUM'
    END as urgency

FROM employees e
INNER JOIN allocations a ON e.id = a.employee_id
WHERE e.is_deleted = 0
  AND a.is_active = 1 
  AND (a.end_date IS NULL OR a.end_date >= CURRENT_DATE)
GROUP BY e.id, e.name, e.email
HAVING SUM(a.allocation_pct) > 100
ORDER BY total_allocation_pct DESC;
```

### 5.4 Skill Availability Analysis Query

```sql
-- Skills available on bench with proficiency breakdown
SELECT 
    s.skill_name,
    COUNT(DISTINCT e.id) as available_count,
    COUNT(DISTINCT CASE WHEN s.proficiency = 'Expert' THEN e.id END) as expert_count,
    COUNT(DISTINCT CASE WHEN s.proficiency = 'Proficient' THEN e.id END) as proficient_count,
    COUNT(DISTINCT CASE WHEN s.proficiency = 'Beginner' THEN e.id END) as beginner_count
FROM employees e
INNER JOIN skills s ON e.id = s.employee_id
WHERE e.bench_status IN ('BENCH', 'ROLLING_OFF')
  AND e.is_deleted = 0
GROUP BY s.skill_name
ORDER BY available_count DESC, expert_count DESC
LIMIT 10;  -- Top 10 most available skills
```

### 5.5 Bench Filtered by Skill Query

```sql
-- Bench employees filtered by skill (case-insensitive partial match)
SELECT 
    e.id,
    e.name,
    e.email,
    e.grade,
    e.department,
    e.location,
    e.bench_status,
    e.created_at as bench_since,
    CAST((JULIANDAY('now') - JULIANDAY(e.created_at)) as INTEGER) as bench_days,
    
    -- Current allocation (should be 0 or partial for bench employees)
    COALESCE(SUM(a.allocation_pct), 0) as current_allocation,
    
    -- All skills for this employee
    GROUP_CONCAT(s.skill_name || ':' || s.proficiency) as skills_list,
    
    -- Active certifications
    GROUP_CONCAT(CASE WHEN c.status = 'Active' THEN c.cert_name END) as active_certifications

FROM employees e
LEFT JOIN allocations a ON e.id = a.employee_id AND a.is_active = 1
LEFT JOIN skills s ON e.id = s.employee_id
LEFT JOIN certifications c ON e.id = c.employee_id
INNER JOIN skills skill_filter ON e.id = skill_filter.employee_id

WHERE e.bench_status IN ('BENCH', 'ROLLING_OFF')
  AND e.is_deleted = 0
  AND skill_filter.skill_name ILIKE '%' || ? || '%'  -- Case-insensitive partial match

GROUP BY e.id, e.name, e.email, e.grade, e.department, e.location, e.bench_status, e.created_at
ORDER BY e.bench_status ASC, bench_days DESC;  -- BENCH first, then by longest on bench
```

### 5.6 Bench Trend Analysis (7-day comparison)

```sql
-- Compare current bench count with 7 days ago
WITH current_bench AS (
    SELECT COUNT(*) as current_count
    FROM employees 
    WHERE bench_status IN ('BENCH', 'ROLLING_OFF') 
      AND is_deleted = 0
),
-- Note: This is simplified for pilot. Production would need bench history tracking.
historical_bench AS (
    SELECT 12 as previous_count  -- Placeholder: would come from audit/history table
)
SELECT 
    cb.current_count,
    hb.previous_count,
    (cb.current_count - hb.previous_count) as change,
    CASE 
        WHEN hb.previous_count > 0 THEN 
            ROUND(((cb.current_count - hb.previous_count) * 100.0 / hb.previous_count), 1)
        ELSE 0 
    END as percentage_change
FROM current_bench cb, historical_bench hb;
```

---

## 6. Performance Optimization

### 6.1 Database Indexes for Dashboard Queries

```sql
-- Critical for dashboard performance
CREATE INDEX idx_employees_bench_status ON employees(bench_status, is_deleted);
CREATE INDEX idx_allocations_active_end_date ON allocations(is_active, end_date) WHERE end_date IS NOT NULL;
CREATE INDEX idx_allocations_employee_active ON allocations(employee_id, is_active);
CREATE INDEX idx_skills_employee_skill ON skills(employee_id, skill_name);
CREATE INDEX idx_demand_requests_status ON demand_requests(status);

-- Composite index for over-allocation queries
CREATE INDEX idx_allocations_employee_active_pct ON allocations(employee_id, is_active, allocation_pct);
```

### 6.2 Query Optimization Strategy

- **Single metrics query:** Combine all dashboard metrics to reduce round trips
- **Parallel API calls:** Frontend fires 4 simultaneous requests
- **Efficient JOINs:** Use appropriate indexes for JOIN operations
- **Result limiting:** Limit skill availability to top 10, over-allocations to active only
- **Computed fields in SQL:** Calculate bench_days and urgency in database

---

## 7. Caching Strategy

### 7.1 React Query Caching

```typescript
// Dashboard-specific cache configuration
const CACHE_CONFIG = {
  metrics: {
    staleTime: 30 * 1000,      // 30 seconds
    cacheTime: 5 * 60 * 1000,  // 5 minutes
    refetchInterval: 30 * 1000, // Auto-refresh every 30 seconds
  },
  bench: {
    staleTime: 60 * 1000,      // 1 minute
    cacheTime: 10 * 60 * 1000, // 10 minutes
    refetchInterval: 60 * 1000, // Auto-refresh every minute
  },
  overAllocations: {
    staleTime: 45 * 1000,      // 45 seconds
    cacheTime: 5 * 60 * 1000,  // 5 minutes
    refetchInterval: 45 * 1000, // Auto-refresh every 45 seconds
  }
};
```

### 7.2 Cache Invalidation Strategy

- **On employee allocation change:** Invalidate metrics, bench, over-allocations
- **On demand fulfilment:** Invalidate metrics, demand-requests
- **On employee status change:** Invalidate metrics, bench
- **Manual refresh button:** Force refetch all dashboard data

---

## 8. Frontend Component Design

### 8.1 Component Hierarchy

```typescript
DashboardPage.tsx
├── MetricsRow.tsx
│   ├── MetricCard.tsx (Bench Count)
│   ├── MetricCard.tsx (Rolling Off)  
│   ├── MetricCard.tsx (Over-allocated)
│   └── MetricCard.tsx (Open Demands)
├── DashboardGrid.tsx
│   ├── BenchPanel.tsx
│   │   ├── BenchFilters.tsx
│   │   ├── BenchTable.tsx
│   │   └── SkillAvailabilityChart.tsx
│   ├── OverAllocationPanel.tsx
│   │   ├── OverAllocationAlert.tsx
│   │   └── AllocationBreakdown.tsx
│   ├── DemandPanel.tsx
│   │   ├── DemandCard.tsx
│   │   └── DemandPriorityChart.tsx
│   └── RolloffPanel.tsx (from separate TDD)
```

### 8.2 React Query Hooks

```typescript
// Dashboard metrics hook
export const useDashboardMetrics = () => {
  return useQuery({
    queryKey: ['dashboard', 'metrics'],
    queryFn: () => api.get('/dashboard/metrics'),
    staleTime: 30 * 1000,
    refetchInterval: 30 * 1000,
    refetchIntervalInBackground: true
  });
};

// Bench employees hook
export const useBenchEmployees = (filters?: BenchFilters) => {
  return useQuery({
    queryKey: ['dashboard', 'bench', filters],
    queryFn: () => api.get('/dashboard/bench', { params: filters }),
    staleTime: 60 * 1000,
    refetchInterval: 60 * 1000,
    enabled: true
  });
};

// Over-allocations hook
export const useOverAllocations = () => {
  return useQuery({
    queryKey: ['dashboard', 'over-allocations'],
    queryFn: () => api.get('/dashboard/over-allocations'),
    staleTime: 45 * 1000,
    refetchInterval: 45 * 1000
  });
};

// Open demands hook (reuses from demand-requests)
export const useOpenDemands = () => {
  return useQuery({
    queryKey: ['demand-requests', 'OPEN'],
    queryFn: () => api.get('/demand-requests', { params: { status: 'OPEN' } }),
    staleTime: 2 * 60 * 1000,  // 2 minutes (less frequent changes)
    refetchInterval: 2 * 60 * 1000
  });
};
```

### 8.3 MetricCard Component

```typescript
interface MetricCardProps {
  title: string;
  value: number | string;
  trend?: {
    change: number;
    percentage: number;
    period: string;
  };
  urgency?: 'normal' | 'warning' | 'critical';
  icon: React.ComponentType;
  loading?: boolean;
  onClick?: () => void;
}

const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  trend,
  urgency = 'normal',
  icon: Icon,
  loading,
  onClick
}) => {
  const getUrgencyStyle = () => {
    switch (urgency) {
      case 'critical': return 'border-l-4 border-red-500 bg-red-50';
      case 'warning': return 'border-l-4 border-yellow-500 bg-yellow-50';
      default: return 'border-l-4 border-blue-500 bg-white';
    }
  };

  if (loading) {
    return <MetricCardSkeleton />;
  }

  return (
    <div 
      className={`${getUrgencyStyle()} p-6 rounded-lg shadow-sm cursor-pointer hover:shadow-md transition-shadow`}
      onClick={onClick}
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <p className="text-3xl font-bold text-gray-900">{value}</p>
          {trend && (
            <TrendIndicator 
              change={trend.change} 
              percentage={trend.percentage} 
              period={trend.period}
            />
          )}
        </div>
        <div className="text-blue-600">
          <Icon className="w-8 h-8" />
        </div>
      </div>
    </div>
  );
};
```

### 8.4 Loading Skeleton Behavior

```typescript
const DashboardSkeleton: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Metrics row skeleton */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[1, 2, 3, 4].map(i => (
          <MetricCardSkeleton key={i} />
        ))}
      </div>
      
      {/* Panels skeleton */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <PanelSkeleton title="Bench Employees" />
        <PanelSkeleton title="Over-allocations" />
        <PanelSkeleton title="Open Demands" />
        <PanelSkeleton title="Upcoming Roll-offs" />
      </div>
    </div>
  );
};

const MetricCardSkeleton: React.FC = () => (
  <div className="border-l-4 border-gray-200 bg-gray-50 p-6 rounded-lg animate-pulse">
    <div className="flex items-center justify-between">
      <div className="space-y-2">
        <div className="h-4 bg-gray-300 rounded w-24"></div>
        <div className="h-8 bg-gray-300 rounded w-16"></div>
        <div className="h-3 bg-gray-300 rounded w-20"></div>
      </div>
      <div className="w-8 h-8 bg-gray-300 rounded"></div>
    </div>
  </div>
);

const PanelSkeleton: React.FC<{title: string}> = ({title}) => (
  <div className="bg-white p-6 rounded-lg shadow">
    <h3 className="text-lg font-semibold mb-4">{title}</h3>
    <div className="space-y-3">
      {[1, 2, 3, 4].map(i => (
        <div key={i} className="flex items-center space-x-4 animate-pulse">
          <div className="w-10 h-10 bg-gray-300 rounded-full"></div>
          <div className="flex-1">
            <div className="h-4 bg-gray-300 rounded w-3/4 mb-2"></div>
            <div className="h-3 bg-gray-300 rounded w-1/2"></div>
          </div>
        </div>
      ))}
    </div>
  </div>
);
```

### 8.5 BenchPanel Component

```typescript
interface BenchFilters {
  skill?: string;
  grade?: string;
  location?: string;
}

const BenchPanel: React.FC = () => {
  const [filters, setFilters] = useState<BenchFilters>({});
  const { data: benchEmployees, isLoading, error } = useBenchEmployees(filters);

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-semibold">Bench Employees</h3>
        <BenchFilters filters={filters} onChange={setFilters} />
      </div>
      
      {isLoading ? (
        <BenchTableSkeleton />
      ) : error ? (
        <ErrorState message="Failed to load bench employees" onRetry={() => {}} />
      ) : (
        <>
          <BenchTable employees={benchEmployees || []} />
          <SkillAvailabilityChart data={benchEmployees || []} />
        </>
      )}
    </div>
  );
};
```

### 8.6 Auto-Refresh Implementation

```typescript
const DashboardPage: React.FC = () => {
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date());

  // Manual refresh all queries
  const queryClient = useQueryClient();
  const refreshDashboard = useCallback(() => {
    queryClient.invalidateQueries(['dashboard']);
    queryClient.invalidateQueries(['demand-requests', 'OPEN']);
    setLastRefresh(new Date());
  }, [queryClient]);

  // Auto-refresh toggle effect
  useEffect(() => {
    if (!autoRefresh) {
      // Disable auto-refresh for all dashboard queries
      queryClient.getQueriesData(['dashboard']).forEach(([queryKey]) => {
        queryClient.cancelQueries(queryKey);
      });
    }
  }, [autoRefresh, queryClient]);

  return (
    <div className="space-y-6">
      <DashboardHeader 
        lastRefresh={lastRefresh}
        autoRefresh={autoRefresh}
        onToggleAutoRefresh={setAutoRefresh}
        onManualRefresh={refreshDashboard}
      />
      
      <MetricsRow />
      <DashboardGrid />
    </div>
  );
};
```

---

## 9. Error Handling

### 9.1 API Error Scenarios

| Error Type | HTTP Code | Frontend Behavior |
|---|---|---|
| **Authentication expired** | 401 | Redirect to login |
| **Insufficient permissions** | 403 | Show access denied message |
| **Database timeout** | 500 | Show retry button with error message |
| **Network failure** | Network error | Show offline indicator, retry automatically |

### 9.2 Partial Data Loading Strategy

```typescript
const DashboardPage: React.FC = () => {
  const metricsQuery = useDashboardMetrics();
  const benchQuery = useBenchEmployees();
  const overAllocationsQuery = useOverAllocations();
  const demandsQuery = useOpenDemands();

  // Render components as data becomes available
  return (
    <div className="space-y-6">
      {/* Always render metrics row - shows skeletons if loading */}
      <MetricsRow 
        data={metricsQuery.data} 
        loading={metricsQuery.isLoading}
        error={metricsQuery.error}
      />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Render each panel independently */}
        <BenchPanel 
          data={benchQuery.data}
          loading={benchQuery.isLoading}
          error={benchQuery.error}
        />
        
        <OverAllocationPanel
          data={overAllocationsQuery.data}
          loading={overAllocationsQuery.isLoading}
          error={overAllocationsQuery.error}
        />
        
        <DemandPanel
          data={demandsQuery.data}
          loading={demandsQuery.isLoading}
          error={demandsQuery.error}
        />
      </div>
    </div>
  );
};
```

---

## 10. Testing Strategy

### 10.1 Backend API Tests (pytest)

```python
# tests/test_dashboard_api.py
def test_dashboard_metrics_success(client: TestClient, rm_token: str):
    """Test dashboard metrics endpoint returns correct structure"""
    response = client.get(
        "/dashboard/metrics",
        headers={"Authorization": f"Bearer {rm_token}"}
    )
    assert response.status_code == 200
    data = response.json()
    assert "bench_count" in data
    assert "over_allocated_count" in data
    assert "open_demand_count" in data

def test_bench_employees_filtering(client: TestClient, rm_token: str):
    """Test bench employees can be filtered by skill"""
    response = client.get(
        "/dashboard/bench?skill=React",
        headers={"Authorization": f"Bearer {rm_token}"}
    )
    assert response.status_code == 200
    employees = response.json()
    
    # Verify all employees have React skill
    for employee in employees:
        skill_names = [skill["skill_name"] for skill in employee["skills"]]
        assert "React" in skill_names

def test_over_allocation_detection(client: TestClient, rm_token: str):
    """Test over-allocation detection returns only employees > 100%"""
    response = client.get(
        "/dashboard/over-allocations",
        headers={"Authorization": f"Bearer {rm_token}"}
    )
    assert response.status_code == 200
    over_allocated = response.json()
    
    for employee in over_allocated:
        assert employee["total_allocation_pct"] > 100
```

### 10.2 Frontend Component Tests

```typescript
// components/MetricCard.test.tsx
describe('MetricCard', () => {
  test('renders loading skeleton when loading', () => {
    render(<MetricCard title="Test" value={0} loading={true} />);
    expect(screen.getByRole('status')).toBeInTheDocument();
  });

  test('shows critical styling for critical urgency', () => {
    render(<MetricCard title="Test" value={150} urgency="critical" />);
    expect(screen.getByRole('article')).toHaveClass('border-red-500');
  });

  test('displays trend indicator when provided', () => {
    const trend = { change: 5, percentage: 15.2, period: '7d' };
    render(<MetricCard title="Test" value={50} trend={trend} />);
    expect(screen.getByText('15.2%')).toBeInTheDocument();
  });
});

// components/BenchPanel.test.tsx
describe('BenchPanel', () => {
  test('applies skill filter correctly', async () => {
    const mockEmployees = [
      { id: 1, name: 'Alice', skills: [{ skill_name: 'React' }] }
    ];
    
    mockApiResponse('/dashboard/bench', mockEmployees);
    
    render(<BenchPanel />);
    
    const skillFilter = screen.getByLabelText('Filter by skill');
    fireEvent.change(skillFilter, { target: { value: 'React' } });
    
    await waitFor(() => {
      expect(screen.getByText('Alice')).toBeInTheDocument();
    });
  });
});
```

---

## 11. Implementation Checklist

### Backend Implementation

- [ ] **routers/dashboard.py** — Dashboard endpoints with RBAC
- [ ] **services/dashboard_service.py** — Complex dashboard queries and metrics calculation
- [ ] **schemas/dashboard.py** — Pydantic response models for dashboard data
- [ ] **Database indexes** — Performance optimization for dashboard queries
- [ ] **tests/test_dashboard.py** — Complete API test suite

### Frontend Implementation

- [ ] **pages/DashboardPage.tsx** — Main dashboard page with parallel data loading
- [ ] **components/MetricCard.tsx** — Reusable metric display component
- [ ] **components/BenchPanel.tsx** — Bench employees panel with filtering
- [ ] **components/OverAllocationPanel.tsx** — Over-allocation alerts panel
- [ ] **components/DemandPanel.tsx** — Open demands panel
- [ ] **hooks/useDashboard.ts** — Dashboard-specific React Query hooks
- [ ] **components/skeletons/** — Loading skeleton components
- [ ] **tests/Dashboard.test.tsx** — Component test suite

### Performance & UX

- [ ] **Auto-refresh implementation** — 30-second automatic updates
- [ ] **Loading states** — Skeleton components for all panels
- [ ] **Error handling** — Partial failure recovery and retry logic
- [ ] **Responsive design** — Mobile-friendly dashboard layout
- [ ] **Cache optimization** — Appropriate stale times and invalidation
- [ ] **Performance monitoring** — Dashboard load time tracking

---

**Document Status:** APPROVED for implementation  
**Owner:** Architect  
**Reviewed:** 2026-05-22  
**Implementation Target:** Phase 2