# TDD: Roll-off Tracker
## Resource 360 — Technical Design Document
## TEG AI Adoption Pilot | Phase 1 Implementation

---

## 1. Overview

**Feature:** Proactive tracking of upcoming project allocations ending  
**Scope:** View employees rolling off projects in 30/60/90-day time windows  
**Primary Actors:** Resource Manager, Operations Manager (RBAC: no access for Solution Owner)  
**Core Purpose:** Prevent bench time by identifying upcoming capacity gaps  
**Key Metric:** Days remaining until allocation end_date  

---

## 2. Sequence Diagram

### GET /dashboard/rolloffs?days={window}

```mermaid
sequenceDiagram
    participant User as User (RM/OM)
    participant UI as React RolloffTracker
    participant API as FastAPI /dashboard/rolloffs
    participant JWT as JWT Middleware
    participant DB as SQLite Database

    User->>UI: Navigate to Roll-off Tracker
    UI->>API: GET /dashboard/rolloffs?days=30
    
    API->>JWT: Validate JWT token
    JWT->>JWT: Extract role claim
    
    alt Invalid token or Solution Owner
        JWT-->>API: 401 Unauthorized / 403 Forbidden
        API-->>UI: Error response
        UI-->>User: Show access denied
    else Valid RM/OM role
        JWT->>API: Proceed with authorized user
        
        API->>API: Validate days parameter
        Note right of API: days must be 30, 60, or 90
        
        alt Invalid days parameter
            API-->>UI: 422 {validation error}
            UI-->>User: Show parameter error
        else Valid days parameter
            API->>DB: SELECT rolloffs for time window
            Note right of DB: Complex query with JOINs:<br/>allocations + employees + projects<br/>WHERE is_active=1 AND end_date NOT NULL<br/>AND end_date BETWEEN now AND (now + days)
            
            DB-->>API: Rolloff records with calculated fields
            
            API->>API: Calculate derived fields
            Note right of API: days_remaining = end_date - today<br/>criticality_level based on days_remaining<br/>sort by days_remaining ASC
            
            API-->>UI: 200 {rolloff list with metadata}
            UI->>UI: Render time-boxed tabs
            UI-->>User: Display rolloffs with criticality indicators
        end
    end
```

---

## 3. API Specifications

### GET /dashboard/rolloffs

**Query Parameters:**
- `days` (required): Time window filter (30, 60, or 90)

**Success Response (200):**
```json
{
  "window_days": 30,
  "total_rolloffs": 5,
  "critical_count": 2,
  "rolloffs": [
    {
      "allocation_id": 42,
      "employee_id": 15,
      "employee_name": "Sneha Krishnan",
      "employee_email": "sneha.k@teg.com",
      "project_id": 10,
      "project_name": "Customer Portal Rebuild",
      "project_role": "Senior Developer",
      "allocation_pct": 80,
      "end_date": "2026-05-25",
      "days_remaining": 3,
      "criticality": "CRITICAL",
      "replacement_urgency": "IMMEDIATE"
    },
    {
      "allocation_id": 23,
      "employee_id": 8,
      "employee_name": "Arun Kumar",
      "employee_email": "arun.k@teg.com", 
      "project_id": 12,
      "project_name": "Legacy Migration",
      "project_role": "Tech Lead",
      "allocation_pct": 100,
      "end_date": "2026-06-15",
      "days_remaining": 24,
      "criticality": "HIGH",
      "replacement_urgency": "SOON"
    }
  ]
}
```

**Error Responses:**
```json
// 422 Invalid Parameter
{
  "error": "days parameter must be 30, 60, or 90",
  "code": "INVALID_PARAMETER",
  "field": "days"
}

// 403 Forbidden
{
  "error": "Only Resource Managers and Operations Managers can access rolloff tracker",
  "code": "FORBIDDEN",
  "field": null
}
```

---

## 4. RBAC Matrix

| Action | Resource Manager | Operations Manager | Solution Owner |
|---|---|---|---|
| GET /dashboard/rolloffs | ✅ | ✅ | ❌ (403) |
| View employee details from rolloff | ✅ (full) | ✅ (full) | ❌ |
| Navigate to replacement flow | ✅ | ❌ (read-only) | ❌ |

**Enforcement Point:** `middleware/auth.py` — JWT role claim validation  
**Business Rationale:** Solution Owners shouldn't see internal capacity planning data

---

## 5. Database Operations

### 5.1 Rolloff Query — 30 Days Window

```sql
-- Employees rolling off within next 30 days
SELECT 
    a.id as allocation_id,
    a.employee_id,
    e.name as employee_name,
    e.email as employee_email,
    a.project_id,
    p.name as project_name,
    a.project_role,
    a.allocation_pct,
    a.end_date,
    
    -- Calculate days remaining (critical business logic)
    CAST((JULIANDAY(a.end_date) - JULIANDAY('now')) as INTEGER) as days_remaining,
    
    -- Criticality classification
    CASE 
        WHEN a.end_date <= DATE('now') THEN 'OVERDUE'
        WHEN CAST((JULIANDAY(a.end_date) - JULIANDAY('now')) as INTEGER) <= 7 THEN 'CRITICAL'
        WHEN CAST((JULIANDAY(a.end_date) - JULIANDAY('now')) as INTEGER) <= 14 THEN 'HIGH'
        ELSE 'MEDIUM'
    END as criticality

FROM allocations a
INNER JOIN employees e ON a.employee_id = e.id
INNER JOIN projects p ON a.project_id = p.id

WHERE a.is_active = 1
  AND a.end_date IS NOT NULL
  AND a.end_date BETWEEN DATE('now') AND DATE('now', '+30 days')
  AND e.is_deleted = 0

ORDER BY a.end_date ASC, a.allocation_pct DESC;
```

### 5.2 Rolloff Query — 60 Days Window  

```sql
-- Employees rolling off within 31-60 days
SELECT 
    a.id as allocation_id,
    a.employee_id,
    e.name as employee_name,
    e.email as employee_email,
    a.project_id,
    p.name as project_name,
    a.project_role,
    a.allocation_pct,
    a.end_date,
    CAST((JULIANDAY(a.end_date) - JULIANDAY('now')) as INTEGER) as days_remaining,
    
    CASE 
        WHEN CAST((JULIANDAY(a.end_date) - JULIANDAY('now')) as INTEGER) <= 45 THEN 'MEDIUM'
        ELSE 'LOW'
    END as criticality

FROM allocations a
INNER JOIN employees e ON a.employee_id = e.id
INNER JOIN projects p ON a.project_id = p.id

WHERE a.is_active = 1
  AND a.end_date IS NOT NULL
  AND a.end_date BETWEEN DATE('now', '+31 days') AND DATE('now', '+60 days')
  AND e.is_deleted = 0

ORDER BY a.end_date ASC;
```

### 5.3 Rolloff Query — 90 Days Window

```sql
-- Employees rolling off within 61-90 days
SELECT 
    a.id as allocation_id,
    a.employee_id,
    e.name as employee_name,
    e.email as employee_email,
    a.project_id,
    p.name as project_name,
    a.project_role,
    a.allocation_pct,
    a.end_date,
    CAST((JULIANDAY(a.end_date) - JULIANDAY('now')) as INTEGER) as days_remaining,
    'LOW' as criticality

FROM allocations a
INNER JOIN employees e ON a.employee_id = e.id  
INNER JOIN projects p ON a.project_id = p.id

WHERE a.is_active = 1
  AND a.end_date IS NOT NULL
  AND a.end_date BETWEEN DATE('now', '+61 days') AND DATE('now', '+90 days')
  AND e.is_deleted = 0

ORDER BY a.end_date ASC;
```

### 5.4 Rolloff Summary Statistics

```sql
-- Dashboard summary metrics for rolloff tracker
SELECT 
    SUM(CASE WHEN a.end_date BETWEEN DATE('now') AND DATE('now', '+30 days') THEN 1 ELSE 0 END) as next_30_days,
    SUM(CASE WHEN a.end_date BETWEEN DATE('now', '+31 days') AND DATE('now', '+60 days') THEN 1 ELSE 0 END) as next_60_days,
    SUM(CASE WHEN a.end_date BETWEEN DATE('now', '+61 days') AND DATE('now', '+90 days') THEN 1 ELSE 0 END) as next_90_days,
    
    -- Critical rolloffs (within 7 days)
    SUM(CASE WHEN a.end_date BETWEEN DATE('now') AND DATE('now', '+7 days') THEN 1 ELSE 0 END) as critical_rolloffs,
    
    -- Overdue (past end date but still active)
    SUM(CASE WHEN a.end_date < DATE('now') THEN 1 ELSE 0 END) as overdue_rolloffs

FROM allocations a
INNER JOIN employees e ON a.employee_id = e.id

WHERE a.is_active = 1
  AND a.end_date IS NOT NULL
  AND e.is_deleted = 0;
```

### 5.5 Employee Multiple Rolloffs Query

```sql
-- Employees with multiple projects ending in same window
SELECT 
    e.id as employee_id,
    e.name as employee_name,
    COUNT(*) as rolloffs_count,
    SUM(a.allocation_pct) as total_capacity_freeing,
    GROUP_CONCAT(p.name) as affected_projects

FROM allocations a
INNER JOIN employees e ON a.employee_id = e.id
INNER JOIN projects p ON a.project_id = p.id

WHERE a.is_active = 1
  AND a.end_date IS NOT NULL
  AND a.end_date BETWEEN DATE('now') AND DATE('now', '+30 days')
  AND e.is_deleted = 0

GROUP BY e.id, e.name
HAVING COUNT(*) > 1

ORDER BY total_capacity_freeing DESC;
```

### 5.6 Overdue Rolloffs Detection

```sql
-- Allocations that should have ended but are still active
SELECT 
    a.id as allocation_id,
    e.name as employee_name,
    p.name as project_name,
    a.end_date,
    CAST((JULIANDAY('now') - JULIANDAY(a.end_date)) as INTEGER) as days_overdue,
    'OVERDUE' as criticality

FROM allocations a
INNER JOIN employees e ON a.employee_id = e.id
INNER JOIN projects p ON a.project_id = p.id

WHERE a.is_active = 1
  AND a.end_date IS NOT NULL
  AND a.end_date < DATE('now')
  AND e.is_deleted = 0

ORDER BY days_overdue DESC;
```

---

## 6. Validation Rules

| Rule | Implementation | Error Response |
|---|---|---|
| days: required parameter | FastAPI query parameter validation | 422 + "days parameter is required" |
| days: must be 30, 60, or 90 | Enum validation in schema | 422 + "days must be 30, 60, or 90" |
| User role: RM or OM only | JWT middleware validation | 403 + "FORBIDDEN" |
| Date calculations: handle timezone | Use UTC consistently | N/A (system consistency) |

---

## 7. Business Rules

### 7.1 Time Window Classification

| Days Remaining | Criticality | Color Code | Replacement Urgency |
|---|---|---|---|
| **≤ 0** (overdue) | OVERDUE | Red (urgent) | IMMEDIATE |
| **1-7** days | CRITICAL | Red | IMMEDIATE |
| **8-14** days | HIGH | Orange | SOON |
| **15-30** days | MEDIUM | Yellow | PLANNING |
| **31-90** days | LOW | Green | MONITORING |

### 7.2 Inclusion/Exclusion Rules

**Included in Rolloff Tracker:**
- ✅ Active allocations (`is_active = 1`)
- ✅ With definite end dates (`end_date IS NOT NULL`)
- ✅ Ending within specified time window
- ✅ Non-deleted employees (`is_deleted = 0`)

**Excluded from Rolloff Tracker:**
- ❌ Ongoing allocations (`end_date IS NULL`)
- ❌ Inactive allocations (`is_active = 0`)
- ❌ Allocations ending outside time window
- ❌ Soft-deleted employees

### 7.3 Multiple Rolloffs Handling

When an employee has multiple projects ending in the same window:
- Show as separate entries in the list
- Aggregate view available via summary query
- Total capacity being freed is sum of all allocation_pct

---

## 8. React Frontend Integration

### 8.1 RolloffTracker Component

```typescript
interface RolloffEntry {
  allocation_id: number;
  employee_id: number;
  employee_name: string;
  employee_email: string;
  project_id: number;
  project_name: string;
  project_role: string;
  allocation_pct: number;
  end_date: string;
  days_remaining: number;
  criticality: 'OVERDUE' | 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  replacement_urgency: 'IMMEDIATE' | 'SOON' | 'PLANNING' | 'MONITORING';
}

interface RolloffResponse {
  window_days: 30 | 60 | 90;
  total_rolloffs: number;
  critical_count: number;
  rolloffs: RolloffEntry[];
}

interface RolloffTrackerProps {
  defaultWindow?: 30 | 60 | 90;
}
```

### 8.2 React Query Hook

```typescript
const useRolloffTracker = (windowDays: 30 | 60 | 90) => {
  return useQuery({
    queryKey: ['rolloffs', windowDays],
    queryFn: () => api.get(`/dashboard/rolloffs?days=${windowDays}`),
    staleTime: 60 * 1000, // 1 minute (relatively static data)
    refetchInterval: 5 * 60 * 1000, // Auto-refresh every 5 minutes
    enabled: windowDays != null
  });
};

const useRolloffSummary = () => {
  return useQuery({
    queryKey: ['rolloffs', 'summary'],
    queryFn: () => api.get('/dashboard/rolloffs/summary'),
    staleTime: 2 * 60 * 1000 // 2 minutes for summary stats
  });
};
```

### 8.3 Time Window Tabs Component

```typescript
const RolloffTabs: React.FC = () => {
  const [activeWindow, setActiveWindow] = useState<30 | 60 | 90>(30);
  const { data: rolloffs, isLoading, error } = useRolloffTracker(activeWindow);
  const { data: summary } = useRolloffSummary();

  return (
    <div className="rolloff-tracker">
      <div className="window-tabs">
        <TabButton
          active={activeWindow === 30}
          onClick={() => setActiveWindow(30)}
          badge={summary?.next_30_days}
          urgent={summary?.critical_rolloffs > 0}
        >
          Next 30 Days
        </TabButton>
        <TabButton
          active={activeWindow === 60}
          onClick={() => setActiveWindow(60)}
          badge={summary?.next_60_days}
        >
          31-60 Days  
        </TabButton>
        <TabButton
          active={activeWindow === 90}
          onClick={() => setActiveWindow(90)}
          badge={summary?.next_90_days}
        >
          61-90 Days
        </TabButton>
      </div>

      <div className="rolloff-list">
        {rolloffs?.rolloffs.map(rolloff => (
          <RolloffCard key={rolloff.allocation_id} rolloff={rolloff} />
        ))}
      </div>
    </div>
  );
};
```

### 8.4 Criticality Display Component

```typescript
const CriticalityIndicator: React.FC<{
  criticality: RolloffEntry['criticality'];
  daysRemaining: number;
}> = ({ criticality, daysRemaining }) => {
  const getIndicatorStyle = () => {
    switch (criticality) {
      case 'OVERDUE':
      case 'CRITICAL':
        return 'bg-red-500 text-white animate-pulse';
      case 'HIGH':
        return 'bg-orange-500 text-white';
      case 'MEDIUM':
        return 'bg-yellow-500 text-black';
      case 'LOW':
        return 'bg-green-500 text-white';
    }
  };

  const getDisplayText = () => {
    if (daysRemaining <= 0) return 'OVERDUE';
    if (daysRemaining === 1) return '1 day';
    return `${daysRemaining} days`;
  };

  return (
    <span className={`px-3 py-1 rounded-full text-sm font-medium ${getIndicatorStyle()}`}>
      {getDisplayText()}
    </span>
  );
};
```

---

## 9. Edge Cases

### 9.1 Critical Timing Edge Cases

| Test Case | Input | Expected Result | Criticality |
|---|---|---|---|
| **End date = today (0 days remaining)** | end_date: "2026-05-22" | ✅ Show as CRITICAL | OVERDUE/CRITICAL |
| **End date = tomorrow (1 day)** | end_date: "2026-05-23" | ✅ Show as CRITICAL | CRITICAL |
| **End date = exactly 7 days** | end_date: "2026-05-29" | ✅ Show as CRITICAL | CRITICAL |
| **End date = exactly 30 days** | end_date: "2026-06-21" | ✅ Show in 30-day window | MEDIUM |
| **End date = 31 days** | end_date: "2026-06-22" | ✅ Show in 60-day window | MEDIUM |

### 9.2 NULL End Date Handling

| Test Case | Allocation State | Expected Result | Rationale |
|---|---|---|---|
| **end_date = NULL (ongoing)** | is_active=1, end_date=NULL | ❌ EXCLUDED from tracker | No planned rolloff |
| **Project with indefinite duration** | end_date=NULL | ❌ EXCLUDED from tracker | Cannot calculate days_remaining |
| **Mixed allocations for same employee** | Some NULL, some with dates | ✅ Show only dated allocations | Partial tracking |

### 9.3 Project Changes Edge Cases  

| Test Case | Scenario | Expected Result | System Behavior |
|---|---|---|---|
| **Project end date extended** | end_date updated from 2026-05-25 to 2026-06-25 | ✅ Moves to different time window | Next query reflects change |
| **Project canceled mid-flight** | project.status = 'CANCELLED' | ✅ Still shows in tracker | allocation.is_active controls visibility |
| **Allocation deactivated** | is_active set to 0 | ❌ EXCLUDED from tracker | Immediate removal |
| **New end_date set during project** | NULL → specific date | ✅ Appears in appropriate window | Next refresh shows it |

### 9.4 Multiple Rolloffs Edge Cases

| Test Case | Employee State | Expected Result | Display Strategy |
|---|---|---|---|
| **Same employee, two projects ending within 30 days** | 2 active allocations ending | ✅ Show as 2 separate entries | Individual project cards |
| **Employee at 40% + 60% both ending** | Total 100% capacity freeing | ✅ Show capacity impact | Aggregate view option |
| **Staggered rolloffs (day 5 and day 25)** | Different criticality levels | ✅ Different criticality indicators | Sort by end_date |

### 9.5 Overdue Rolloffs Edge Cases

| Test Case | Allocation State | Expected Result | Action Required |
|---|---|---|---|
| **Roll-off date 1 week in past** | end_date: "2026-05-15", is_active=1 | ✅ Show as OVERDUE | Manual intervention needed |
| **Roll-off date 30 days in past** | end_date: "2026-04-22", is_active=1 | ✅ Show as OVERDUE | Data cleanup needed |
| **Project extended but allocation not updated** | Project ongoing, allocation shows past end | ⚠️ Business rule violation | Process gap |

**Overdue Handling Strategy:**
- Include overdue allocations in rolloff tracker with OVERDUE criticality
- Separate "Overdue Actions Needed" section in UI
- Alert Resource Managers about data inconsistencies
- Provide quick action to update end_date or deactivate allocation

### 9.6 Timezone and Date Calculation Edge Cases

| Test Case | Scenario | Expected Result | Technical Consideration |
|---|---|---|---|
| **Calculation at midnight boundary** | Query run at 23:59:59 vs 00:00:01 | ✅ Consistent day calculation | Use DATE() function, not DATETIME |
| **Leap year calculation** | end_date in leap year | ✅ Accurate day count | JULIANDAY handles leap years |
| **Cross-month boundary** | 30 days from Jan 31 | ✅ Handles variable month lengths | Date arithmetic handles this |

---

## 10. Performance Considerations

### 10.1 Database Indexes

```sql
-- Critical for rolloff queries (most important)
CREATE INDEX idx_allocations_end_date_active ON allocations(end_date, is_active) WHERE end_date IS NOT NULL;

-- Supporting indexes for JOIN performance
CREATE INDEX idx_allocations_employee_active ON allocations(employee_id, is_active);
CREATE INDEX idx_employees_is_deleted ON employees(is_deleted);
CREATE INDEX idx_projects_status ON projects(status);

-- Composite index for complex rolloff queries
CREATE INDEX idx_rolloff_window ON allocations(is_active, end_date) WHERE end_date IS NOT NULL;
```

### 10.2 Query Optimization

- **Single window query:** Optimized date range with proper indexing
- **Avoid N+1 queries:** Use JOINs to fetch all data in one query
- **Date calculations in SQL:** Use JULIANDAY for consistent day calculations
- **Result set size:** Typically small (dozens, not hundreds)

### 10.3 Caching Strategy

- **React Query:** 1-minute stale time (rolloff dates change infrequently)
- **Auto-refresh:** 5-minute intervals for real-time awareness
- **Summary metrics:** 2-minute cache (used across multiple components)
- **No server-side caching:** Data is relatively static and queries are fast

---

## 11. Testing Strategy

### 11.1 Unit Tests (pytest)

```python
# tests/test_rolloff_service.py
def test_rolloff_30_day_window():
    """Test 30-day rolloff query accuracy"""

def test_rolloff_exclude_null_end_dates():
    """Test NULL end_date exclusion"""

def test_days_remaining_calculation():
    """Test date arithmetic for days_remaining"""

def test_criticality_classification():
    """Test criticality assignment logic"""

def test_multiple_rolloffs_same_employee():
    """Test employee with multiple ending allocations"""

def test_overdue_rolloffs_detection():
    """Test past end_date handling"""
```

### 11.2 Integration Tests (pytest + httpx)

```python
# tests/test_rolloff_api.py
def test_get_rolloffs_30_days():
    """Test complete 30-day rolloff endpoint"""

def test_get_rolloffs_invalid_days():
    """Test validation for invalid days parameter"""

def test_rolloff_rbac_restrictions():
    """Test access control for different roles"""

def test_rolloff_empty_result():
    """Test response when no rolloffs in window"""

def test_rolloff_summary_metrics():
    """Test dashboard summary endpoint"""
```

### 11.3 Frontend Tests (Vitest + React Testing Library)

```typescript
// components/RolloffTracker.test.tsx
describe('RolloffTracker', () => {
  test('renders tabs for different time windows');
  test('displays criticality indicators correctly');
  test('shows empty state when no rolloffs');
  test('handles multiple rolloffs for same employee');
  test('updates data on tab change');
});

// components/CriticalityIndicator.test.tsx
describe('CriticalityIndicator', () => {
  test('shows OVERDUE for past dates');
  test('shows CRITICAL for <= 7 days');
  test('animates critical indicators');
  test('uses correct colors for each level');
});
```

---

## 12. Implementation Checklist

### Backend Implementation

- [ ] **routers/dashboard.py** — Rolloff tracker endpoint
- [ ] **services/rolloff_service.py** — Business logic and complex queries
- [ ] **schemas/rolloff.py** — Pydantic response schemas
- [ ] **middleware/auth.py** — RBAC enforcement for RM/OM only
- [ ] **tests/test_rolloff.py** — Complete test suite including edge cases

### Frontend Implementation

- [ ] **components/RolloffTracker.tsx** — Main rolloff tracker component
- [ ] **components/RolloffCard.tsx** — Individual rolloff display component
- [ ] **components/CriticalityIndicator.tsx** — Criticality display with styling
- [ ] **components/RolloffTabs.tsx** — Time window navigation
- [ ] **api/rolloffs.ts** — React Query hooks
- [ ] **types/rolloff.ts** — TypeScript interfaces
- [ ] **tests/RolloffTracker.test.tsx** — Component tests

### Database & Performance

- [ ] **Database indexes** — Optimized for date range queries
- [ ] **Date calculation functions** — Consistent timezone handling
- [ ] **Overdue rolloff alerts** — Automated detection system
- [ ] **Performance monitoring** — Query performance for large datasets

---

**Document Status:** APPROVED for implementation  
**Owner:** Architect  
**Reviewed:** 2026-05-22  
**Implementation Target:** Phase 2