# TDD: Allocation Management
## Resource 360 — Technical Design Document
## TEG AI Adoption Pilot | Phase 1 Implementation

---

## 1. Overview

**Feature:** Employee project allocation with percentage-based capacity management  
**Scope:** Create, update, and validate allocations with strict 100% capacity enforcement  
**Primary Actor:** Resource Manager (RBAC: RESOURCE_MANAGER only)  
**Core Constraint:** `SUM(allocation_pct) WHERE employee_id = X AND is_active = 1` MUST NOT exceed 100  

---

## 2. Sequence Diagram

```mermaid
sequenceDiagram
    participant RM as Resource Manager
    participant UI as React AllocationForm
    participant API as FastAPI /allocations
    participant JWT as JWT Middleware
    participant DB as SQLite Database
    participant EMP as Employee Service

    RM->>UI: Submit allocation form
    UI->>API: POST /allocations
    Note right of UI: {employee_id, project_id, project_role, allocation_pct, start_date, end_date}
    
    API->>JWT: Validate JWT token
    JWT->>JWT: Extract role claim
    
    alt Invalid token or wrong role
        JWT-->>API: 401 Unauthorized / 403 Forbidden
        API-->>UI: Error response
        UI-->>RM: Show error message
    else Valid RESOURCE_MANAGER
        JWT->>API: Proceed with authorized user
        
        API->>DB: SELECT SUM(allocation_pct) FROM allocations<br/>WHERE employee_id = ? AND is_active = 1
        DB-->>API: current_sum (integer)
        
        alt Over-allocation check
            Note right of API: if current_sum + new_allocation_pct > 100
            API-->>UI: 422 {"error": "Over-allocation", "code": "OVER_ALLOCATION"}
            UI-->>RM: Show validation error
        else Valid allocation
            API->>DB: INSERT INTO allocations<br/>(employee_id, project_id, project_role, allocation_pct,<br/>start_date, end_date, is_active)
            DB-->>API: allocation_id
            
            API->>EMP: Update bench status
            EMP->>DB: UPDATE employees SET bench_status = 'ALLOCATED'<br/>WHERE id = ? AND bench_status != 'ON_LEAVE'
            DB-->>EMP: Updated
            
            API-->>UI: 201 {allocation object}
            UI-->>RM: Success confirmation + refresh data
        end
    end
```

---

## 3. API Specification

### POST /allocations

**Request Schema:**
```json
{
  "employee_id": 1,
  "project_id": 10,
  "project_role": "Senior Developer",
  "allocation_pct": 80,
  "start_date": "2026-06-01",
  "end_date": "2026-09-01"
}
```

**Success Response (201):**
```json
{
  "id": 42,
  "employee_id": 1,
  "project_id": 10,
  "project_name": "Customer Portal Rebuild",
  "project_role": "Senior Developer",
  "allocation_pct": 80,
  "start_date": "2026-06-01",
  "end_date": "2026-09-01",
  "is_active": true
}
```

**Error Response (422) — Over-allocation:**
```json
{
  "error": "Employee allocation would exceed 100%. Current: 75%, Requested: 30%, Total: 105%",
  "code": "OVER_ALLOCATION",
  "field": "allocation_pct"
}
```

### PATCH /allocations/{id}

**Request Schema:**
```json
{
  "end_date": "2026-07-15",
  "is_active": false
}
```

**Success Response (200):**
```json
{
  "id": 42,
  "end_date": "2026-07-15",
  "is_active": false
}
```

---

## 4. RBAC Matrix

| Action | Resource Manager | Operations Manager | Solution Owner |
|---|---|---|---|
| POST /allocations | ✅ | ❌ (403) | ❌ (403) |
| PATCH /allocations/{id} | ✅ | ❌ (403) | ❌ (403) |
| GET /allocations (via employee profile) | ✅ | ✅ | ✅ (limited) |

**Enforcement Point:** `middleware/auth.py` — JWT role claim validation before router execution

---

## 5. Database Operations

### 5.1 Pre-allocation Validation Query

```sql
-- Check current allocation sum before INSERT
SELECT COALESCE(SUM(allocation_pct), 0) as current_total
FROM allocations 
WHERE employee_id = ? 
  AND is_active = 1
  AND (end_date IS NULL OR end_date >= CURRENT_DATE);
```

### 5.2 Allocation Creation

```sql
-- Create new allocation record
INSERT INTO allocations (
    employee_id, 
    project_id, 
    project_role, 
    allocation_pct, 
    start_date, 
    end_date, 
    is_active,
    created_at
) VALUES (?, ?, ?, ?, ?, ?, 1, CURRENT_TIMESTAMP);
```

### 5.3 Employee Bench Status Update

```sql
-- Update employee status to ALLOCATED (unless ON_LEAVE)
UPDATE employees 
SET bench_status = 'ALLOCATED'
WHERE id = ? 
  AND bench_status IN ('BENCH', 'ROLLING_OFF')
  AND is_deleted = 0;
```

### 5.4 Over-allocation Detection for Dashboard

```sql
-- Find employees with total allocation > 100% for dashboard alerts
SELECT 
    e.id,
    e.name,
    e.email,
    SUM(a.allocation_pct) as total_allocation,
    COUNT(a.id) as active_projects
FROM employees e
INNER JOIN allocations a ON e.id = a.employee_id
WHERE a.is_active = 1
  AND (a.end_date IS NULL OR a.end_date >= CURRENT_DATE)
  AND e.is_deleted = 0
GROUP BY e.id, e.name, e.email
HAVING SUM(a.allocation_pct) > 100
ORDER BY total_allocation DESC;
```

### 5.5 Allocation End/Deactivation

```sql
-- Update allocation end date or deactivate
UPDATE allocations 
SET end_date = ?, is_active = ?
WHERE id = ?;

-- Check if employee should return to bench status
SELECT COUNT(*) as active_allocations
FROM allocations 
WHERE employee_id = ? 
  AND is_active = 1
  AND (end_date IS NULL OR end_date >= CURRENT_DATE);

-- If active_allocations = 0, update employee bench status
UPDATE employees 
SET bench_status = 'BENCH'
WHERE id = ? 
  AND bench_status = 'ALLOCATED'
  AND is_deleted = 0;
```

---

## 6. Validation Rules

| Rule | Implementation | Error Response |
|---|---|---|
| allocation_pct: 1-100 | Pydantic schema validation | 422 + field validation error |
| start_date: required | Pydantic schema validation | 422 + field validation error |
| end_date ≥ start_date | Custom validator in schema | 422 + "end_date must be after start_date" |
| employee_id exists | Foreign key + DB query | 422 + "Employee not found" |
| project_id exists | Foreign key + DB query | 422 + "Project not found" |
| Sum(allocation) ≤ 100% | Business logic in router | 422 + "OVER_ALLOCATION" code |
| Employee not ON_LEAVE | Business logic check | 422 + "Cannot allocate employee on leave" |

---

## 7. Error Handling

### Application-Level Errors

```python
class AllocationError(Exception):
    """Allocation-specific business logic errors"""
    pass

class OverAllocationError(AllocationError):
    def __init__(self, current_pct: int, requested_pct: int):
        self.current_pct = current_pct
        self.requested_pct = requested_pct
        self.total_pct = current_pct + requested_pct
        super().__init__(f"Over-allocation: current={current_pct}%, requested={requested_pct}%, total={self.total_pct}%")

class EmployeeOnLeaveError(AllocationError):
    def __init__(self, employee_id: int):
        super().__init__(f"Cannot allocate employee {employee_id}: currently on leave")
```

### Error Response Format (Standardised)

```python
{
    "error": "Human-readable error message",
    "code": "MACHINE_READABLE_CODE",
    "field": "field_name_if_applicable"  # null for business logic errors
}
```

---

## 8. React Frontend Integration

### 8.1 AllocationForm Component

```typescript
interface AllocationFormData {
  employee_id: number;
  project_id: number;
  project_role: string;
  allocation_pct: number;
  start_date: string;
  end_date?: string;
}

interface AllocationFormProps {
  employee: Employee;
  onSuccess: () => void;
  onCancel: () => void;
}
```

### 8.2 React Query Mutation

```typescript
const createAllocationMutation = useMutation({
  mutationFn: (data: AllocationFormData) => 
    api.post('/allocations', data),
  onSuccess: () => {
    queryClient.invalidateQueries(['employees', employee.id]);
    queryClient.invalidateQueries(['dashboard', 'metrics']);
    onSuccess();
  },
  onError: (error: ApiError) => {
    if (error.code === 'OVER_ALLOCATION') {
      setFieldError('allocation_pct', error.message);
    }
  }
});
```

### 8.3 Real-time Allocation Display

```typescript
// Calculate remaining allocation capacity in real-time
const remainingCapacity = useMemo(() => {
  const currentTotal = employee.allocations
    .filter(a => a.is_active)
    .reduce((sum, a) => sum + a.allocation_pct, 0);
  return 100 - currentTotal;
}, [employee.allocations]);

// Show warning if trying to exceed
const showOverallocationWarning = formData.allocation_pct > remainingCapacity;
```

---

## 9. Edge Cases

### 9.1 Allocation Percentage Edge Cases

| Test Case | Input | Expected Result | Status Code |
|---|---|---|---|
| **Exactly 100% (fresh employee)** | employee has 0%, request 100% | ✅ Allow | 201 |
| **Exactly 100% (partial + partial)** | employee has 60%, request 40% | ✅ Allow | 201 |
| **101% (single allocation)** | employee has 0%, request 101% | ❌ Block | 422 |
| **101% (over by 1%)** | employee has 100%, request 1% | ❌ Block | 422 |
| **101% (partial overflow)** | employee has 60%, request 41% | ❌ Block | 422 |
| **Edge case: 99% + 1%** | employee has 99%, request 1% | ✅ Allow | 201 |
| **Edge case: 50% + 50%** | employee has 50%, request 50% | ✅ Allow | 201 |

### 9.2 Employee Status Edge Cases

| Test Case | Employee Status | Expected Result | Status Code |
|---|---|---|---|
| **Employee ON_LEAVE** | bench_status = 'ON_LEAVE' | ❌ Block allocation | 422 |
| **Employee BENCH** | bench_status = 'BENCH' | ✅ Allow, update to ALLOCATED | 201 |
| **Employee ALLOCATED** | bench_status = 'ALLOCATED' | ✅ Allow if capacity available | 201/422 |
| **Employee ROLLING_OFF** | bench_status = 'ROLLING_OFF' | ✅ Allow, update to ALLOCATED | 201 |
| **Soft-deleted employee** | is_deleted = 1 | ❌ Block | 404 |

### 9.3 Date Validation Edge Cases

| Test Case | Input | Expected Result | Status Code |
|---|---|---|---|
| **end_date before start_date** | start: 2026-06-01, end: 2026-05-01 | ❌ Block | 422 |
| **end_date same as start_date** | start: 2026-06-01, end: 2026-06-01 | ✅ Allow (1 day allocation) | 201 |
| **end_date null (indefinite)** | start: 2026-06-01, end: null | ✅ Allow | 201 |
| **start_date in the past** | start: 2026-01-01 (past date) | ✅ Allow (historical allocation) | 201 |
| **Invalid date format** | start: "invalid-date" | ❌ Block | 422 |

### 9.4 Foreign Key Edge Cases

| Test Case | Input | Expected Result | Status Code |
|---|---|---|---|
| **Non-existent employee_id** | employee_id: 999999 | ❌ Block | 422 |
| **Non-existent project_id** | project_id: 999999 | ❌ Block | 422 |
| **Cancelled project** | project.status = 'CANCELLED' | ❌ Block | 422 |
| **Completed project** | project.status = 'COMPLETED' | ❌ Block | 422 |
| **On-hold project** | project.status = 'ON_HOLD' | ✅ Allow (contingent allocation) | 201 |

---

## 10. Performance Considerations

### 10.1 Database Indexes (Already Implemented)

```sql
-- Critical for allocation sum queries
CREATE INDEX idx_allocations_employee_active ON allocations(employee_id, is_active);

-- Critical for dashboard over-allocation detection
CREATE INDEX idx_allocations_end_date ON allocations(end_date, is_active);

-- Critical for employee status updates
CREATE INDEX idx_employees_bench_status ON employees(bench_status) WHERE is_deleted = 0;
```

### 10.2 Query Optimisation

- **Allocation sum query:** Single query with COALESCE handles null case
- **Dashboard over-allocation:** Single aggregation query, not N+1
- **Employee status update:** Single UPDATE with WHERE conditions

### 10.3 Caching Strategy

- **React Query:** 5-minute cache for employee profile data
- **API Response:** No server-side caching (data changes frequently)
- **Dashboard metrics:** 1-minute cache for aggregate data

---

## 11. Testing Strategy

### 11.1 Unit Tests (pytest)

```python
# tests/test_allocation_service.py
def test_calculate_current_allocation():
    """Test allocation percentage calculation"""

def test_over_allocation_validation():
    """Test business rule: sum <= 100%"""

def test_employee_status_update():
    """Test bench_status transitions"""

def test_allocation_creation():
    """Test successful allocation creation"""
```

### 11.2 Integration Tests (pytest + httpx)

```python
# tests/test_allocations_api.py
def test_post_allocation_success():
    """Test full allocation creation flow"""

def test_post_allocation_over_allocation():
    """Test over-allocation prevention"""

def test_allocation_rbac():
    """Test RBAC enforcement on allocation endpoints"""
```

### 11.3 Frontend Tests (Vitest + React Testing Library)

```typescript
// components/AllocationForm.test.tsx
describe('AllocationForm', () => {
  test('shows over-allocation warning');
  test('displays remaining capacity');
  test('validates form fields');
  test('handles API errors');
});
```

---

## 12. Implementation Checklist

### Backend Implementation

- [ ] **models/allocation.py** — SQLAlchemy allocation model
- [ ] **schemas/allocation.py** — Pydantic request/response schemas
- [ ] **routers/allocations.py** — FastAPI endpoints with RBAC
- [ ] **services/allocation_service.py** — Business logic and validation
- [ ] **middleware/auth.py** — JWT role validation
- [ ] **tests/test_allocations.py** — Complete test suite

### Frontend Implementation

- [ ] **components/AllocationForm.tsx** — React form component
- [ ] **api/allocations.ts** — React Query hooks
- [ ] **types/allocation.ts** — TypeScript interfaces
- [ ] **components/AllocationTable.tsx** — Display component
- [ ] **tests/AllocationForm.test.tsx** — Component tests

### Database

- [ ] **schema.sql** — Allocation table with constraints
- [ ] **seed/allocations_seed.py** — Test allocation data
- [ ] **Database indexes** — Performance optimisation

---

**Document Status:** APPROVED for implementation  
**Owner:** Architect  
**Reviewed:** 2026-05-22  
**Implementation Target:** Phase 2