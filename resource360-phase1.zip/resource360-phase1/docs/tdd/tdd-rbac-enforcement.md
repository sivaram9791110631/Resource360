# TDD: RBAC Enforcement
## Resource 360 — Technical Design Document  
## TEG AI Adoption Pilot | Phase 1 Implementation

---

## 1. Overview

**Feature:** Role-Based Access Control (RBAC) enforcement across all API endpoints  
**Scope:** JWT-based authentication with role claim validation  
**Security Model:** Resource Manager, Operations Manager, Solution Owner role hierarchy  
**Enforcement Points:** Backend middleware + Frontend route guards  
**Token Standard:** JWT (python-jose) with httpOnly cookies  
**Core Principle:** Deny by default, explicit allow by role  

---

## 2. Sequence Diagram

### JWT Middleware Authentication & Authorization Flow

```mermaid
sequenceDiagram
    participant Client as Client (React/Postman)
    participant Middleware as JWT Middleware
    participant Decoder as JWT Decoder (python-jose)
    participant Handler as Route Handler
    participant DB as Database

    Client->>Middleware: HTTP Request with Authorization header
    Note right of Client: Authorization: Bearer <jwt_token>
    
    Middleware->>Middleware: Extract Bearer token from header
    
    alt No token provided
        Middleware-->>Client: 401 {"error": "Unauthorized", "code": "MISSING_TOKEN"}
    else Token provided
        Middleware->>Decoder: Decode JWT token
        
        alt Invalid signature
            Decoder-->>Middleware: JWTError (signature verification failed)
            Middleware-->>Client: 401 {"error": "Invalid token", "code": "INVALID_SIGNATURE"}
        else Valid signature
            Decoder-->>Middleware: Decoded payload with claims
            
            Middleware->>Middleware: Extract role claim from payload
            Note right of Middleware: role = payload.get('role')
            
            alt Missing role claim
                Middleware-->>Client: 401 {"error": "Missing role", "code": "MISSING_ROLE_CLAIM"}
            else Role claim present
                Middleware->>Middleware: Check expiry (exp claim)
                
                alt Token expired
                    Middleware-->>Client: 401 {"error": "Token expired", "code": "TOKEN_EXPIRED"}
                else Token valid
                    Middleware->>Middleware: Check role against endpoint requirements
                    Note right of Middleware: required_roles = get_endpoint_roles(request.url, request.method)
                    
                    alt Role not in required_roles
                        Middleware-->>Client: 403 {"error": "Forbidden", "code": "RBAC_VIOLATION"}
                    else Role permitted
                        Middleware->>Handler: Forward request with user context
                        Note right of Handler: request.user = {id, email, role, name}
                        
                        Handler->>DB: Execute business logic
                        DB-->>Handler: Query results
                        Handler-->>Client: 200/201 Success response
                    end
                end
            end
        end
    end
```

---

## 3. JWT Token Structure

### 3.1 JWT Payload Claims

```json
{
  "sub": "user@teg.com",
  "user_id": 1,
  "email": "user@teg.com", 
  "name": "John Smith",
  "role": "RESOURCE_MANAGER",
  "iat": 1716380400,
  "exp": 1716466800,
  "iss": "resource360-pilot"
}
```

### 3.2 JWT Header

```json
{
  "alg": "HS256",
  "typ": "JWT"
}
```

### 3.3 Token Generation (Login Endpoint)

```python
def create_access_token(user: User) -> str:
    payload = {
        "sub": user.email,
        "user_id": user.id,
        "email": user.email,
        "name": user.name,
        "role": user.role,
        "iat": datetime.utcnow(),
        "exp": datetime.utcnow() + timedelta(hours=24),
        "iss": "resource360-pilot"
    }
    return jwt.encode(payload, settings.SECRET_KEY, algorithm="HS256")
```

---

## 4. Middleware Implementation

### 4.1 JWT Authentication Middleware

```python
from fastapi import HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from typing import List, Optional

security = HTTPBearer()

class RoleChecker:
    def __init__(self, allowed_roles: List[str]):
        self.allowed_roles = allowed_roles

    def __call__(self, credentials: HTTPAuthorizationCredentials = Depends(security)):
        try:
            # Decode JWT token
            payload = jwt.decode(
                credentials.credentials, 
                settings.SECRET_KEY, 
                algorithms=["HS256"]
            )
            
            # Extract user information
            user_email = payload.get("sub")
            user_role = payload.get("role")
            user_id = payload.get("user_id")
            user_name = payload.get("name")
            
            if not all([user_email, user_role, user_id]):
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail={
                        "error": "Invalid token claims",
                        "code": "INVALID_CLAIMS"
                    }
                )
            
            # Check role authorization
            if user_role not in self.allowed_roles:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail={
                        "error": f"Access denied. Required roles: {', '.join(self.allowed_roles)}. Your role: {user_role}",
                        "code": "RBAC_VIOLATION",
                        "required_roles": self.allowed_roles,
                        "user_role": user_role
                    }
                )
            
            # Return user context
            return {
                "id": user_id,
                "email": user_email,
                "name": user_name, 
                "role": user_role
            }
            
        except jwt.ExpiredSignatureError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "error": "Token has expired",
                    "code": "TOKEN_EXPIRED"
                }
            )
        except JWTError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "error": "Invalid token",
                    "code": "INVALID_TOKEN"
                }
            )

# Role-specific dependencies
require_resource_manager = RoleChecker(["RESOURCE_MANAGER"])
require_operations_manager = RoleChecker(["OPERATIONS_MANAGER"])
require_solution_owner = RoleChecker(["SOLUTION_OWNER"])
require_rm_or_om = RoleChecker(["RESOURCE_MANAGER", "OPERATIONS_MANAGER"])
require_any_role = RoleChecker(["RESOURCE_MANAGER", "OPERATIONS_MANAGER", "SOLUTION_OWNER"])
```

### 4.2 Router-Level RBAC Application

```python
from fastapi import APIRouter, Depends

router = APIRouter()

@router.post("/employees")
async def create_employee(
    employee_data: CreateEmployeeRequest,
    current_user: dict = Depends(require_resource_manager)
):
    """Only Resource Manager can create employees"""
    pass

@router.get("/dashboard/bench")
async def get_bench_dashboard(
    current_user: dict = Depends(require_rm_or_om)
):
    """Resource Manager and Operations Manager can view bench dashboard"""
    pass

@router.post("/demand-requests")
async def create_demand_request(
    demand_data: CreateDemandRequest,
    current_user: dict = Depends(require_solution_owner)
):
    """Only Solution Owner can create demand requests"""
    pass
```

---

## 5. Complete Permission Matrix Table

| Endpoint | Method | Resource Manager | Operations Manager | Solution Owner | Unauthenticated |
|---|---|---|---|---|---|
| **Authentication** |||||
| `/auth/login` | POST | ✅ | ✅ | ✅ | ✅ |
| `/auth/me` | GET | ✅ | ✅ | ✅ | ❌ 401 |
| **Employee Management** |||||
| `/employees` | GET | ✅ | ✅ | ✅* | ❌ 401 |
| `/employees` | POST | ✅ | ❌ 403 | ❌ 403 | ❌ 401 |
| `/employees/{id}` | GET | ✅ | ✅ | ✅* | ❌ 401 |
| `/employees/{id}` | PATCH | ✅ | ❌ 403 | ❌ 403 | ❌ 401 |
| `/employees/{id}` | DELETE | ✅ | ❌ 403 | ❌ 403 | ❌ 401 |
| `/employees/{id}/skills` | POST | ✅ | ❌ 403 | ❌ 403 | ❌ 401 |
| `/employees/{id}/skills/{skill_id}` | DELETE | ✅ | ❌ 403 | ❌ 403 | ❌ 401 |
| **Allocation Management** |||||
| `/allocations` | POST | ✅ | ❌ 403 | ❌ 403 | ❌ 401 |
| `/allocations/{id}` | PATCH | ✅ | ❌ 403 | ❌ 403 | ❌ 401 |
| **Demand Requests** |||||
| `/demand-requests` | GET | ✅ | ✅ | ✅** | ❌ 401 |
| `/demand-requests` | POST | ❌ 403 | ❌ 403 | ✅ | ❌ 401 |
| `/demand-requests/{id}/fulfil` | POST | ✅ | ❌ 403 | ❌ 403 | ❌ 401 |
| `/demand-requests/{id}/decline` | POST | ✅ | ❌ 403 | ❌ 403 | ❌ 401 |
| **Dashboard & Analytics** |||||
| `/dashboard/bench` | GET | ✅ | ✅ | ❌ 403 | ❌ 401 |
| `/dashboard/rolloffs` | GET | ✅ | ✅ | ❌ 403 | ❌ 401 |
| `/dashboard/over-allocations` | GET | ✅ | ✅ | ❌ 403 | ❌ 401 |
| `/dashboard/metrics` | GET | ✅ | ✅ | ❌ 403 | ❌ 401 |
| **AI Features** |||||
| `/ai/suggestions/{demand_id}` | GET | ✅ | ❌ 403 | ❌ 403 | ❌ 401 |
| `/ai/readiness/{employee_id}/{demand_id}` | GET | ✅ | ❌ 403 | ❌ 403 | ❌ 401 |

**Notes:**
- `*` Solution Owner gets limited field view (no email, bench_status, allocation details)
- `**` Solution Owner sees only their own demand requests (scoped query)
- `✅` = Allowed
- `❌ 403` = Forbidden (role insufficient) 
- `❌ 401` = Unauthorized (authentication required)

---

## 6. Role Hierarchy & Permissions

### 6.1 Role Definitions

| Role | Primary Responsibility | Key Permissions |
|---|---|---|
| **Resource Manager** | Employee allocation and capacity management | Create/edit employees, manage allocations, fulfill demands, view all dashboards, access AI features |
| **Operations Manager** | Visibility and reporting | View employees, view dashboards, see demand requests, no create/edit capabilities |
| **Solution Owner** | Project resource requests | Create demand requests, view own requests only, limited employee visibility |

### 6.2 Data Scoping Rules

```python
def apply_role_based_filtering(query: Query, user_role: str, user_id: int) -> Query:
    """Apply role-based data filtering to queries"""
    
    if user_role == "SOLUTION_OWNER":
        # Solution Owner data scoping
        if "demand_requests" in str(query):
            # Can only see own demand requests
            query = query.filter(DemandRequest.raised_by_user_id == user_id)
        
        if "employees" in str(query):
            # Limited field view - no sensitive data
            query = query.options(
                defer(Employee.email),
                defer(Employee.bench_status)
            )
    
    # Resource Manager and Operations Manager see all data
    return query
```

---

## 7. Error Response Standards

### 7.1 Authentication Errors (401)

```json
{
  "detail": {
    "error": "Token has expired",
    "code": "TOKEN_EXPIRED",
    "timestamp": "2026-05-22T10:30:00Z"
  }
}
```

### 7.2 Authorization Errors (403)

```json
{
  "detail": {
    "error": "Access denied. Required roles: RESOURCE_MANAGER. Your role: SOLUTION_OWNER",
    "code": "RBAC_VIOLATION",
    "required_roles": ["RESOURCE_MANAGER"],
    "user_role": "SOLUTION_OWNER",
    "endpoint": "POST /allocations"
  }
}
```

### 7.3 Missing Authentication (401)

```json
{
  "detail": {
    "error": "Authentication required",
    "code": "MISSING_TOKEN",
    "message": "Please provide a valid Bearer token"
  }
}
```

---

## 8. Frontend RBAC

### 8.1 RoleGuard Component Implementation

```typescript
interface RoleGuardProps {
  allowedRoles: UserRole[];
  children: React.ReactNode;
  fallback?: React.ReactNode;
  behavior?: 'hide' | 'disable' | 'redirect';
  redirectPath?: string;
}

type UserRole = 'RESOURCE_MANAGER' | 'OPERATIONS_MANAGER' | 'SOLUTION_OWNER';

const RoleGuard: React.FC<RoleGuardProps> = ({ 
  allowedRoles, 
  children, 
  fallback = null,
  behavior = 'hide',
  redirectPath = '/unauthorized'
}) => {
  const { user, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  // Not authenticated - redirect to login
  if (!isAuthenticated || !user) {
    navigate('/login');
    return null;
  }

  // Check if user role is allowed
  const isAuthorized = allowedRoles.includes(user.role);

  if (!isAuthorized) {
    switch (behavior) {
      case 'hide':
        return <>{fallback}</>;
      
      case 'disable':
        return (
          <div className="disabled-content">
            {React.cloneElement(children as React.ReactElement, { disabled: true })}
          </div>
        );
      
      case 'redirect':
        navigate(redirectPath);
        return null;
      
      default:
        return <>{fallback}</>;
    }
  }

  return <>{children}</>;
};
```

### 8.2 Usage Examples

```typescript
// Hide entire form for unauthorized roles
<RoleGuard allowedRoles={['RESOURCE_MANAGER']}>
  <AllocationForm />
</RoleGuard>

// Show fallback message
<RoleGuard 
  allowedRoles={['RESOURCE_MANAGER', 'OPERATIONS_MANAGER']}
  fallback={<p>You need Resource Manager or Operations Manager access to view this dashboard.</p>}
>
  <BenchDashboard />
</RoleGuard>

// Disable buttons for unauthorized users
<RoleGuard 
  allowedRoles={['RESOURCE_MANAGER']} 
  behavior="disable"
>
  <button>Create Employee</button>
</RoleGuard>

// Redirect unauthorized users
<RoleGuard 
  allowedRoles={['SOLUTION_OWNER']}
  behavior="redirect"
  redirectPath="/dashboard"
>
  <DemandRequestForm />
</RoleGuard>
```

### 8.3 Auth Context Implementation

```typescript
interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  hasRole: (role: UserRole) => boolean;
  hasAnyRole: (roles: UserRole[]) => boolean;
}

interface User {
  id: number;
  email: string;
  name: string;
  role: UserRole;
}

export const AuthProvider: React.FC<{children: React.ReactNode}> = ({children}) => {
  const [user, setUser] = useState<User | null>(null);
  
  useEffect(() => {
    // Check for existing token on app load
    const checkAuth = async () => {
      try {
        const response = await api.get('/auth/me');
        setUser(response.data);
      } catch (error) {
        // Token invalid or expired
        localStorage.removeItem('token');
        setUser(null);
      }
    };
    
    checkAuth();
  }, []);

  const login = async (email: string, password: string) => {
    const response = await api.post('/auth/login', { email, password });
    const { access_token, user: userData } = response.data;
    
    // Store token in httpOnly cookie (backend sets it)
    setUser(userData);
  };

  const logout = () => {
    // Clear httpOnly cookie via backend
    api.post('/auth/logout');
    setUser(null);
  };

  const hasRole = (role: UserRole): boolean => {
    return user?.role === role;
  };

  const hasAnyRole = (roles: UserRole[]): boolean => {
    return user ? roles.includes(user.role) : false;
  };

  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated: !!user,
      login,
      logout,
      hasRole,
      hasAnyRole
    }}>
      {children}
    </AuthContext.Provider>
  );
};
```

### 8.4 Route-Level Protection

```typescript
import { Navigate } from 'react-router-dom';

const ProtectedRoute: React.FC<{
  children: React.ReactNode;
  allowedRoles: UserRole[];
}> = ({ children, allowedRoles }) => {
  const { user, isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (!allowedRoles.includes(user.role)) {
    return <Navigate to="/unauthorized" replace />;
  }

  return <>{children}</>;
};

// Router configuration
<Routes>
  <Route path="/login" element={<LoginPage />} />
  
  <Route path="/dashboard" element={
    <ProtectedRoute allowedRoles={['RESOURCE_MANAGER', 'OPERATIONS_MANAGER']}>
      <DashboardPage />
    </ProtectedRoute>
  } />
  
  <Route path="/employees/new" element={
    <ProtectedRoute allowedRoles={['RESOURCE_MANAGER']}>
      <CreateEmployeePage />
    </ProtectedRoute>
  } />
  
  <Route path="/demand/new" element={
    <ProtectedRoute allowedRoles={['SOLUTION_OWNER']}>
      <CreateDemandPage />
    </ProtectedRoute>
  } />
</Routes>
```

---

## 9. Edge Cases

### 9.1 Token Validation Edge Cases

| Test Case | Token State | Expected Result | HTTP Code |
|---|---|---|---|
| **Expired token (> 24h old)** | exp claim in past | ❌ TOKEN_EXPIRED | 401 |
| **Tampered signature** | Modified token signature | ❌ INVALID_SIGNATURE | 401 |
| **Missing role claim** | JWT without role field | ❌ MISSING_ROLE_CLAIM | 401 |
| **Invalid role value** | role: "ADMIN" (not in enum) | ❌ INVALID_ROLE | 401 |
| **Missing Bearer prefix** | Authorization: "token123" | ❌ MISSING_TOKEN | 401 |
| **Empty token** | Authorization: "Bearer " | ❌ MISSING_TOKEN | 401 |
| **Malformed JWT** | Invalid base64 encoding | ❌ INVALID_TOKEN | 401 |

### 9.2 Role Authorization Edge Cases

| Test Case | User Role | Required Role | Expected Result | HTTP Code |
|---|---|---|---|
| **Valid token but wrong role** | SOLUTION_OWNER | RESOURCE_MANAGER | ❌ RBAC_VIOLATION | 403 |
| **Case sensitivity check** | resource_manager | RESOURCE_MANAGER | ❌ RBAC_VIOLATION | 403 |
| **Multiple valid roles** | OPERATIONS_MANAGER | [RM, OM] | ✅ Allowed | 200 |
| **Role hierarchy bypass attempt** | SOLUTION_OWNER | Any RM endpoint | ❌ RBAC_VIOLATION | 403 |

### 9.3 Frontend RBAC Edge Cases

| Test Case | Scenario | Expected Result | UI Behavior |
|---|---|---|---|
| **Token expires during session** | JWT exp reached while using app | Redirect to login | Clear user state, show login |
| **Role changed in another session** | Admin changes role elsewhere | Next API call fails 403 | Force logout, show message |
| **Component renders before auth check** | User state still loading | Show loading spinner | No premature access denial |
| **Navigation to unauthorized route** | Direct URL access | Redirect to unauthorized page | Clear URL, show access denied |

### 9.4 Multi-Role Future Scenario

**Current State:** Single role per user  
**Future Enhancement:** Multiple roles per user

```typescript
// Current JWT payload
{
  "role": "RESOURCE_MANAGER"
}

// Future JWT payload (for reference)
{
  "roles": ["RESOURCE_MANAGER", "OPERATIONS_MANAGER"],
  "primary_role": "RESOURCE_MANAGER"
}

// Future role checking logic
const hasAnyRole = (requiredRoles: string[]): boolean => {
  return user.roles.some(role => requiredRoles.includes(role));
};
```

### 9.5 Token Refresh Edge Cases

| Test Case | Scenario | Expected Result | Implementation Note |
|---|---|---|---|
| **Token near expiry** | exp in next 5 minutes | Auto-refresh token | Frontend handles silently |
| **Refresh token expired** | Both tokens expired | Force re-login | Clear all auth state |
| **Refresh during API call** | Token expires mid-request | Retry with new token | Axios interceptor handles |
| **Multiple tabs refreshing** | Race condition on refresh | One succeeds, others use result | Synchronize via localStorage |

---

## 10. Security Considerations

### 10.1 JWT Security Best Practices

```python
# Secure JWT configuration
JWT_SETTINGS = {
    "SECRET_KEY": os.getenv("JWT_SECRET_KEY"),  # Strong random secret
    "ALGORITHM": "HS256",
    "ACCESS_TOKEN_EXPIRE_HOURS": 24,
    "ISSUER": "resource360-pilot",
    "AUDIENCE": "resource360-users"
}

# Additional security validations
def validate_jwt_claims(payload: dict) -> bool:
    # Check issuer
    if payload.get("iss") != JWT_SETTINGS["ISSUER"]:
        return False
    
    # Check audience (if used)
    if "aud" in payload and payload["aud"] != JWT_SETTINGS["AUDIENCE"]:
        return False
    
    # Check issued at time (prevent very old tokens)
    iat = payload.get("iat")
    if iat and datetime.fromtimestamp(iat) < datetime.now() - timedelta(days=30):
        return False
    
    return True
```

### 10.2 Rate Limiting by Role

```python
# Role-based rate limiting
RATE_LIMITS = {
    "RESOURCE_MANAGER": "1000/hour",
    "OPERATIONS_MANAGER": "500/hour", 
    "SOLUTION_OWNER": "200/hour"
}

@limiter.limit(lambda: RATE_LIMITS.get(current_user.role, "100/hour"))
async def rate_limited_endpoint():
    pass
```

### 10.3 Audit Logging

```python
async def log_rbac_violation(
    user_id: int,
    user_role: str,
    endpoint: str,
    method: str,
    required_roles: List[str]
):
    """Log all RBAC violations for security monitoring"""
    audit_log = {
        "event_type": "RBAC_VIOLATION",
        "user_id": user_id,
        "user_role": user_role,
        "endpoint": endpoint,
        "method": method,
        "required_roles": required_roles,
        "timestamp": datetime.utcnow(),
        "ip_address": request.client.host
    }
    await audit_logger.log(audit_log)
```

---

## 11. Testing Strategy

### 11.1 Backend RBAC Tests (pytest)

```python
# tests/test_rbac.py
import pytest
from fastapi.testclient import TestClient

def test_resource_manager_can_create_employee(client: TestClient, rm_token: str):
    """Test Resource Manager can create employees"""
    response = client.post(
        "/employees",
        headers={"Authorization": f"Bearer {rm_token}"},
        json={"name": "Test User", "email": "test@teg.com"}
    )
    assert response.status_code == 201

def test_operations_manager_cannot_create_employee(client: TestClient, om_token: str):
    """Test Operations Manager cannot create employees"""
    response = client.post(
        "/employees", 
        headers={"Authorization": f"Bearer {om_token}"},
        json={"name": "Test User", "email": "test@teg.com"}
    )
    assert response.status_code == 403
    assert response.json()["detail"]["code"] == "RBAC_VIOLATION"

def test_expired_token_rejected(client: TestClient, expired_token: str):
    """Test expired tokens are rejected"""
    response = client.get(
        "/employees",
        headers={"Authorization": f"Bearer {expired_token}"}
    )
    assert response.status_code == 401
    assert response.json()["detail"]["code"] == "TOKEN_EXPIRED"

# Parameterized tests for complete permission matrix
@pytest.mark.parametrize("role,endpoint,method,expected_status", [
    ("RESOURCE_MANAGER", "/employees", "POST", 201),
    ("OPERATIONS_MANAGER", "/employees", "POST", 403),
    ("SOLUTION_OWNER", "/employees", "POST", 403),
    ("RESOURCE_MANAGER", "/demand-requests", "POST", 403),
    ("SOLUTION_OWNER", "/demand-requests", "POST", 201),
    # ... all permission matrix combinations
])
def test_rbac_permission_matrix(role, endpoint, method, expected_status, client, auth_tokens):
    """Test complete RBAC permission matrix"""
    token = auth_tokens[role]
    response = getattr(client, method.lower())(
        endpoint,
        headers={"Authorization": f"Bearer {token}"}
    )
    assert response.status_code == expected_status
```

### 11.2 Frontend RBAC Tests (Vitest + React Testing Library)

```typescript
// components/RoleGuard.test.tsx
import { render, screen } from '@testing-library/react';
import { RoleGuard } from './RoleGuard';

const MockAuthProvider = ({ role, children }) => (
  <AuthContext.Provider value={{
    user: { id: 1, email: 'test@teg.com', name: 'Test', role },
    isAuthenticated: true
  }}>
    {children}
  </AuthContext.Provider>
);

describe('RoleGuard', () => {
  test('shows content for authorized role', () => {
    render(
      <MockAuthProvider role="RESOURCE_MANAGER">
        <RoleGuard allowedRoles={['RESOURCE_MANAGER']}>
          <div>Protected Content</div>
        </RoleGuard>
      </MockAuthProvider>
    );
    
    expect(screen.getByText('Protected Content')).toBeInTheDocument();
  });

  test('hides content for unauthorized role', () => {
    render(
      <MockAuthProvider role="SOLUTION_OWNER">
        <RoleGuard allowedRoles={['RESOURCE_MANAGER']}>
          <div>Protected Content</div>
        </RoleGuard>
      </MockAuthProvider>
    );
    
    expect(screen.queryByText('Protected Content')).not.toBeInTheDocument();
  });

  test('shows fallback for unauthorized role', () => {
    render(
      <MockAuthProvider role="SOLUTION_OWNER">
        <RoleGuard 
          allowedRoles={['RESOURCE_MANAGER']}
          fallback={<div>Access Denied</div>}
        >
          <div>Protected Content</div>
        </RoleGuard>
      </MockAuthProvider>
    );
    
    expect(screen.getByText('Access Denied')).toBeInTheDocument();
  });
});
```

### 11.3 Integration Tests

```python
# tests/test_rbac_integration.py
def test_complete_user_journey_rbac(client: TestClient):
    """Test RBAC across complete user journey"""
    
    # 1. Login as Resource Manager
    rm_response = client.post("/auth/login", json={
        "email": "rm@teg.com", 
        "password": "password"
    })
    rm_token = rm_response.json()["access_token"]
    
    # 2. Create employee (should succeed)
    employee_response = client.post(
        "/employees",
        headers={"Authorization": f"Bearer {rm_token}"},
        json={"name": "Test Employee", "email": "emp@teg.com"}
    )
    assert employee_response.status_code == 201
    
    # 3. Login as Solution Owner  
    so_response = client.post("/auth/login", json={
        "email": "so@teg.com",
        "password": "password" 
    })
    so_token = so_response.json()["access_token"]
    
    # 4. Try to create employee as SO (should fail)
    so_employee_response = client.post(
        "/employees",
        headers={"Authorization": f"Bearer {so_token}"},
        json={"name": "SO Employee", "email": "so-emp@teg.com"}
    )
    assert so_employee_response.status_code == 403
    
    # 5. Create demand request as SO (should succeed)
    demand_response = client.post(
        "/demand-requests",
        headers={"Authorization": f"Bearer {so_token}"},
        json={
            "project_name": "Test Project",
            "required_role": "Developer"
        }
    )
    assert demand_response.status_code == 201
```

---

## 12. Implementation Checklist

### Backend Implementation

- [ ] **middleware/auth.py** — JWT authentication and role validation middleware
- [ ] **routers/auth.py** — Login endpoint with JWT token generation
- [ ] **services/auth_service.py** — User authentication and role management
- [ ] **models/user.py** — User model with role enum
- [ ] **dependencies/rbac.py** — Role checker dependencies for routes
- [ ] **tests/test_rbac.py** — Comprehensive RBAC test suite

### Frontend Implementation

- [ ] **contexts/AuthContext.tsx** — Authentication state management
- [ ] **components/RoleGuard.tsx** — Role-based component access control
- [ ] **components/ProtectedRoute.tsx** — Route-level access control
- [ ] **hooks/useAuth.ts** — Authentication hook utilities
- [ ] **api/auth.ts** — Authentication API calls
- [ ] **tests/RoleGuard.test.tsx** — Frontend RBAC component tests

### Security & Monitoring

- [ ] **JWT secret management** — Secure secret key configuration
- [ ] **Token expiration handling** — Frontend token refresh logic
- [ ] **Audit logging** — RBAC violation logging for security monitoring
- [ ] **Rate limiting** — Role-based API rate limits
- [ ] **Security headers** — CORS, CSP configuration

### Documentation & Training

- [ ] **API documentation** — RBAC requirements for each endpoint
- [ ] **Frontend component docs** — RoleGuard usage examples
- [ ] **Security playbook** — RBAC violation response procedures
- [ ] **Permission matrix** — Complete role × endpoint access reference

---

**Document Status:** APPROVED for implementation  
**Owner:** Architect  
**Reviewed:** 2026-05-22  
**Implementation Target:** Phase 2