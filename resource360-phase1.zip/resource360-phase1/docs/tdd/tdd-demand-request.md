# TDD: Demand Request Management
## Resource 360 — Technical Design Document
## TEG AI Adoption Pilot | Phase 1 Implementation

---

## 1. Overview

**Feature:** Resource demand workflow from request to fulfilment  
**Scope:** Solution Owners raise demand, Resource Managers fulfil with AI assistance  
**Primary Actors:** Solution Owner (raise), Resource Manager (fulfil), Operations Manager (view)  
**Core Workflow:** OPEN → PENDING → FULFILLED/DECLINED  
**Key Integration:** Links to allocation creation and AI candidate suggestions  

---

## 2. Sequence Diagrams

### Flow A — Solution Owner Raises Demand

```mermaid
sequenceDiagram
    participant SO as Solution Owner
    participant UI as React DemandForm
    participant API as FastAPI /demand-requests
    participant JWT as JWT Middleware
    participant DB as SQLite Database
    participant NOTIF as Notification Service

    SO->>UI: Submit demand request form
    UI->>API: POST /demand-requests
    Note right of UI: {project_name, required_role, required_skills[], <br/>start_date, allocation_pct, grade_required, priority}
    
    API->>JWT: Validate JWT token
    JWT->>JWT: Extract role claim
    
    alt Invalid token or wrong role
        JWT-->>API: 401 Unauthorized / 403 Forbidden
        API-->>UI: Error response
        UI-->>SO: Show error message
    else Valid SOLUTION_OWNER
        JWT->>API: Proceed with authorized user
        
        API->>API: Validate request fields
        Note right of API: allocation_pct 1-100, valid date format, <br/>required fields present
        
        alt Validation failure
            API-->>UI: 422 {field validation errors}
            UI-->>SO: Show field errors
        else Valid request
            API->>DB: INSERT INTO demand_requests<br/>(project_name, required_role, required_skills,<br/>start_date, allocation_pct, grade_required,<br/>priority, status='OPEN', raised_by_user_id)
            DB-->>API: demand_request_id
            
            API->>NOTIF: Send in-app notification to Resource Managers
            Note right of NOTIF: New demand request notification
            
            API-->>UI: 201 {demand_request object}
            UI-->>SO: Success confirmation + redirect to status page
        end
    end
```

### Flow B — Resource Manager Fulfils Demand

```mermaid
sequenceDiagram
    participant RM as Resource Manager
    participant UI as React AISuggestionsPage
    participant API as FastAPI /demand-requests/{id}/fulfil
    participant JWT as JWT Middleware
    participant DB as SQLite Database
    participant ALLOC as Allocation Service
    participant EMP as Employee Service

    RM->>UI: Select employee and confirm allocation
    UI->>API: POST /demand-requests/{id}/fulfil
    Note right of UI: {employee_id}
    
    API->>JWT: Validate JWT token
    JWT->>JWT: Extract role claim
    
    alt Invalid token or wrong role
        JWT-->>API: 401 Unauthorized / 403 Forbidden
        API-->>UI: Error response
        UI-->>RM: Show error message
    else Valid RESOURCE_MANAGER
        JWT->>API: Proceed with authorized user
        
        API->>DB: SELECT * FROM demand_requests WHERE id = ?
        DB-->>API: demand_request
        
        alt Demand not found
            API-->>UI: 404 {demand not found}
            UI-->>RM: Show not found error
        else Demand already fulfilled
            Note right of API: status != 'OPEN'
            API-->>UI: 409 {"error": "DEMAND_ALREADY_FULFILLED"}
            UI-->>RM: Show conflict error
        else Demand is OPEN
            API->>ALLOC: Validate allocation feasibility
            ALLOC->>DB: SELECT SUM(allocation_pct) FROM allocations<br/>WHERE employee_id = ? AND is_active = 1
            DB-->>ALLOC: current_allocation
            
            alt Over-allocation would occur
                Note right of ALLOC: current + demand.allocation_pct > 100
                ALLOC-->>API: OverAllocationError
                API-->>UI: 422 {"error": "OVER_ALLOCATION"}
                UI-->>RM: Show over-allocation warning
            else Allocation is valid
                API->>DB: BEGIN TRANSACTION
                
                API->>DB: UPDATE demand_requests<br/>SET status='FULFILLED', fulfilled_by_employee_id=?<br/>WHERE id = ?
                DB-->>API: Updated
                
                API->>ALLOC: Create allocation
                ALLOC->>DB: INSERT INTO allocations<br/>(employee_id, project_id, project_role,<br/>allocation_pct, start_date, is_active=1)
                DB-->>ALLOC: allocation_id
                
                API->>EMP: Update employee status
                EMP->>DB: UPDATE employees SET bench_status='ALLOCATED'<br/>WHERE id = ? AND bench_status != 'ON_LEAVE'
                DB-->>EMP: Updated
                
                API->>DB: COMMIT TRANSACTION
                
                API-->>UI: 200 {demand_request with allocation}
                UI-->>RM: Success confirmation + refresh data
            end
        end
    end
```

---

## 3. API Specifications

### POST /demand-requests

**Request Schema:**
```json
{
  "project_name": "Project Alpha",
  "required_role": "Senior React Developer", 
  "required_skills": ["React", "TypeScript", "Node.js"],
  "start_date": "2026-06-01",
  "duration_months": 6,
  "allocation_pct": 100,
  "grade_required": "Senior",
  "priority": "Urgent",
  "notes": "Need someone with fintech experience"
}
```

**Success Response (201):**
```json
{
  "id": 42,
  "project_name": "Project Alpha",
  "required_role": "Senior React Developer",
  "required_skills": ["React", "TypeScript", "Node.js"],
  "start_date": "2026-06-01", 
  "duration_months": 6,
  "allocation_pct": 100,
  "grade_required": "Senior",
  "priority": "Urgent",
  "status": "OPEN",
  "raised_by_user_id": 3,
  "notes": "Need someone with fintech experience",
  "created_at": "2026-05-22T10:30:00Z"
}
```

### GET /demand-requests

**Query Parameters:**
- `status` (optional): Filter by status (OPEN, PENDING, FULFILLED, DECLINED)

**Success Response (200):**
```json
[
  {
    "id": 42,
    "project_name": "Project Alpha",
    "status": "OPEN",
    "priority": "Urgent",
    "required_role": "Senior React Developer",
    "created_at": "2026-05-22T10:30:00Z"
  }
]
```

### POST /demand-requests/{id}/fulfil

**Request Schema:**
```json
{
  "employee_id": 1
}
```

**Success Response (200):**
```json
{
  "id": 42,
  "status": "FULFILLED",
  "fulfilled_by_employee_id": 1,
  "allocation": {
    "id": 23,
    "employee_id": 1,
    "project_id": 15,
    "allocation_pct": 100,
    "start_date": "2026-06-01"
  }
}
```

### POST /demand-requests/{id}/decline

**Request Schema:**
```json
{
  "reason": "No available candidates with required skills in next 30 days"
}
```

**Success Response (200):**
```json
{
  "id": 42,
  "status": "DECLINED", 
  "decline_reason": "No available candidates with required skills in next 30 days"
}
```

---

## 4. RBAC Matrix

| Action | Resource Manager | Operations Manager | Solution Owner |
|---|---|---|---|
| POST /demand-requests | ❌ (403) | ❌ (403) | ✅ |
| GET /demand-requests | ✅ (all) | ✅ (all) | ✅ (own only) |
| POST /demand-requests/{id}/fulfil | ✅ | ❌ (403) | ❌ (403) |
| POST /demand-requests/{id}/decline | ✅ | ❌ (403) | ❌ (403) |
| GET /ai/suggestions/{demand_id} | ✅ | ❌ (403) | ❌ (403) |

**Enforcement Points:**
- `middleware/auth.py` — JWT role claim validation
- `routers/demand.py` — Scoped queries for Solution Owner (own requests only)

---

## 5. Database Operations

### 5.1 Demand Request Creation

```sql
-- Create new demand request
INSERT INTO demand_requests (
    project_name,
    required_role, 
    required_skills,
    start_date,
    duration_months,
    allocation_pct,
    grade_required,
    priority,
    status,
    raised_by_user_id,
    notes,
    created_at
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'OPEN', ?, ?, CURRENT_TIMESTAMP);
```

### 5.2 Demand Request Listing (Solution Owner - Scoped)

```sql
-- Solution Owner can only see their own requests
SELECT * FROM demand_requests 
WHERE raised_by_user_id = ?
  AND status IN ('OPEN', 'PENDING', 'FULFILLED', 'DECLINED')
ORDER BY created_at DESC;
```

### 5.3 Demand Request Listing (Resource/Operations Manager - All)

```sql
-- RM and OM can see all requests with optional status filter
SELECT 
    dr.*,
    u.name as raised_by_name,
    e.name as fulfilled_by_employee_name
FROM demand_requests dr
LEFT JOIN users u ON dr.raised_by_user_id = u.id  
LEFT JOIN employees e ON dr.fulfilled_by_employee_id = e.id
WHERE (?1 IS NULL OR dr.status = ?1)
ORDER BY 
    CASE dr.priority 
        WHEN 'Urgent' THEN 1 
        WHEN 'High' THEN 2 
        WHEN 'Normal' THEN 3 
    END,
    dr.created_at DESC;
```

### 5.4 Demand Fulfilment Transaction

```sql
-- Step 1: Check demand is still OPEN
SELECT status FROM demand_requests WHERE id = ? FOR UPDATE;

-- Step 2: Validate employee allocation capacity
SELECT COALESCE(SUM(allocation_pct), 0) as current_total
FROM allocations 
WHERE employee_id = ? 
  AND is_active = 1
  AND (end_date IS NULL OR end_date >= CURRENT_DATE);

-- Step 3: Update demand status
UPDATE demand_requests 
SET status = 'FULFILLED', 
    fulfilled_by_employee_id = ?
WHERE id = ? AND status = 'OPEN';

-- Step 4: Create allocation from demand data
INSERT INTO allocations (
    employee_id,
    project_id,
    project_role,
    allocation_pct,
    start_date,
    end_date,
    is_active
) 
SELECT 
    ?,
    (SELECT id FROM projects WHERE name = dr.project_name LIMIT 1),
    dr.required_role,
    dr.allocation_pct,
    dr.start_date,
    CASE 
        WHEN dr.duration_months IS NOT NULL 
        THEN DATE(dr.start_date, '+' || dr.duration_months || ' months')
        ELSE NULL 
    END,
    1
FROM demand_requests dr WHERE dr.id = ?;

-- Step 5: Update employee bench status
UPDATE employees 
SET bench_status = 'ALLOCATED'
WHERE id = ? 
  AND bench_status IN ('BENCH', 'ROLLING_OFF')
  AND is_deleted = 0;
```

### 5.5 Dashboard Metrics Queries

```sql
-- Open demand requests count by priority
SELECT 
    priority,
    COUNT(*) as count
FROM demand_requests 
WHERE status = 'OPEN'
GROUP BY priority;

-- Recent fulfilment rate (last 30 days)
SELECT 
    COUNT(CASE WHEN status = 'FULFILLED' THEN 1 END) * 100.0 / COUNT(*) as fulfilment_rate
FROM demand_requests 
WHERE created_at >= DATE('now', '-30 days');
```

---

## 6. Validation Rules

| Rule | Implementation | Error Response |
|---|---|---|
| project_name: required, non-empty | Pydantic schema validation | 422 + field validation error |
| required_role: required, non-empty | Pydantic schema validation | 422 + field validation error |
| required_skills: array, min 1 item | Pydantic schema validation | 422 + "At least one skill required" |
| allocation_pct: 1-100 | Pydantic schema validation | 422 + field validation error |
| start_date: valid date format | Pydantic schema validation | 422 + field validation error |
| priority: enum validation | Pydantic schema validation | 422 + "Invalid priority value" |
| grade_required: non-empty | Pydantic schema validation | 422 + field validation error |
| demand status: OPEN for fulfilment | Business logic in router | 409 + "DEMAND_ALREADY_FULFILLED" |
| employee exists for fulfilment | DB query validation | 422 + "Employee not found" |
| allocation would not exceed 100% | Business logic integration | 422 + "OVER_ALLOCATION" |

---

## 7. Error Handling

### 7.1 HTTP Error Codes and Business Logic Errors

| Error Scenario | HTTP Code | Error Code | Description |
|---|---|---|---|
| **Fulfilling already FULFILLED demand** | 409 | DEMAND_ALREADY_FULFILLED | Cannot fulfil demand that is not OPEN |
| **Fulfilling causes over-allocation** | 422 | OVER_ALLOCATION | Employee allocation would exceed 100% |
| **Solution Owner tries to fulfil** | 403 | FORBIDDEN | Only Resource Manager can fulfil demands |
| **Resource Manager tries to raise** | 403 | FORBIDDEN | Only Solution Owner can raise demands |
| **Invalid allocation_pct (>100)** | 422 | VALIDATION_ERROR | allocation_pct must be 1-100 |
| **Employee on leave for fulfilment** | 422 | EMPLOYEE_ON_LEAVE | Cannot allocate employee currently on leave |
| **Non-existent demand_id** | 404 | DEMAND_NOT_FOUND | Demand request does not exist |
| **Non-existent employee_id** | 422 | EMPLOYEE_NOT_FOUND | Employee does not exist |

### 7.2 Application-Level Exception Classes

```python
class DemandRequestError(Exception):
    """Demand request-specific business logic errors"""
    pass

class DemandAlreadyFulfilledError(DemandRequestError):
    def __init__(self, demand_id: int, current_status: str):
        self.demand_id = demand_id
        self.current_status = current_status
        super().__init__(f"Demand {demand_id} already {current_status}, cannot fulfil")

class DemandFulfilmentOverAllocationError(DemandRequestError):
    def __init__(self, employee_id: int, current_pct: int, demand_pct: int):
        self.employee_id = employee_id
        self.current_pct = current_pct
        self.demand_pct = demand_pct
        super().__init__(f"Fulfilling demand would over-allocate employee {employee_id}: {current_pct}% + {demand_pct}% > 100%")

class InsufficientPermissionError(DemandRequestError):
    def __init__(self, action: str, required_role: str, actual_role: str):
        super().__init__(f"Cannot {action}: requires {required_role}, user has {actual_role}")
```

### 7.3 Error Response Format Examples

```json
// 409 Conflict - Already fulfilled
{
  "error": "Demand request has already been fulfilled",
  "code": "DEMAND_ALREADY_FULFILLED",
  "field": null,
  "details": {
    "demand_id": 42,
    "current_status": "FULFILLED",
    "fulfilled_by_employee_id": 5
  }
}

// 422 Over-allocation
{
  "error": "Fulfilling this demand would over-allocate employee. Current: 80%, Demand: 50%, Total: 130%",
  "code": "OVER_ALLOCATION", 
  "field": "employee_id",
  "details": {
    "employee_id": 1,
    "current_allocation": 80,
    "demand_allocation": 50,
    "total_would_be": 130
  }
}

// 403 Forbidden - RBAC
{
  "error": "Only Solution Owners can raise demand requests",
  "code": "FORBIDDEN",
  "field": null,
  "details": {
    "required_role": "SOLUTION_OWNER",
    "user_role": "RESOURCE_MANAGER"
  }
}
```

---

## 8. React Frontend Integration

### 8.1 DemandForm Component (Solution Owner)

```typescript
interface DemandRequestFormData {
  project_name: string;
  required_role: string;
  required_skills: string[];
  start_date: string;
  duration_months?: number;
  allocation_pct: number;
  grade_required: string;
  priority: 'Urgent' | 'High' | 'Normal';
  notes?: string;
}

interface DemandFormProps {
  onSuccess: (demandId: number) => void;
  onCancel: () => void;
}
```

### 8.2 React Query Mutations

```typescript
// Create demand request
const createDemandMutation = useMutation({
  mutationFn: (data: DemandRequestFormData) => 
    api.post('/demand-requests', data),
  onSuccess: (response) => {
    queryClient.invalidateQueries(['demand-requests']);
    queryClient.invalidateQueries(['dashboard', 'metrics']);
    onSuccess(response.data.id);
  },
  onError: (error: ApiError) => {
    if (error.code === 'VALIDATION_ERROR') {
      // Handle field-specific validation errors
      setFieldErrors(error.details.field_errors);
    }
  }
});

// Fulfil demand request
const fulfilDemandMutation = useMutation({
  mutationFn: ({demandId, employeeId}: {demandId: number, employeeId: number}) =>
    api.post(`/demand-requests/${demandId}/fulfil`, {employee_id: employeeId}),
  onSuccess: () => {
    queryClient.invalidateQueries(['demand-requests']);
    queryClient.invalidateQueries(['employees']);
    queryClient.invalidateQueries(['dashboard']);
  },
  onError: (error: ApiError) => {
    if (error.code === 'DEMAND_ALREADY_FULFILLED') {
      showToast('This demand has already been fulfilled', 'error');
    } else if (error.code === 'OVER_ALLOCATION') {
      showToast(error.message, 'warning');
    }
  }
});
```

### 8.3 Skills Input Component

```typescript
const SkillsInput: React.FC<{
  value: string[];
  onChange: (skills: string[]) => void;
}> = ({ value, onChange }) => {
  const [inputValue, setInputValue] = useState('');
  
  const addSkill = (skill: string) => {
    if (skill.trim() && !value.includes(skill.trim())) {
      onChange([...value, skill.trim()]);
    }
    setInputValue('');
  };

  return (
    <div>
      <div className="skills-tags">
        {value.map(skill => (
          <span key={skill} className="skill-tag">
            {skill}
            <button onClick={() => onChange(value.filter(s => s !== skill))}>×</button>
          </span>
        ))}
      </div>
      <input
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        onKeyPress={(e) => {
          if (e.key === 'Enter') {
            e.preventDefault();
            addSkill(inputValue);
          }
        }}
        placeholder="Type skill and press Enter"
      />
    </div>
  );
};
```

---

## 9. Status Transitions

### 9.1 Demand Request State Machine

```
    [OPEN] ──────┐
       │         │
       │ fulfil  │ decline
       ▼         ▼
  [FULFILLED] [DECLINED]
       │         │
       └── (terminal states)
```

**Valid Transitions:**
- OPEN → FULFILLED (via POST /demand-requests/{id}/fulfil)
- OPEN → DECLINED (via POST /demand-requests/{id}/decline)

**Invalid Transitions (will result in 409 error):**
- FULFILLED → any other state
- DECLINED → any other state

### 9.2 Integration with Allocation Status

When demand is FULFILLED:
1. Allocation is created with `is_active = 1`
2. Employee `bench_status` updates to `ALLOCATED` (unless `ON_LEAVE`)
3. Demand `fulfilled_by_employee_id` is populated

---

## 10. Performance Considerations

### 10.1 Database Indexes

```sql
-- Critical for demand listing performance
CREATE INDEX idx_demand_status ON demand_requests(status);
CREATE INDEX idx_demand_raised_by ON demand_requests(raised_by_user_id);
CREATE INDEX idx_demand_priority_created ON demand_requests(priority, created_at);

-- Critical for dashboard metrics
CREATE INDEX idx_demand_created_status ON demand_requests(created_at, status);
```

### 10.2 Query Optimisation

- **Demand listing:** Use appropriate indexes for filtering by status and user
- **Dashboard metrics:** Single query with conditional aggregation
- **Fulfilment transaction:** Use FOR UPDATE to prevent race conditions

### 10.3 Caching Strategy

- **React Query:** 2-minute cache for demand list (changes moderately)
- **Dashboard metrics:** 30-second cache for open demand counts
- **AI suggestions:** No caching (real-time data dependent on current bench status)

---

## 11. Testing Strategy

### 11.1 Unit Tests (pytest)

```python
# tests/test_demand_service.py
def test_create_demand_request():
    """Test demand creation with valid data"""

def test_demand_fulfilment_validation():
    """Test business rules for fulfilment"""

def test_demand_status_transitions():
    """Test valid and invalid status transitions"""

def test_demand_rbac_scoping():
    """Test Solution Owner can only see own demands"""
```

### 11.2 Integration Tests (pytest + httpx)

```python
# tests/test_demand_api.py
def test_post_demand_request_success():
    """Test complete demand creation flow"""

def test_fulfil_demand_success():
    """Test demand fulfilment with allocation creation"""

def test_fulfil_demand_already_fulfilled():
    """Test 409 error for already fulfilled demand"""

def test_fulfil_demand_over_allocation():
    """Test 422 error for over-allocation"""

def test_demand_rbac_endpoints():
    """Test all RBAC restrictions"""
```

### 11.3 Frontend Tests (Vitest + React Testing Library)

```typescript
// components/DemandForm.test.tsx
describe('DemandForm', () => {
  test('validates required fields');
  test('handles skills input correctly'); 
  test('shows validation errors');
  test('submits form successfully');
});

// pages/AISuggestionsPage.test.tsx
describe('AISuggestionsPage', () => {
  test('shows fulfil confirmation modal');
  test('handles fulfil success');
  test('handles already fulfilled error');
  test('handles over-allocation error');
});
```

---

## 12. Implementation Checklist

### Backend Implementation

- [ ] **models/demand_request.py** — SQLAlchemy demand model
- [ ] **schemas/demand_request.py** — Pydantic request/response schemas
- [ ] **routers/demand.py** — FastAPI endpoints with RBAC
- [ ] **services/demand_service.py** — Business logic and validation
- [ ] **services/notification_service.py** — In-app notifications for RMs
- [ ] **middleware/auth.py** — Enhanced JWT role validation
- [ ] **tests/test_demand.py** — Complete test suite

### Frontend Implementation

- [ ] **components/DemandForm.tsx** — React form for demand creation
- [ ] **components/DemandStatusList.tsx** — Solution Owner status view
- [ ] **components/DemandPanel.tsx** — Resource Manager dashboard view
- [ ] **components/SkillsInput.tsx** — Skills tagging input component
- [ ] **api/demand.ts** — React Query hooks
- [ ] **types/demand.ts** — TypeScript interfaces
- [ ] **tests/DemandForm.test.tsx** — Component tests

### Database & Integration

- [ ] **schema.sql** — Demand requests table with constraints
- [ ] **seed/demand_seed.py** — Test demand data
- [ ] **Database indexes** — Performance optimisation
- [ ] **Integration with allocation service** — Fulfilment creates allocations
- [ ] **Integration with AI suggestions** — Link demand to candidate ranking

---

**Document Status:** APPROVED for implementation  
**Owner:** Architect  
**Reviewed:** 2026-05-22  
**Implementation Target:** Phase 2