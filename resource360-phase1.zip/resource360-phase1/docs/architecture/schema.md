# Database Schema — Resource 360
## TEG AI Adoption Pilot | Phase 1 Deliverable 02

---

## ER Diagram (Text)

```
┌──────────┐         ┌─────────────┐        ┌──────────────┐
│  users   │         │  employees  │        │   projects   │
├──────────┤         ├─────────────┤        ├──────────────┤
│ id (PK)  │         │ id (PK)     │        │ id (PK)      │
│ email    │         │ name        │        │ name         │
│ password │         │ email       │        │ description  │
│ role     │         │ grade       │        │ status       │
│ name     │         │ department  │        │ start_date   │
└──────────┘         │ location    │        │ end_date     │
                     │ bench_status│        │ created_at   │
                     │ is_deleted  │        └──────┬───────┘
                     │ created_at  │               │
                     └──────┬──────┘               │
                            │                      │
              ┌─────────────┼──────────────────────┤
              │             │                      │
    ┌─────────▼──────┐  ┌───▼──────────────────────▼──┐
    │     skills     │  │         allocations          │
    ├────────────────┤  ├──────────────────────────────┤
    │ id (PK)        │  │ id (PK)                      │
    │ employee_id FK │  │ employee_id FK               │
    │ skill_name     │  │ project_id FK                │
    │ proficiency    │  │ project_role                 │
    │ created_at     │  │ allocation_pct  (1–100)      │
    └────────────────┘  │ start_date                   │
                        │ end_date                     │
    ┌───────────────┐   │ is_active                    │
    │certifications │   │ created_at                   │
    ├───────────────┤   └──────────────────────────────┘
    │ id (PK)       │
    │ employee_id FK│   ┌──────────────────────────────┐
    │ cert_name     │   │       demand_requests         │
    │ expires_on    │   ├──────────────────────────────┤
    │ status        │   │ id (PK)                      │
    │ created_at    │   │ project_name                 │
    └───────────────┘   │ required_role                │
                        │ required_skills (JSON)       │
                        │ start_date                   │
                        │ duration_months              │
                        │ allocation_pct               │
                        │ grade_required               │
                        │ priority                     │
                        │ status                       │
                        │ raised_by_user_id FK         │
                        │ fulfilled_by_employee_id FK  │
                        │ notes                        │
                        │ created_at                   │
                        └──────────────────────────────┘
```

---

## SQL DDL

```sql
PRAGMA foreign_keys = ON;

CREATE TABLE users (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    email       TEXT NOT NULL UNIQUE,
    password    TEXT NOT NULL,
    name        TEXT NOT NULL,
    role        TEXT NOT NULL CHECK (role IN ('RESOURCE_MANAGER','OPERATIONS_MANAGER','SOLUTION_OWNER')),
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE projects (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    description TEXT,
    status      TEXT NOT NULL DEFAULT 'ACTIVE'
                CHECK (status IN ('ACTIVE','COMPLETED','CANCELLED','ON_HOLD')),
    start_date  DATE,
    end_date    DATE,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE employees (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT NOT NULL,
    email        TEXT NOT NULL UNIQUE,
    grade        TEXT NOT NULL,
    department   TEXT NOT NULL,
    location     TEXT NOT NULL,
    bench_status TEXT NOT NULL DEFAULT 'BENCH'
                 CHECK (bench_status IN ('ALLOCATED','BENCH','ROLLING_OFF','ON_LEAVE')),
    is_deleted   INTEGER NOT NULL DEFAULT 0,
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE skills (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    skill_name  TEXT NOT NULL,
    proficiency TEXT NOT NULL DEFAULT 'Proficient'
                CHECK (proficiency IN ('Beginner','Proficient','Expert')),
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE certifications (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    cert_name   TEXT NOT NULL,
    expires_on  DATE,
    status      TEXT NOT NULL DEFAULT 'Active'
                CHECK (status IN ('Active','Expiring','Expired')),
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE allocations (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id     INTEGER NOT NULL REFERENCES employees(id),
    project_id      INTEGER NOT NULL REFERENCES projects(id),
    project_role    TEXT NOT NULL,
    allocation_pct  INTEGER NOT NULL CHECK (allocation_pct BETWEEN 1 AND 100),
    start_date      DATE NOT NULL,
    end_date        DATE,
    is_active       INTEGER NOT NULL DEFAULT 1,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Prevent over-allocation via application logic (not DB trigger in SQLite pilot)
-- RULE: SUM(allocation_pct) WHERE employee_id = X AND is_active = 1 MUST NOT exceed 100
-- This is enforced in allocations router before INSERT

CREATE TABLE demand_requests (
    id                       INTEGER PRIMARY KEY AUTOINCREMENT,
    project_name             TEXT NOT NULL,
    required_role            TEXT NOT NULL,
    required_skills          TEXT NOT NULL,  -- JSON array: ["React","TypeScript"]
    start_date               DATE NOT NULL,
    duration_months          INTEGER,
    allocation_pct           INTEGER NOT NULL CHECK (allocation_pct BETWEEN 1 AND 100),
    grade_required           TEXT NOT NULL,
    priority                 TEXT NOT NULL DEFAULT 'Normal'
                             CHECK (priority IN ('Urgent','High','Normal')),
    status                   TEXT NOT NULL DEFAULT 'OPEN'
                             CHECK (status IN ('OPEN','PENDING','FULFILLED','DECLINED')),
    raised_by_user_id        INTEGER NOT NULL REFERENCES users(id),
    fulfilled_by_employee_id INTEGER REFERENCES employees(id),
    decline_reason           TEXT,
    notes                    TEXT,
    created_at               DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for dashboard query performance
CREATE INDEX idx_employees_bench_status ON employees(bench_status) WHERE is_deleted = 0;
CREATE INDEX idx_allocations_employee_active ON allocations(employee_id, is_active);
CREATE INDEX idx_allocations_end_date ON allocations(end_date, is_active);
CREATE INDEX idx_demand_status ON demand_requests(status);
CREATE INDEX idx_skills_employee ON skills(employee_id);
```

---

## Key Business Rules (Enforced in Application Code)

| Rule | Where Enforced | Description |
|---|---|---|
| No over-allocation | `routers/allocations.py` | Before INSERT, query SUM of active allocation_pct for employee. If sum + new > 100, return 422 error. |
| Soft delete only | `routers/employees.py` | SET is_deleted = 1, never DELETE FROM employees |
| Bench status auto-update | `services/bench_service.py` | When all allocations for an employee end, set bench_status = 'BENCH' |
| RBAC on every endpoint | `middleware/auth.py` | JWT role claim checked against required role for every route |
| Demand scoped to raiser | `routers/demand.py` | Solution Owner can only SELECT their own demand_requests |

---

*Document owner: Architect | Status: APPROVED*
