# Architecture — Resource 360
## TEG AI Adoption Pilot | Phase 1 Deliverable 02

---

## 1. System Overview

```
┌─────────────────────────────────────────────────────────┐
│                    Browser (React 18)                    │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐              │
│  │ Resource │  │  Ops     │  │ Solution │              │
│  │ Manager  │  │ Manager  │  │  Owner   │              │
│  │   View   │  │   View   │  │   View   │              │
│  └──────────┘  └──────────┘  └──────────┘              │
│         React Router + Role Guard (RBAC)                 │
│         React Query (API State Management)               │
└─────────────────────┬───────────────────────────────────┘
                      │ HTTPS / REST
┌─────────────────────▼───────────────────────────────────┐
│               FastAPI (Python 3.11)                      │
│  ┌────────────┐  ┌────────────┐  ┌────────────────────┐ │
│  │ /employees │  │ /allocations│  │ /demand-requests   │ │
│  │ /skills    │  │ /projects  │  │ /ai/suggestions    │ │
│  │ /auth      │  │ /dashboard │  │ /ai/readiness      │ │
│  └────────────┘  └────────────┘  └────────────────────┘ │
│         JWT Auth Middleware (role enforcement)            │
│         SQLAlchemy ORM (scoped queries)                  │
└──────────────┬──────────────────────┬────────────────────┘
               │                      │
┌──────────────▼───────┐    ┌─────────▼──────────────────┐
│   SQLite Database     │    │   Anthropic Claude API      │
│   (pilot only)        │    │   claude-sonnet-4-20250514  │
│   schema.sql          │    │   Candidate ranking +       │
│                       │    │   Readiness summaries       │
└───────────────────────┘    └─────────────────────────────┘
```

---

## 2. Technology Decisions

| Layer | Technology | Rationale |
|---|---|---|
| Frontend | React 18 + TypeScript | Typed, component-based, standard TEG stack |
| API Framework | FastAPI (Python 3.11) | Fast to develop, auto-generates OpenAPI spec, async-ready |
| ORM | SQLAlchemy 2.0 | Mature, supports SQLite for pilot and PostgreSQL for production |
| Database (pilot) | SQLite | Zero infrastructure for pilot; schema is DB-agnostic |
| Auth | JWT (python-jose) | Simple for pilot; can be replaced with SSO in production |
| AI Integration | Anthropic Claude API | Candidate ranking and readiness summaries |
| State Management | React Query (TanStack) | Server state caching, loading states, error handling |
| Styling | Tailwind CSS | Rapid UI development |
| Testing (BE) | pytest + httpx | API-level integration tests |
| Testing (FE) | Vitest + React Testing Library | Component and RBAC tests |
| Containerisation | Docker Compose | Local pilot deployment |

---

## 3. Project Directory Structure

```
resource360/
├── CLAUDE.md                          # AI governance constitution
├── README.md                          # Setup and run instructions
├── docker-compose.yml                 # Pilot deployment
├── .env.example                       # Required environment variables
├── .claude/
│   ├── settings.json                  # Permissions and hooks
│   └── commands/                      # Custom slash commands
│       ├── review-scope.md
│       ├── generate-feature.md
│       └── ai-boundary-check.md
│
├── backend/
│   ├── main.py                        # FastAPI app entry point
│   ├── requirements.txt
│   ├── .env                           # Not committed
│   ├── database.py                    # SQLAlchemy engine and session
│   ├── models/
│   │   ├── __init__.py
│   │   ├── employee.py                # Employee, Skill, Certification
│   │   ├── project.py                 # Project, Allocation
│   │   ├── demand.py                  # DemandRequest
│   │   └── user.py                    # User, Role
│   ├── routers/
│   │   ├── __init__.py
│   │   ├── auth.py                    # POST /auth/login, /auth/me
│   │   ├── employees.py               # CRUD /employees
│   │   ├── skills.py                  # /employees/{id}/skills
│   │   ├── allocations.py             # /allocations
│   │   ├── projects.py                # /projects
│   │   ├── demand.py                  # /demand-requests
│   │   ├── dashboard.py               # /dashboard/*
│   │   └── ai.py                      # /ai/suggestions, /ai/readiness
│   ├── schemas/
│   │   ├── employee.py                # Pydantic request/response schemas
│   │   ├── allocation.py
│   │   ├── demand.py
│   │   └── ai.py
│   ├── services/
│   │   ├── ai_service.py              # Claude API integration
│   │   └── rbac.py                    # Role enforcement helpers
│   ├── middleware/
│   │   └── auth.py                    # JWT validation middleware
│   ├── seed/
│   │   └── seed_data.py               # Pilot seed data (anonymised)
│   └── tests/
│       ├── conftest.py
│       ├── test_employees.py
│       ├── test_allocations.py
│       ├── test_demand.py
│       ├── test_rbac.py               # All RBAC rules tested
│       └── test_ai.py
│
├── frontend/
│   ├── package.json
│   ├── tsconfig.json
│   ├── tailwind.config.js
│   ├── vite.config.ts
│   ├── index.html
│   └── src/
│       ├── main.tsx
│       ├── App.tsx
│       ├── types/                     # TypeScript interfaces
│       │   ├── employee.ts
│       │   ├── allocation.ts
│       │   ├── demand.ts
│       │   └── auth.ts
│       ├── api/                       # React Query hooks
│       │   ├── employees.ts
│       │   ├── allocations.ts
│       │   ├── demand.ts
│       │   └── ai.ts
│       ├── components/
│       │   ├── RoleGuard.tsx          # RBAC enforcement component
│       │   ├── layout/
│       │   │   ├── Sidebar.tsx
│       │   │   └── Topbar.tsx
│       │   ├── employees/
│       │   │   ├── EmployeeProfile.tsx
│       │   │   ├── EmployeeTable.tsx
│       │   │   └── AllocationForm.tsx
│       │   ├── dashboards/
│       │   │   ├── BenchDashboard.tsx
│       │   │   ├── RolloffTracker.tsx
│       │   │   └── DemandPanel.tsx
│       │   ├── demand/
│       │   │   ├── DemandForm.tsx
│       │   │   └── DemandStatus.tsx
│       │   └── ai/
│       │       ├── CandidateSuggestions.tsx
│       │       └── ReadinessSummary.tsx
│       └── pages/
│           ├── LoginPage.tsx
│           ├── DashboardPage.tsx
│           ├── BenchPage.tsx
│           ├── RolloffPage.tsx
│           ├── EmployeeProfilePage.tsx
│           ├── DemandRequestPage.tsx
│           ├── AISuggestionsPage.tsx
│           └── SettingsPage.tsx
│
├── features/                          # Gherkin feature files
│   ├── employee-profile.feature
│   ├── allocation-management.feature
│   ├── rbac-enforcement.feature
│   ├── bench-dashboard.feature
│   ├── rolloff-tracker.feature
│   ├── demand-request.feature
│   └── ai-suggestions.feature
│
├── docs/
│   ├── requirements/
│   │   ├── problem-statement.md
│   │   ├── scope.md
│   │   ├── user-personas.md
│   │   └── user-workflows.md
│   ├── architecture/
│   │   ├── architecture.md            # This file
│   │   ├── schema.md                  # ER diagram + table descriptions
│   │   └── api-spec.yaml             # OpenAPI specification
│   └── wireframes/
│       └── wireframe.md              # Screen descriptions and flows
│
└── delivery/
    ├── phase1-signoff.md             # Architect sign-off record
    ├── ai-usage-log.md               # AI touchpoints and time savings
    ├── productionisation-considerations.md
    └── future-roadmap.md
```

---

## 4. Architecture Decisions Record (ADR)

### ADR-001: SQLite for Pilot
**Decision:** Use SQLite for Phase 1 pilot.
**Rationale:** Zero infrastructure, no cloud costs, instant setup for demo.
**Consequence:** Schema must use ANSI SQL only — no SQLite-specific syntax. Migration path to PostgreSQL documented in productionisation considerations.

### ADR-002: JWT Auth (No SSO)
**Decision:** JWT-based authentication with hardcoded pilot users.
**Rationale:** SSO integration (Azure AD, Okta) is complex and out of pilot scope.
**Consequence:** Three pilot users pre-seeded: one per role. SSO is Phase 2.

### ADR-003: Claude API for AI Features Only
**Decision:** Claude API is used only for candidate ranking and readiness summaries.
**Rationale:** AI assists the Resource Manager — it does not make autonomous allocation decisions. Human confirms every AI suggestion.
**Consequence:** AI suggestions are always advisory. Confirmation step is mandatory.

### ADR-004: No Real Email Notifications
**Decision:** All notifications are in-app banners only for the pilot.
**Rationale:** SMTP/SES setup is infrastructure overhead not justified for a 2-week pilot.
**Consequence:** Demand fulfilment notifications are visible only when the user is logged in.

---

*Document owner: Architect | Status: APPROVED — locked for Phase 1*
