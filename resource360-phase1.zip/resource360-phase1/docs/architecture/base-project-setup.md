# Base Project Setup — Resource 360
## TEG AI Adoption Pilot | Phase 2 Scaffold Plan

---

## Overview

This is the **exact command sequence** to scaffold the complete Resource 360 project from scratch. Follow these steps in order to build the entire Phase 1 deliverable.

**Estimated Setup Time:** 45 minutes
**Prerequisites:** Docker, Node.js 18+, Python 3.11+, git

---

## Step 1: Project Structure Initialization (5 minutes)

```bash
# Create root directory and navigate
mkdir resource360-phase1
cd resource360-phase1

# Initialize git repository
git init
echo "# Resource 360 - Employee Allocation Platform" > README.md
git add README.md
git commit -m "[p1][init] initial project setup"

# Create complete directory structure
mkdir -p {backend,frontend,docs,features,delivery}
mkdir -p backend/{models,routers,schemas,services,middleware,seed,tests}
mkdir -p frontend/src/{components,pages,types,api,utils,hooks}
mkdir -p frontend/src/components/{layout,employees,dashboards,demand,ai}
mkdir -p docs/{requirements,architecture,wireframes}
mkdir -p .claude/{commands,memory}

# Copy documentation files (assume they exist)
# Note: In real scenario, these would be created first or copied from templates
```

---

## Step 2: Backend Setup - FastAPI Foundation (15 minutes)

### 2.1 Python Environment & Dependencies

```bash
# Navigate to backend
cd backend

# Create virtual environment
python3.11 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Create requirements.txt
cat > requirements.txt << 'EOF'
fastapi==0.111.0
uvicorn==0.29.0
sqlalchemy==2.0.30
pydantic==2.7.1
anthropic==0.26.0
python-jose[cryptography]==3.3.0
passlib[bcrypt]==1.7.4
pytest==8.2.0
httpx==0.27.0
python-dotenv==1.0.1
alembic==1.13.1
EOF

# Install dependencies
pip install -r requirements.txt

# Create .env template
cat > .env.example << 'EOF'
DATABASE_URL=sqlite:///./resource360.db
SECRET_KEY=your-secret-key-here-change-in-production
ANTHROPIC_API_KEY=sk-your-claude-api-key-here
JWT_ALGORITHM=HS256
JWT_EXPIRATION_HOURS=8
ENVIRONMENT=pilot
EOF

# Copy to actual .env (user will need to fill real values)
cp .env.example .env
```

### 2.2 Database Models

```bash
# Create database.py
cat > database.py << 'EOF'
"""Database configuration and session management."""
import os
from sqlalchemy import create_engine, event
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.engine import Engine
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./resource360.db")

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {}
)

@event.listens_for(Engine, "connect")
def set_sqlite_pragma(dbapi_connection, connection_record):
    """Enable foreign key constraints in SQLite."""
    if "sqlite" in str(dbapi_connection):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    """Database dependency for FastAPI."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
EOF

# Create schema.sql from the documented schema
cat > schema.sql << 'EOF'
PRAGMA foreign_keys = ON;

CREATE TABLE users (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    email       TEXT NOT NULL UNIQUE,
    password    TEXT NOT NULL,
    name        TEXT NOT NULL,
    role        TEXT NOT NULL CHECK (role IN ('RESOURCE_MANAGER','OPERATIONS_MANAGER','SOLUTION_OWNER')),
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE projects (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    description TEXT,
    status      TEXT NOT NULL DEFAULT 'ACTIVE'
                CHECK (status IN ('ACTIVE','COMPLETED','CANCELLED','ON_HOLD')),
    start_date  DATE,
    end_date    DATE,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE employees (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT NOT NULL,
    email        TEXT NOT NULL UNIQUE,
    grade        TEXT NOT NULL,
    department   TEXT NOT NULL,
    location     TEXT NOT NULL,
    bench_status TEXT NOT NULL DEFAULT 'BENCH'
                 CHECK (bench_status IN ('ALLOCATED','BENCH','ROLLING_OFF','ON_LEAVE')),
    is_deleted   INTEGER NOT NULL DEFAULT 0,
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE skills (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    skill_name  TEXT NOT NULL,
    proficiency TEXT NOT NULL DEFAULT 'Proficient'
                CHECK (proficiency IN ('Beginner','Proficient','Expert')),
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE certifications (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    cert_name   TEXT NOT NULL,
    expires_on  DATE,
    status      TEXT NOT NULL DEFAULT 'Active'
                CHECK (status IN ('Active','Expiring','Expired')),
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE allocations (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id     INTEGER NOT NULL REFERENCES employees(id),
    project_id      INTEGER NOT NULL REFERENCES projects(id),
    project_role    TEXT NOT NULL,
    allocation_pct  INTEGER NOT NULL CHECK (allocation_pct BETWEEN 1 AND 100),
    start_date      DATE NOT NULL,
    end_date        DATE,
    is_active       INTEGER NOT NULL DEFAULT 1,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE demand_requests (
    id                       INTEGER PRIMARY KEY AUTOINCREMENT,
    project_name             TEXT NOT NULL,
    required_role            TEXT NOT NULL,
    required_skills          TEXT NOT NULL,
    start_date               DATE NOT NULL,
    duration_months          INTEGER,
    allocation_pct           INTEGER NOT NULL CHECK (allocation_pct BETWEEN 1 AND 100),
    grade_required           TEXT NOT NULL,
    priority                 TEXT NOT NULL DEFAULT 'Normal'
                             CHECK (priority IN ('Urgent','High','Normal')),
    status                   TEXT NOT NULL DEFAULT 'OPEN'
                             CHECK (status IN ('OPEN','PENDING','FULFILLED','DECLINED')),
    raised_by_user_id        INTEGER NOT NULL REFERENCES users(id),
    fulfilled_by_employee_id INTEGER REFERENCES employees(id),
    decline_reason           TEXT,
    notes                    TEXT,
    created_at               DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Performance indexes
CREATE INDEX idx_employees_bench_status ON employees(bench_status) WHERE is_deleted = 0;
CREATE INDEX idx_allocations_employee_active ON allocations(employee_id, is_active);
CREATE INDEX idx_allocations_end_date ON allocations(end_date, is_active);
CREATE INDEX idx_demand_status ON demand_requests(status);
CREATE INDEX idx_skills_employee ON skills(employee_id);
EOF
```

### 2.3 Core FastAPI Application

```bash
# Create main.py
cat > main.py << 'EOF'
"""FastAPI application entry point."""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from database import engine, Base
import os
from dotenv import load_dotenv

load_dotenv()

# Create database tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Resource 360 API",
    description="Employee Allocation Platform — TEG AI Pilot Phase 1",
    version="1.0.0-pilot"
)

# Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["localhost", "127.0.0.1", "0.0.0.0"]
)

@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "service": "resource360-api"}

# Import and include routers (will be created by Claude Code)
# from routers import auth, employees, allocations, demand, dashboard, ai
# app.include_router(auth.router, prefix="/auth", tags=["authentication"])
# app.include_router(employees.router, prefix="/employees", tags=["employees"])
# app.include_router(allocations.router, prefix="/allocations", tags=["allocations"])
# app.include_router(demand.router, prefix="/demand-requests", tags=["demand"])
# app.include_router(dashboard.router, prefix="/dashboard", tags=["dashboard"])
# app.include_router(ai.router, prefix="/ai", tags=["ai"])

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
EOF

# Navigate back to root
cd ..
```

---

## Step 3: Frontend Setup - React 18 Foundation (15 minutes)

### 3.1 React Application Initialization

```bash
# Navigate to frontend
cd frontend

# Create package.json
cat > package.json << 'EOF'
{
  "name": "resource360-frontend",
  "private": true,
  "version": "1.0.0-pilot",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "lint": "eslint . --ext ts,tsx --report-unused-disable-directives --max-warnings 0",
    "preview": "vite preview",
    "test": "vitest",
    "test:ui": "vitest --ui"
  },
  "dependencies": {
    "react": "18.3.1",
    "react-dom": "18.3.1",
    "typescript": "5.4.5",
    "@tanstack/react-query": "5.40.0",
    "react-router-dom": "6.23.1",
    "axios": "1.7.2",
    "tailwindcss": "3.4.4"
  },
  "devDependencies": {
    "@types/react": "^18.3.3",
    "@types/react-dom": "^18.3.0",
    "@typescript-eslint/eslint-plugin": "^7.13.1",
    "@typescript-eslint/parser": "^7.13.1",
    "@vitejs/plugin-react": "^4.3.1",
    "eslint": "^8.57.0",
    "eslint-plugin-react-hooks": "^4.6.2",
    "eslint-plugin-react-refresh": "^0.4.7",
    "vite": "^5.3.1",
    "vitest": "1.6.0",
    "@testing-library/react": "16.0.0",
    "@testing-library/jest-dom": "^6.4.6",
    "autoprefixer": "^10.4.19",
    "postcss": "^8.4.38"
  }
}
EOF

# Install dependencies
npm install

# Create TypeScript config
cat > tsconfig.json << 'EOF'
{
  "compilerOptions": {
    "target": "ES2020",
    "useDefineForClassFields": true,
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "react-jsx",
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true,
    "baseUrl": "./src",
    "paths": {
      "@/*": ["./*"]
    }
  },
  "include": ["src"],
  "references": [{ "path": "./tsconfig.node.json" }]
}
EOF

# Create Vite config
cat > vite.config.ts << 'EOF'
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    port: 3000,
    proxy: {
      '/api': {
        target: 'http://localhost:8000',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, ''),
      },
    },
  },
  test: {
    globals: true,
    environment: 'jsdom',
    setupFiles: ['./src/test/setup.ts'],
  },
})
EOF

# Create Tailwind config
cat > tailwind.config.js << 'EOF'
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#f3f1ff',
          500: '#5b4fcf',
          600: '#4c44b8',
          700: '#3d3698',
        },
        success: {
          50: '#f0fdf4',
          500: '#10b981',
          600: '#059669',
        },
        warning: {
          50: '#fffbeb',
          500: '#f59e0b',
          600: '#d97706',
        },
        error: {
          50: '#fef2f2',
          500: '#ef4444',
          600: '#dc2626',
        },
      },
    },
  },
  plugins: [],
}
EOF

# Create PostCSS config
cat > postcss.config.js << 'EOF'
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
EOF
```

### 3.2 Core React Application Structure

```bash
# Create index.html
cat > index.html << 'EOF'
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Resource 360 - Employee Allocation Platform</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
EOF

# Create main.tsx
cat > src/main.tsx << 'EOF'
import React from 'react'
import ReactDOM from 'react-dom/client'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { BrowserRouter } from 'react-router-dom'
import App from './App.tsx'
import './index.css'

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      retry: 1,
    },
  },
})

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </QueryClientProvider>
  </React.StrictMode>,
)
EOF

# Create CSS file with Tailwind
cat > src/index.css << 'EOF'
@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  html {
    font-family: 'Inter', system-ui, sans-serif;
  }
}

@layer components {
  .btn-primary {
    @apply bg-primary-500 hover:bg-primary-600 text-white font-medium py-2 px-4 rounded-lg transition-colors;
  }
  
  .btn-secondary {
    @apply bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium py-2 px-4 rounded-lg border transition-colors;
  }
  
  .status-badge {
    @apply inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium;
  }
  
  .status-badge-success {
    @apply bg-success-50 text-success-600;
  }
  
  .status-badge-warning {
    @apply bg-warning-50 text-warning-600;
  }
  
  .status-badge-error {
    @apply bg-error-50 text-error-600;
  }
}
EOF

# Create App.tsx stub
cat > src/App.tsx << 'EOF'
import { Routes, Route, Navigate } from 'react-router-dom'

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Routes>
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/login" element={<div>Login Page - To be implemented by Claude Code</div>} />
        <Route path="/dashboard" element={<div>Dashboard - To be implemented by Claude Code</div>} />
        {/* Additional routes will be added by Claude Code based on wireframe.md */}
      </Routes>
    </div>
  )
}

export default App
EOF

# Create test setup
mkdir -p src/test
cat > src/test/setup.ts << 'EOF'
import '@testing-library/jest-dom'
EOF

# Navigate back to root
cd ..
```

---

## Step 4: Docker Setup (5 minutes)

```bash
# Create docker-compose.yml for the complete environment
cat > docker-compose.yml << 'EOF'
version: '3.8'

services:
  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=sqlite:///./data/resource360.db
      - SECRET_KEY=pilot-secret-key-change-in-production
      - ANTHROPIC_API_KEY=${ANTHROPIC_API_KEY}
    volumes:
      - ./backend:/app
      - backend_data:/app/data
    command: uvicorn main:app --host 0.0.0.0 --port 8000 --reload

  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    ports:
      - "3000:3000"
    environment:
      - VITE_API_URL=http://localhost:8000
    volumes:
      - ./frontend:/app
      - /app/node_modules
    command: npm run dev
    depends_on:
      - backend

volumes:
  backend_data:
EOF

# Create backend Dockerfile
cat > backend/Dockerfile << 'EOF'
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

RUN mkdir -p data

EXPOSE 8000

CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
EOF

# Create frontend Dockerfile
cat > frontend/Dockerfile << 'EOF'
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install

COPY . .

EXPOSE 3000

CMD ["npm", "run", "dev", "--", "--host", "0.0.0.0"]
EOF

# Create .dockerignore files
cat > backend/.dockerignore << 'EOF'
venv/
__pycache__/
*.pyc
.env
.git/
.pytest_cache/
EOF

cat > frontend/.dockerignore << 'EOF'
node_modules/
dist/
.git/
.env.local
.env.development.local
.env.test.local
.env.production.local
EOF
```

---

## Step 5: Environment & Git Setup (5 minutes)

```bash
# Create root .gitignore
cat > .gitignore << 'EOF'
# Environment files
.env
.env.local
.env.*.local

# Database
*.db
*.sqlite
*.sqlite3

# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
pip-wheel-metadata/
share/python-wheels/
*.egg-info/
.installed.cfg
*.egg
MANIFEST
backend/venv/

# Node
node_modules/
npm-debug.log*
yarn-debug.log*
yarn-error.log*
pnpm-debug.log*
frontend/dist/

# IDEs
.vscode/
.idea/
*.swp
*.swo
*~

# OS
.DS_Store
Thumbs.db

# Docker
.dockerignore

# Logs
logs/
*.log

# Claude Code specific
.claude/local/
EOF

# Create development setup script
cat > setup.sh << 'EOF'
#!/bin/bash
set -e

echo "🚀 Setting up Resource 360 development environment..."

# Check prerequisites
command -v python3.11 >/dev/null 2>&1 || { echo "❌ Python 3.11 is required"; exit 1; }
command -v node >/dev/null 2>&1 || { echo "❌ Node.js is required"; exit 1; }
command -v docker >/dev/null 2>&1 || { echo "❌ Docker is required"; exit 1; }

# Setup backend
echo "📦 Setting up backend..."
cd backend
python3.11 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
echo "✅ Backend dependencies installed"
cd ..

# Setup frontend
echo "🎨 Setting up frontend..."
cd frontend
npm install
echo "✅ Frontend dependencies installed"
cd ..

# Initialize database
echo "🗄️ Initializing database..."
cd backend
source venv/bin/activate
sqlite3 resource360.db < schema.sql
echo "✅ Database initialized"
cd ..

echo "🎉 Setup complete! Run 'docker-compose up' to start the application."
EOF

chmod +x setup.sh

# Create README.md with setup instructions
cat > README.md << 'EOF'
# Resource 360 - Employee Allocation Platform

TEG AI Adoption Pilot | Phase 1 Deliverable

## Quick Start

1. **Prerequisites**: Python 3.11, Node.js 18+, Docker
2. **Setup**: `./setup.sh`
3. **Run**: `docker-compose up`
4. **Access**: Frontend at http://localhost:3000, API at http://localhost:8000

## Development

### Backend (FastAPI)
```bash
cd backend
source venv/bin/activate
uvicorn main:app --reload
```

### Frontend (React)
```bash
cd frontend
npm run dev
```

### Testing
```bash
# Backend tests
cd backend && pytest

# Frontend tests  
cd frontend && npm test
```

## Architecture

See `docs/architecture/` for complete system design, API specs, and database schema.

## Phase 1 Scope

6 modules: Employee Profiles, Allocations, RBAC, Dashboards, Demand Workflow, AI Suggestions.
See `docs/requirements/scope.md` for details.
EOF
```

---

## Final Verification Commands

```bash
# Verify project structure
find . -type f -name "*.py" -o -name "*.tsx" -o -name "*.ts" -o -name "*.yml" | head -20

# Test backend startup
cd backend && source venv/bin/activate && python -c "import main; print('✅ Backend imports successful')"

# Test frontend compilation
cd frontend && npm run build --dry-run || npm run type-check || echo "✅ Frontend setup complete"

# Final git commit
git add .
git commit -m "[p1][setup] complete project scaffold - ready for Claude Code development"

echo "🎉 Project scaffold complete! Ready for Phase 2 development with Claude Code."
echo "📋 Next: Run 'docker-compose up' and start implementing with Claude Code."
```

---

## Next Steps for Claude Code

1. **Generate Models**: Use Claude Code to create SQLAlchemy models in `backend/models/`
2. **Generate Schemas**: Create Pydantic schemas in `backend/schemas/`
3. **Generate Routers**: Implement FastAPI routers based on `api-spec.yaml`
4. **Generate Components**: Create React components based on `wireframe.md`
5. **Generate Tests**: Write comprehensive test suites
6. **Generate Seed Data**: Create realistic anonymized pilot data

**Estimated Claude Code Development Time:** 8-12 hours across 6 modules