# Scope — Resource 360 · Phase 1
## TEG AI Adoption Pilot | Phase 1 Deliverable 01

---

## IN SCOPE (Must Build for Phase 1 Pilot)

> **RULE: Claude Code must check this list before generating any code or feature.**
> If a task does not map to an item below, it is OUT OF SCOPE.

### Module 1: Employee Profile Management
- [ ] Create an employee record with: name, email, grade, department, location, role
- [ ] Add/edit/remove skills on an employee profile (skill name + proficiency level: Beginner / Proficient / Expert)
- [ ] Add/edit certifications with expiry date and active/expired status
- [ ] View full employee 360° profile: current allocations, skills, certifications, project history
- [ ] Soft-delete an employee record (is_deleted flag — not hard delete)
- [ ] Bench status transitions: ALLOCATED → ROLLING_OFF → BENCH → ALLOCATED

### Module 2: Allocation Management
- [ ] Assign an employee to a project with: start date, end date, allocation %, project role
- [ ] Validate that total allocation across active projects does not exceed 100%
- [ ] Block and return an error when over-allocation is attempted
- [ ] Handle partial allocation (e.g. 60% on Project A + 40% on Project B = 100% — valid)
- [ ] Update allocation end date (roll-off date)
- [ ] Remove an allocation (set end date to today)

### Module 3: Role-Based Access Control
- [ ] JWT authentication with role claim embedded in token
- [ ] Three roles enforced: RESOURCE_MANAGER, OPERATIONS_MANAGER, SOLUTION_OWNER
- [ ] RBAC matrix from CLAUDE.md Section 6 enforced at API and UI level
- [ ] `RoleGuard` component in React that hides/shows UI elements by role
- [ ] 403 response from API for any role-permission violation

### Module 4: Dashboards
- [ ] **Bench Dashboard**: List of employees currently on bench — name, skills, grade, bench since date, location
- [ ] **Roll-off Dashboard**: Upcoming roll-offs in 30 / 60 / 90 day tabs — employee, project, end date, days remaining
- [ ] **Over-allocation Panel**: Employees with total allocation > 100% — name, percentage, affected projects
- [ ] **Open Demand Panel**: All unfulfilled demand requests — role, skills, start date, requesting SO
- [ ] Dashboard filters: filter bench by skill, filter roll-offs by project

### Module 5: Demand Request Workflow
- [ ] Solution Owner submits a demand request: project, required role, required skills, start date, allocation %, grade, priority
- [ ] Resource Manager views open demand requests
- [ ] Resource Manager fulfils demand by confirming an AI suggestion → allocation created
- [ ] Resource Manager declines a demand request with a reason
- [ ] Solution Owner can view status of their own demand requests

### Module 6: AI-Powered Candidate Suggestions (Claude API)
- [ ] Given an open demand request, Claude API returns ranked employee matches
- [ ] Each match includes: match score (%), matched skills, missing skills, availability status
- [ ] AI-generated natural language readiness summary for the top-ranked candidate
- [ ] Skill gap analysis: list skills required by demand but absent from current bench
- [ ] Resource Manager can accept or dismiss an AI suggestion

---

## OUT OF SCOPE (Phase 1 Pilot)

> **RULE: Do not build, scaffold, or generate code for anything in this list.**
> These are recorded here so they can be planned for future phases.

| Item | Reason | Future Phase |
|---|---|---|
| HRMS / SAP / Workday integration | Complex integration — out of pilot scope | Phase 2 |
| Employee self-service portal | Employee login, profile editing, leave requests | Phase 2 |
| Email / SMS notifications | Requires SMTP/SES setup — alerts are in-app only for pilot | Phase 2 |
| SSO / Azure AD / Okta authentication | JWT only for pilot | Phase 2 |
| Multi-tenancy (multiple organisations) | Single-org pilot only | Phase 2 |
| Payroll data / salary fields | PII and compliance complexity | Future |
| BI reporting / data export to Excel | Out of pilot scope | Phase 2 |
| Mobile app (iOS / Android) | Web only for pilot | Future |
| Real-time WebSocket notifications | REST polling acceptable for pilot | Phase 2 |
| File storage (CV uploads, documents) | Local filesystem not suitable for production | Phase 2 |
| Approval workflow for profile changes | Audit trail only — no approval chain | Future |
| Performance management / appraisals | Out of product scope | Future |
| Advanced skill taxonomy / ontology | Free-text skill tags only for pilot | Phase 2 |
| Automated candidate suggestion acceptance | Manual RM confirmation required | Future |

---

## PILOT CONSTRAINTS

| Constraint | Detail |
|---|---|
| Duration | 2 weeks · 3 hours/day |
| Team size | 1 Architect + AI (Claude Code) |
| Database | SQLite (pilot only — must be cloud-DB compatible schema) |
| Auth | JWT only — no SSO |
| Deployment | Local Docker Compose — no cloud deployment for pilot |
| Test data | Seed data only — no real employee PII |
| AI model | claude-sonnet-4-20250514 — candidate ranking and summaries only |

---

*Document owner: Architect | Status: APPROVED — Scope locked for Phase 1*
*Any scope change requires architect sign-off and an update to this file.*
