# User Workflows — Resource 360
## TEG AI Adoption Pilot | Phase 1 Deliverable 01

---

## Workflow 1: Resource Manager — Manage Employee and Fulfil Demand

```
[START]
  │
  ├─► Resource Manager logs in → lands on Operations Dashboard
  │
  ├─► MANAGE EMPLOYEE PROFILE
  │     ├─► Navigate to Bench View
  │     ├─► Search or browse employee list
  │     ├─► Select employee → view 360° profile
  │     ├─► Edit: add/remove skills, update certifications, change grade
  │     └─► Confirm save → profile updated
  │
  ├─► MANAGE ALLOCATION
  │     ├─► From employee profile → click "Add allocation"
  │     ├─► Select project, set allocation %, start/end date
  │     ├─► System validates: total allocation ≤ 100%
  │     │     ├─► ✅ Valid → allocation created, bench status updated
  │     │     └─► ❌ Over 100% → error shown, blocked
  │     └─► Employee moves from BENCH → ALLOCATED
  │
  ├─► FULFIL DEMAND REQUEST
  │     ├─► Open Demand Panel → select urgent open request
  │     ├─► View required skills, grade, start date
  │     ├─► Click "AI Suggestions" → Claude API returns ranked candidates
  │     ├─► Review readiness summary for top candidate
  │     ├─► Confirm allocation → demand marked FULFILLED
  │     └─► Solution Owner notified (in-app alert)
  │
  └─► [END]
```

**Key screens:** Dashboard, Bench View, Employee Profile, Demand Panel, AI Suggestions

---

## Workflow 2: Operations Manager — Monitor Workforce Health

```
[START]
  │
  ├─► Operations Manager logs in → lands on Operations Dashboard
  │
  ├─► BENCH HEALTH CHECK
  │     ├─► View metric: "14 on bench" — click to expand
  │     ├─► Filter bench by skill (e.g. React, AWS)
  │     ├─► Identify skill gaps against known upcoming demand
  │     └─► Note employees on bench > 30 days (risk of disengagement)
  │
  ├─► OVER-ALLOCATION REVIEW
  │     ├─► Dashboard alert: "4 employees over-allocated"
  │     ├─► Click to view: employee name, projects, total %
  │     ├─► Note: Operations Manager CANNOT fix — must flag to RM
  │     └─► Read-only view only
  │
  ├─► ROLL-OFF PLANNING
  │     ├─► Navigate to Roll-off Tracker
  │     ├─► Switch tabs: 30 days / 60 days / 90 days
  │     ├─► Identify employees rolling off with no confirmed next project
  │     ├─► Compare rolling-off skills against Open Demand Panel
  │     └─► Escalate resourcing risk to Resource Manager if needed
  │
  ├─► DEMAND VS SUPPLY ANALYSIS
  │     ├─► View Open Demand Panel: 7 unfulfilled requests
  │     ├─► Check Skill Availability chart vs demanded skills
  │     └─► Identify demand with no bench match → escalate / plan upskilling
  │
  └─► [END]
```

**Key screens:** Dashboard, Roll-off Tracker, Open Demand Panel, Skill Availability Chart

---

## Workflow 3: Solution Owner — Raise and Track a Demand Request

```
[START]
  │
  ├─► Solution Owner logs in → lands on Demand Request screen
  │
  ├─► RAISE DEMAND
  │     ├─► Click "New demand request"
  │     ├─► Fill form:
  │     │     ├─► Project name
  │     │     ├─► Required role (e.g. Senior React Developer)
  │     │     ├─► Required skills (multi-select tags)
  │     │     ├─► Start date, duration, allocation %
  │     │     ├─► Grade required
  │     │     └─► Priority (Urgent / High / Normal) and notes
  │     ├─► Submit → demand request created with status: OPEN
  │     └─► Resource Manager receives in-app notification
  │
  ├─► TRACK DEMAND STATUS
  │     ├─► View "My open requests" panel
  │     ├─► Status transitions:
  │     │     ├─► OPEN → Resource Manager reviewing
  │     │     ├─► PENDING → RM found a candidate, confirming allocation
  │     │     ├─► FULFILLED → Allocation confirmed, employee assigned
  │     │     └─► DECLINED → RM declined with reason (no match / timing)
  │     └─► View which employee was assigned (if fulfilled)
  │
  └─► [END]
```

**Key screens:** Demand Request Form, My Requests Panel

---

## End-to-End Cross-Role Flow: Demand to Fulfilment

```
Solution Owner          Resource Manager         System (AI)
─────────────           ────────────────         ──────────
Raises demand ────────► Receives notification
                        Views demand details
                        Clicks "AI Suggestions" ──────────► Claude API receives:
                                                             - Required skills
                                                             - Grade
                                                             - Availability window
                                                ◄────────── Returns ranked candidates
                                                             with match scores
                        Reviews top candidate
                        Reads readiness summary
                        Confirms allocation
Notified: FULFILLED ◄── Demand marked fulfilled
Views assigned employee
```

---

*Document owner: Architect | Status: APPROVED*
