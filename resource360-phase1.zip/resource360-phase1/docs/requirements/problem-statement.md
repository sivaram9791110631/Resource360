# Problem Statement — Resource 360
## TEG AI Adoption Pilot | Phase 1 Deliverable 01

---

## 1. Problem Statement

Resource Managers at TEG track employee allocations in spreadsheets. Solution Owners manually chase resource availability by calling or emailing Resource Managers. Operations Managers have no real-time view of bench strength, skill gaps, or over-allocation risks.

There is no single system connecting employee profiles, project demand, and real-time availability — leading to allocation conflicts, wasted bench time, missed demand opportunities, and reactive rather than proactive workforce planning.

---

## 2. Business Impact (Current State)

| Pain Point | Impact |
|---|---|
| Spreadsheet-based allocation tracking | Data out of date within hours; no single source of truth |
| Manual resource chasing | 2–4 hours/week per Solution Owner lost to status emails |
| No over-allocation detection | Engineers accidentally double-booked; projects under-delivered |
| No bench visibility | Available talent not matched to demand; bench time wasted |
| No skill gap awareness | Demand raised for skills that don't exist on the bench |
| Reactive roll-off planning | Resource gaps discovered too late to fill |

---

## 3. Stakeholder Map

| Role | Name / Type | What They Need |
|---|---|---|
| Resource Manager | Internal TEG staff (e.g. Meera G) | A single place to manage all employee profiles, allocations, and availability |
| Operations Manager | Leadership / ops (e.g. Raj K) | Real-time dashboard of bench health, over-allocation risks, and demand pipeline |
| Solution Owner | Project lead / SO (e.g. Anita P) | Self-serve view of available resources, ability to raise demand requests, track fulfilment |
| Employee | Individual contributor | (Out of scope for Phase 1 — self-service portal is future roadmap) |

---

## 4. Proposed Solution — Resource 360

A web-based Employee Allocation Platform that provides:

1. **Employee 360° Profile** — Skills, certifications, allocation %, bench status, project history, roll-off date
2. **Role-Based Access Control** — Three distinct role views: Resource Manager, Operations Manager, Solution Owner
3. **Operational Dashboards** — Bench view, roll-off tracker (30/60/90 days), over-allocation alerts, open demand panel
4. **Demand Request Workflow** — Solution Owners raise structured demand; Resource Managers fulfil via AI-ranked candidates
5. **AI-Powered Matching** — Claude API ranks bench employees against open demand by skill fit, availability, and grade

---

## 5. Success Criteria (Phase 1 Pilot)

| Criterion | Measure |
|---|---|
| Resource Manager can manage profiles end-to-end | Create, update, allocate employee in < 3 clicks |
| Over-allocation is prevented | System blocks any allocation that would push total > 100% |
| Operations Manager has real-time bench view | Dashboard shows current bench count, skills, days on bench |
| Solution Owner can raise and track demand | Full demand-to-fulfilment workflow in one interface |
| AI candidate suggestion works | Given a demand request, system returns ranked candidates with match score |

---

## 6. What This Is Not (Phase 1 Scope Boundary)

- Not a payroll or HR system
- Not integrated with any existing HRMS
- Not a self-service employee portal
- Not a reporting/BI platform
- Not production-ready (pilot only — see `delivery/productionisation-considerations.md`)

---

## 7. AI Acceleration Points Identified

| Phase | AI Tool | What AI Accelerates |
|---|---|---|
| Discovery | Claude (chat) | Problem framing, requirements structuring, Gherkin generation |
| Architecture | Claude Code (plan mode) | Data model proposals, API spec drafting, ER diagram |
| Build | Claude Code | Component scaffolding, RBAC logic, API endpoints, test generation |
| AI Feature | Claude API | Candidate ranking, readiness summaries, skill gap analysis |
| UAT | Claude Code | Test scenario generation, defect diagnosis |
| Docs | Claude Code | Release notes, productionisation gaps, AI usage summary |

---

*Document owner: Architect | Status: DRAFT — pending Phase 1 sign-off*
