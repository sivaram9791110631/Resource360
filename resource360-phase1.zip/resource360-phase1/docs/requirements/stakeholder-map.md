# Stakeholder Map — Resource 360
## TEG AI Adoption Pilot | Phase 1 Deliverable

---

## Overview

This document provides a comprehensive mapping of all stakeholders involved in the Resource 360 project, their needs, pain points, and influence on project success. The stakeholder analysis helps prioritize features and ensure solution alignment with user needs.

---

## Primary Stakeholders (Phase 1 In-Scope)

### 1. Resource Manager
**Representative:** Meera Gupta  
**Role in System:** RESOURCE_MANAGER (Full Access)  
**Department:** TEG Engineering Practice  
**Scope:** Manages 40-60 employee profiles across engineering practice

#### What They Need
- Single place to view all employee profiles, skills, and current allocations
- Ability to quickly see who is on bench and match them to incoming demand
- Confidence that allocations are not double-counted or conflicting
- Faster fulfilment of demand requests without email chasing
- Real-time validation to prevent over-allocation scenarios

#### Pain Points Today
- **Data Staleness:** Spreadsheet goes stale within hours of an update
- **No Search Capability:** Has to scroll manually through employee list to find skills
- **Over-allocation Discovery:** Regularly discovers conflicts after projects have started
- **Reactive Planning:** No visibility of upcoming roll-offs until the last week
- **Manual Chasing:** 2-4 hours/week lost fielding "who's available?" requests from Solution Owners
- **No Single Source of Truth:** Multiple versions of allocation data across stakeholders

#### Influence Level: **HIGH** | Interest Level: **HIGH**
- **Primary System Owner** — responsible for data accuracy and allocation decisions
- **Business Process Owner** — controls current allocation workflow
- **Success Blocker** — system fails without Resource Manager adoption

---

### 2. Operations Manager  
**Representative:** Raj Kumar  
**Role in System:** OPERATIONS_MANAGER (Read-Heavy Access)  
**Department:** TEG Delivery Operations  
**Scope:** Bench health and delivery capacity across entire practice

#### What They Need
- Real-time dashboard showing bench count, bench skills, and days on bench
- Early warning on upcoming roll-offs — 30, 60, 90 day view
- Visibility into over-allocation risks before they become delivery problems
- Understanding of open demand versus available supply
- Aggregated view of skill availability across the practice

#### Pain Points Today
- **Delayed Information:** Currently relies on weekly status emails from Resource Managers
- **Reactive Problem Solving:** Finds out about over-allocation after escalations from project managers
- **No Skill Visibility:** Cannot see aggregated view of skill availability across practice
- **Planning Blindness:** Cannot anticipate bench gaps for incoming demand pipeline
- **No Early Warning:** Discovers resource gaps too late to fill effectively

#### Influence Level: **HIGH** | Interest Level: **MEDIUM**
- **Executive Sponsor** — senior leadership backing for project success
- **Budget Authority** — controls resource allocation for pilot
- **Strategic User** — uses data for workforce planning decisions

---

### 3. Solution Owner
**Representative:** Anita Pillai  
**Role in System:** SOLUTION_OWNER (Limited Access)  
**Department:** Project Delivery  
**Scope:** Owns delivery of client projects, responsible for team resourcing

#### What They Need
- Self-serve view of broadly what skills are available (without full employee details)
- Simple way to raise a structured resource request
- Status tracking of demand requests — is it pending, fulfilled, or declined?
- Faster resource fulfilment so projects can start on time
- Transparency into resourcing pipeline and timelines

#### Pain Points Today
- **Manual Chasing:** Has to email/call Resource Managers to find out availability
- **No Standard Process:** Every resource request is different — no structured format
- **Status Blindness:** No visibility into when requests will be fulfilled
- **Late Discovery:** Often discovers required skill isn't available only after project starts
- **Project Delays:** Resource constraints discovered late cause project timeline slips

#### Influence Level: **MEDIUM** | Interest Level: **HIGH**
- **End User** — daily system interaction for demand requests
- **Success Beneficiary** — directly benefits from faster resource allocation
- **Adoption Driver** — word-of-mouth influence on other Solution Owners

---

## Secondary Stakeholders (Phase 1 Out-of-Scope)

### 4. Employee (Individual Contributor)
**Role in System:** Future self-service portal user  
**Current Phase:** Out of scope for Phase 1

#### Future Needs (Phase 2+)
- Self-service profile editing (skills, certifications, preferences)
- Visibility into own allocation schedule and upcoming assignments
- Ability to update bench status and availability
- Career path planning based on skill gaps

#### Current Pain Points
- No self-serve access to update profile information
- Limited visibility into own allocation pipeline
- Manual process to update skills and certifications

#### Influence Level: **LOW** | Interest Level: **MEDIUM**
- **Future User** — will benefit from self-service capabilities in later phases
- **Data Source** — provides profile information that powers the system

---

### 5. IT/Security Team
**Role in System:** Technical governance and security oversight  

#### What They Need
- Security compliance validation (authentication, data protection)
- Integration pathway from pilot to production systems
- Data governance and access control verification
- Backup and disaster recovery planning

#### Influence Level: **MEDIUM** | Interest Level: **LOW**
- **Gatekeeper** — controls production deployment approval
- **Compliance Authority** — ensures security and governance standards

---

### 6. HR/People Operations
**Role in System:** Data source and policy governance

#### What They Need
- Integration with HRMS/Workday for employee master data
- Privacy compliance for employee information
- Alignment with broader people operations processes

#### Influence Level: **LOW** | Interest Level: **LOW**
- **Data Provider** — source of employee master data
- **Policy Owner** — controls employee data usage policies

---

## Stakeholder Influence vs Interest Grid

```
                    HIGH INTEREST
                         │
    MANAGE CLOSELY       │       KEEP SATISFIED
    ┌─────────────────────┼─────────────────────┐
    │                    │                     │
    │ • Resource Manager │ • Operations Manager│
    │   (Meera)          │   (Raj)             │
    │                    │                     │
HIGH│ Primary user       │ Executive sponsor   │LOW
INFLUENCE ┼──────────────────────┼─────────────────────┤INFLUENCE
    │                    │                     │
    │ • Solution Owner   │ • Employees         │
    │   (Anita)          │ • IT/Security       │
    │                    │                     │
    └─────────────────────┼─────────────────────┘
     KEEP INFORMED       │      MONITOR
                    LOW INTEREST
```

### Stakeholder Management Strategy

#### **Manage Closely (High Influence, High Interest)**
- **Resource Manager (Meera):** Primary system owner, requires deep involvement in design, training, and change management
- **Strategy:** Weekly check-ins, prototype reviews, early access to system, comprehensive training

#### **Keep Satisfied (High Influence, Medium Interest)**
- **Operations Manager (Raj):** Executive sponsor, needs regular updates but less operational detail
- **Strategy:** Executive briefings, dashboard previews, success metrics reporting

#### **Keep Informed (Medium Influence, High Interest)**
- **Solution Owner (Anita):** Key end user, high adoption importance but limited decision-making power
- **Strategy:** User workshops, demo sessions, feedback collection, early user training

#### **Monitor (Low Influence, Low Interest)**
- **Employees:** Future users, minimal current involvement but important for Phase 2 planning
- **IT/Security:** Governance role, periodic security reviews
- **Strategy:** Periodic updates, compliance checkpoints, future planning discussions

---

## Key Stakeholder Dependencies

### Critical Success Path
1. **Resource Manager** must adopt system for allocation management
2. **Operations Manager** must validate dashboard provides needed insights
3. **Solution Owner** must prefer new demand process over email/calls

### Risk Mitigation
- **Resource Manager resistance:** Extensive training, gradual transition, demonstrate time savings
- **Operations Manager skepticism:** Prove dashboard accuracy, show real-time capabilities
- **Solution Owner adoption:** Make demand process simpler than current email method

---

## Communication Plan

| Stakeholder | Frequency | Format | Content |
|---|---|---|---|
| Resource Manager | Weekly | Working session | Design review, feature testing, process alignment |
| Operations Manager | Bi-weekly | Executive brief | Progress update, demo, success metrics |
| Solution Owner | Weekly | User workshop | Feature demo, feedback collection, training |
| IT/Security | Monthly | Technical review | Security compliance, integration planning |

---

## Success Metrics by Stakeholder

### Resource Manager (Meera)
- **Efficiency:** Allocation time reduced from 30min → 5min per assignment
- **Accuracy:** Over-allocation incidents reduced by 90%
- **Satisfaction:** Single source of truth eliminates spreadsheet maintenance

### Operations Manager (Raj)
- **Visibility:** Real-time bench metrics vs. weekly email updates
- **Planning:** 30/60/90 day roll-off visibility enables proactive hiring
- **Risk Management:** Over-allocation alerts prevent delivery escalations

### Solution Owner (Anita)
- **Speed:** Demand fulfillment time reduced from 3-5 days → 1 day
- **Transparency:** Real-time status tracking vs. email chasing
- **Success Rate:** Skills availability check reduces failed resource matches

---

*Document owner: Architect | Status: APPROVED | Stakeholder validation: Pending Phase 2 user interviews*