# User Personas — Resource 360
## TEG AI Adoption Pilot | Phase 1 Deliverable 01

---

## Persona 1: Resource Manager

**Name:** Meera Gupta
**Role in System:** RESOURCE_MANAGER
**Job Title:** Resource Manager, TEG Engineering Practice

### Context
Meera manages 40–60 employee profiles across the engineering practice. She owns the allocation spreadsheet today — updating it manually whenever a project starts, ends, or changes. She spends significant time each week fielding requests from Solution Owners asking "who's available?"

### Goals
- Single place to view all employee profiles, skills, and current allocations
- Ability to quickly see who is on bench and match them to incoming demand
- Confidence that allocations are not double-counted or conflicting
- Faster fulfilment of demand requests without email chasing

### Pain Points
- Spreadsheet goes stale within hours of an update
- No way to search by skill — has to scroll manually
- Regularly discovers over-allocation after a project has already started
- No visibility of upcoming roll-offs until the last week

### System Access (Full)
- Create, edit, delete employee profiles
- Manage allocations (create, update, close)
- View all dashboards: bench, roll-offs, over-allocation, demand
- Review AI candidate suggestions and confirm or dismiss
- View and fulfil demand requests

---

## Persona 2: Operations Manager

**Name:** Raj Kumar
**Role in System:** OPERATIONS_MANAGER
**Job Title:** Head of Delivery Operations, TEG

### Context
Raj is responsible for bench health and delivery capacity across the entire practice. He needs a real-time view to answer questions like "how many people are on bench?", "are we at risk of over-allocation on Project Alpha?", "what skills are going to roll off in the next 30 days?"

### Goals
- Real-time dashboard showing bench count, bench skills, and days on bench
- Early warning on upcoming roll-offs — 30, 60, 90 day view
- Visibility into over-allocation risks before they become delivery problems
- Understanding of open demand versus available supply

### Pain Points
- Currently relies on weekly status emails from Resource Managers
- Finds out about over-allocation after escalations from project managers
- No aggregated view of skill availability across the practice
- Cannot anticipate bench gaps for incoming demand pipeline

### System Access (Read-heavy)
- View all dashboards (bench, roll-offs, over-allocation, demand)
- View employee profiles (read-only)
- Cannot create or modify allocations
- Cannot raise demand requests

---

## Persona 3: Solution Owner

**Name:** Anita Pillai
**Role in System:** SOLUTION_OWNER
**Job Title:** Solution Owner, Project Gamma

### Context
Anita owns the delivery of a client project and is responsible for resourcing her team. She currently spends time chasing Resource Managers to find out who is available and when. She has no visibility into the bench — she doesn't know who to ask for or whether her requested skills even exist in the practice.

### Goals
- Self-serve view of broadly what skills are available (without full employee details)
- Simple way to raise a structured resource request
- Status tracking of her demand request — is it pending, fulfilled, or declined?
- Faster resource fulfilment so projects can start on time

### Pain Points
- Has to email/call Resource Managers to find out availability
- No standard format for raising a resource request — every time is different
- No visibility into when her request will be fulfilled
- Often discovers the skill she needs isn't available only after the project starts

### System Access (Limited)
- Raise demand requests (structured form)
- View status of own demand requests only
- View high-level skill availability (not individual employee profiles)
- Cannot view bench dashboard or detailed employee data

---

*Document owner: Architect | Status: APPROVED*
