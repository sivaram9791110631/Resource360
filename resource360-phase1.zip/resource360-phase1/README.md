# Resource 360 — Employee Allocation Platform
## TEG AI Adoption Pilot · Phase 1 Delivery Package

---

## What Is This?

This repository is the **Phase 1 (Discovery & Definition) delivery package** for the Resource 360 use case in the TEG AI Adoption Pilot Program.

It contains:
- All Phase 1 documentation (problem statement, scope, personas, workflows, architecture, schema, API spec, wireframes, Gherkin)
- AI governance setup (CLAUDE.md, settings.json, custom slash commands)
- Delivery artifacts (sign-off checklist, AI usage log, productionisation considerations)

**No application code is in this package** — code is Phase 2.

---

## How to Open This in VS Code

```bash
# 1. Unzip the package
unzip resource360-phase1.zip
cd resource360-phase1

# 2. Open in VS Code
code .
```

**Recommended VS Code extensions:**
- `yzhang.markdown-all-in-one` — Markdown preview
- `redhat.vscode-yaml` — OpenAPI spec preview
- `alexkrechik.cucumberautocomplete` — Gherkin syntax highlighting
- `ms-azuretools.vscode-docker` — Docker Compose support (for Phase 2)

---

## Repository Structure

```
resource360-phase1/
│
├── CLAUDE.md                    ← AI governance. Read this first.
├── README.md                    ← This file
├── .env.example                 ← Required environment variables for Phase 2
│
├── .claude/
│   ├── settings.json            ← AI permissions and hooks
│   └── commands/
│       ├── review-scope.md      ← /review-scope — check if task is in scope
│       ├── generate-feature.md  ← /generate-feature — create Gherkin from story
│       └── ai-boundary-check.md ← /ai-boundary-check — log AI vs human work
│
├── docs/
│   ├── requirements/
│   │   ├── problem-statement.md     ← Deliverable 01a
│   │   ├── scope.md                 ← Deliverable 01b (in-scope / out-of-scope)
│   │   ├── user-personas.md         ← Deliverable 01c
│   │   └── user-workflows.md        ← Deliverable 01d
│   │
│   ├── architecture/
│   │   ├── architecture.md          ← Deliverable 02a (system design + ADRs)
│   │   ├── schema.md                ← Deliverable 02b (ER diagram + SQL DDL)
│   │   └── api-spec.yaml            ← Deliverable 02c (OpenAPI 3.0 spec)
│   │
│   └── wireframes/
│       ├── wireframe.md             ← Deliverable 02d (screen inventory + specs)
│       └── resource360-wireframe.html  ← Interactive wireframe (open in browser)
│
├── features/                    ← Gherkin acceptance criteria
│   ├── employee-profile.feature
│   ├── allocation-management.feature
│   ├── rbac-enforcement.feature
│   ├── bench-dashboard.feature
│   ├── rolloff-tracker.feature
│   ├── demand-request.feature
│   └── ai-suggestions.feature
│
└── delivery/
    ├── phase1-signoff.md            ← Architect must complete and sign before Phase 2
    ├── ai-usage-log.md              ← Running AI touchpoint log
    ├── productionisation-considerations.md  ← Deliverable 05
    └── future-roadmap.md            ← Beyond Phase 1
```

---

## Phase 1 Deliverables Summary

| # | Deliverable | Location | Status |
|---|---|---|---|
| 01 | Problem Statement + User Workflow + Approach | `docs/requirements/` | DRAFT |
| 02 | Prototype / Wireframe & Architecture | `docs/wireframes/`, `docs/architecture/` | DRAFT |
| 03 | Working Solution | Phase 2 — not in this package | — |
| 04 | UAT Results & Release Artifacts | Phase 3 — not in this package | — |
| 05 | Productionisation Considerations | `delivery/productionisation-considerations.md` | DRAFT |
| 06 | AI Usage Summary & Learnings | `delivery/ai-usage-log.md` | IN PROGRESS |

---

## Before Phase 2 Starts

1. Architect reviews and approves all docs in `docs/requirements/` and `docs/architecture/`
2. Gherkin files in `features/` reviewed for completeness and unambiguity
3. `delivery/phase1-signoff.md` completed and signed
4. `CLAUDE.md` finalized — this governs all AI-assisted build work in Phase 2

---

## AI Governance Quick Reference

| Can AI do this automatically? | Answer |
|---|---|
| Generate code from approved architecture | ✅ Yes |
| Run pytest after every Python change | ✅ Yes (hook) |
| Add a new dependency | ❌ No — architect approval |
| Drop a database table | ❌ Never |
| Expand scope beyond scope.md | ❌ Never |
| Push to main branch | ❌ Never |
| Expose employee PII in logs | ❌ Never |

Full rules: `CLAUDE.md`

---

## For Other Teams Using This Template

This package is the **standard Phase 1 format** for all TEG AI-DLC engagements.

To adapt for your use case:
1. Copy this folder structure
2. Replace `Resource 360` references with your use case name
3. Update `CLAUDE.md` Section 1 (Project Identity) and Section 7 (Approved Dependencies)
4. Update `docs/requirements/scope.md` with your in-scope features
5. Update `docs/architecture/schema.md` with your data model
6. Update `features/` with your Gherkin acceptance criteria
7. Keep all other governance files unchanged — they are standard across all use cases

---

*TEG AI Adoption Pilot Program · AI-DLC Standard Delivery Format · Phase 1*
