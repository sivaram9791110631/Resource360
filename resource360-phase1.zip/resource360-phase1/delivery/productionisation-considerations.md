# Productionisation Considerations — Resource 360
## TEG AI Adoption Pilot | Phase 1 Deliverable 05

> This document clearly separates what is **demo-ready now** from what must be matured before
> this solution can go to production. Every team delivering under the AI-DLC must produce this
> document as part of Phase 1.

---

## What Is Demo-Ready (Phase 1 Pilot)

| Feature | Demo Status | Notes |
|---|---|---|
| Employee 360° profile (CRUD) | ✅ Demo-ready | Seed data only — no real PII |
| Skill and certification management | ✅ Demo-ready | Free-text skill tags |
| Allocation management with over-allocation prevention | ✅ Demo-ready | Core business rule enforced |
| Bench status transitions | ✅ Demo-ready | ALLOCATED / BENCH / ROLLING_OFF |
| RBAC — three roles enforced at API + UI | ✅ Demo-ready | JWT-based, hardcoded pilot users |
| Bench dashboard | ✅ Demo-ready | Filter by skill and grade |
| Roll-off tracker (30/60/90 day) | ✅ Demo-ready | Date-based query |
| Over-allocation alerts panel | ✅ Demo-ready | Sum > 100% detection |
| Open demand panel | ✅ Demo-ready | All unfulfilled requests |
| Demand request workflow (raise → fulfil → decline) | ✅ Demo-ready | Full end-to-end flow |
| AI candidate suggestions (Claude API) | ✅ Demo-ready | Match score + readiness summary |
| Skill gap analysis | ✅ Demo-ready | Required vs available skills |
| Local Docker Compose deployment | ✅ Demo-ready | Single machine, no cloud |

---

## What Must Be Done Before Production

### 1. Authentication & Identity
| Gap | Required for Production | Effort |
|---|---|---|
| SSO / Azure AD / Okta integration | Replace JWT pilot auth with enterprise SSO | High |
| MFA enforcement | Required for any workforce data system | Medium |
| Session management (refresh tokens, expiry) | Current JWT has no refresh mechanism | Medium |
| Audit log of authentication events | Login / logout / failed attempts | Medium |

### 2. Database
| Gap | Required for Production | Effort |
|---|---|---|
| Migrate from SQLite to PostgreSQL | SQLite is single-file; not suitable for concurrent users | Low (schema is compatible) |
| Connection pooling | PgBouncer or SQLAlchemy pool config | Low |
| Database backups | Automated daily backups with restore testing | Medium |
| Migration tooling | Alembic configured for production migrations | Low |
| Data encryption at rest | PII fields (email, name) encrypted in DB | High |

### 3. Security
| Gap | Required for Production | Effort |
|---|---|---|
| PII data handling policy | GDPR/PDPA compliance review for employee data | High |
| Data residency | Where is employee data stored? Must match org policy | Medium |
| API rate limiting | No rate limiting on pilot API | Low |
| Input sanitisation audit | SQL injection, XSS review | Medium |
| HTTPS / TLS termination | HTTP only in pilot Docker setup | Low |
| Security pen test | Required before any production deployment | High |

### 4. Infrastructure & Deployment
| Gap | Required for Production | Effort |
|---|---|---|
| Cloud deployment (AWS/Azure/GCP) | Docker Compose is local-only | Medium |
| IaC (Terraform / Bicep) | Manual Docker setup not repeatable at scale | Medium |
| CI/CD pipeline | No automated deployment pipeline | Medium |
| Environment separation (dev/staging/prod) | Single local environment in pilot | Medium |
| Health checks and monitoring | No observability in pilot | Medium |
| Centralised logging (CloudWatch / Datadog) | Console logs only in pilot | Medium |
| Auto-scaling | Fixed Docker resources | High |

### 5. Features Not Built (Pilot Exclusions)
| Feature | Why Excluded from Pilot | Production Priority |
|---|---|---|
| Email notifications | SMTP/SES not configured | P1 — critical for demand workflow |
| HRMS / Workday / SAP integration | Complex API integration | P1 — source of truth for employee data |
| Employee self-service portal | Out of pilot scope | P2 |
| Multi-tenancy | Single-org pilot only | P2 |
| File uploads (CVs, certificates) | Local filesystem not scalable | P2 |
| Advanced skill taxonomy | Free-text only in pilot | P2 |
| BI reporting / data export | Out of pilot scope | P3 |
| Mobile app | Web only | P3 |

### 6. AI Feature Maturity
| Gap | Required for Production | Effort |
|---|---|---|
| Claude API rate limit handling | No retry/fallback in pilot | Low |
| AI suggestion caching | Every request calls Claude API — no caching | Medium |
| AI response quality monitoring | No evaluation of suggestion quality over time | Medium |
| Human-in-the-loop audit trail | AI suggestion confirmed/dismissed must be logged | Medium |
| Prompt version control | Prompts hardcoded — no versioning | Low |
| Fallback when AI is unavailable | No graceful degradation | Medium |

### 7. Non-Functional Requirements
| NFR | Pilot Status | Production Target |
|---|---|---|
| Availability | N/A (local) | 99.9% uptime SLA |
| Response time | No SLA | Dashboard < 2s, AI suggestions < 5s |
| Concurrent users | 1 (demo only) | 200+ concurrent |
| Data volume | 20 seed employees | 10,000+ employees |
| WCAG accessibility | Not tested | WCAG 2.1 AA |
| Browser support | Chrome only tested | Chrome, Firefox, Safari, Edge |

---

## Recommended Production Readiness Roadmap

```
Phase 1 (Pilot)     → Demo-ready on local Docker
Phase 2 (MVP)       → PostgreSQL + SSO + email notifications + HRMS sync
Phase 3 (Production)→ Cloud deployment + IaC + monitoring + security audit
Phase 4 (Scale)     → Multi-tenancy + mobile + advanced analytics
```

---

*Document owner: Architect | Status: DRAFT — updated at each phase*
*This document must be reviewed and signed off before any production deployment.*
