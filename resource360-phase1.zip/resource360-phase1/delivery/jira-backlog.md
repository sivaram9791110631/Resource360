# Resource 360 — Jira Backlog
## TEG AI Adoption Pilot | Phase 1 Product Backlog

---

## Backlog Summary

| Epic | Story Count | Total Story Points |
|------|-------------|-------------------|
| Employee Profile Management | 6 | 20 |
| Allocation Management | 5 | 18 |
| Role-Based Access Control | 4 | 13 |
| Dashboards | 6 | 21 |
| Demand Request Workflow | 5 | 18 |
| AI-Powered Candidate Suggestions | 4 | 15 |
| **TOTAL** | **30** | **105** |

**Sprint Capacity:** ~21 story points per week (3 hours/day × 5 days × 1.4 velocity)
**Estimated Duration:** 5 weeks (105 ÷ 21)

---

## Epic 1: Employee Profile Management

### Story ID: R360-001
**Epic:** Employee Profile Management  
**Title:** As a Resource Manager, I want to create employee profiles with basic information so that I have a central record of all team members

**Priority:** Must Have  
**Story Points:** 3

**Acceptance Criteria:**
```gherkin
Scenario: Resource Manager creates a new employee profile
  When I POST to "/employees" with:
    | name       | Sneha Krishnan        |
    | email      | sneha.k@teg.com       |
    | grade      | Senior                |
    | department | Engineering           |
    | location   | Hyderabad             |
  Then the response status is 201
  And the response contains an "id" field
  And the employee "bench_status" is "BENCH"
```

**Definition of Done:**
- [ ] API endpoint `/employees` POST implemented and tested
- [ ] RBAC enforced (only RESOURCE_MANAGER can create)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Input validation prevents duplicate emails
- [ ] Audit logging for profile creation

---

### Story ID: R360-002
**Epic:** Employee Profile Management  
**Title:** As a Resource Manager, I want to add skills to employee profiles with proficiency levels so that I can track team capabilities

**Priority:** Must Have  
**Story Points:** 2

**Acceptance Criteria:**
```gherkin
Scenario: Resource Manager adds a skill to an employee
  Given an employee with id 1 exists
  When I POST to "/employees/1/skills" with:
    | skill_name  | React     |
    | proficiency | Expert    |
  Then the response status is 201
  And the employee profile at "/employees/1" contains skill "React" with proficiency "Expert"
```

**Definition of Done:**
- [ ] API endpoint `/employees/{id}/skills` POST implemented and tested
- [ ] RBAC enforced (only RESOURCE_MANAGER can add skills)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Skill proficiency enum validation (Beginner/Proficient/Expert)
- [ ] Duplicate skill prevention

---

### Story ID: R360-003
**Epic:** Employee Profile Management  
**Title:** As a Resource Manager, I want to add certifications to employee profiles with expiry tracking so that I can ensure compliance requirements

**Priority:** Should Have  
**Story Points:** 3

**Acceptance Criteria:**
```gherkin
Scenario: Resource Manager adds a certification to an employee
  Given an employee with id 1 exists
  When I POST to "/employees/1/certifications" with:
    | cert_name  | AWS Solutions Architect |
    | expires_on | 2026-12-31              |
    | status     | Active                  |
  Then the response status is 201
  And the employee profile shows certification "AWS Solutions Architect" as "Active"
```

**Definition of Done:**
- [ ] API endpoint `/employees/{id}/certifications` POST implemented and tested
- [ ] RBAC enforced (only RESOURCE_MANAGER can add certifications)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Expiry date validation and status calculation
- [ ] Certification status enum validation (Active/Expiring/Expired)

---

### Story ID: R360-004
**Epic:** Employee Profile Management  
**Title:** As a Resource Manager, I want to view a complete 360° employee profile so that I can see all information in one place

**Priority:** Must Have  
**Story Points:** 5

**Acceptance Criteria:**
```gherkin
Scenario: Resource Manager views a full employee 360 profile
  Given employee "Arun Kumar" exists with 2 active allocations and 3 skills
  When I GET "/employees/1"
  Then the response status is 200
  And the response contains "allocations" with 2 items
  And the response contains "skills" with 3 items
  And the response contains "certifications"
  And the response contains "bench_status"
```

**Definition of Done:**
- [ ] API endpoint `/employees/{id}` GET implemented and tested
- [ ] RBAC enforced (all roles can view with different field access)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Data aggregation for allocations, skills, certifications
- [ ] Limited view for Solution Owners (PII restrictions)

---

### Story ID: R360-005
**Epic:** Employee Profile Management  
**Title:** As a Resource Manager, I want to soft-delete employee records so that I can remove inactive employees without losing historical data

**Priority:** Must Have  
**Story Points:** 3

**Acceptance Criteria:**
```gherkin
Scenario: Resource Manager soft-deletes an employee
  Given an employee with id 5 exists with no active allocations
  When I DELETE "/employees/5"
  Then the response status is 204
  And a GET to "/employees/5" returns 404
  And the database record has "is_deleted" = true (not hard deleted)
```

**Definition of Done:**
- [ ] API endpoint `/employees/{id}` DELETE implemented and tested
- [ ] RBAC enforced (only RESOURCE_MANAGER can delete)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Soft-delete implementation (is_deleted flag)
- [ ] Prevention of deleting employees with active allocations

---

### Story ID: R360-006
**Epic:** Employee Profile Management  
**Title:** As a Resource Manager, I want email uniqueness validation so that I cannot create duplicate employee records

**Priority:** Must Have  
**Story Points:** 4

**Acceptance Criteria:**
```gherkin
Scenario: Creating an employee with a duplicate email is rejected
  Given an employee with email "sneha.k@teg.com" already exists
  When I POST to "/employees" with email "sneha.k@teg.com"
  Then the response status is 422
  And the error code is "DUPLICATE_EMAIL"
```

**Definition of Done:**
- [ ] API endpoint validation for duplicate emails implemented and tested
- [ ] RBAC enforced (only RESOURCE_MANAGER can create)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Proper error handling and user feedback
- [ ] Database constraint enforcement

---

## Epic 2: Allocation Management

### Story ID: R360-007
**Epic:** Allocation Management  
**Title:** As a Resource Manager, I want to allocate employees to projects with percentage-based assignments so that I can track capacity accurately

**Priority:** Must Have  
**Story Points:** 5

**Acceptance Criteria:**
```gherkin
Scenario: Resource Manager allocates an employee at 100%
  Given employee "Sneha Krishnan" has no active allocations
  When I POST to "/allocations" with:
    | employee_id    | 1           |
    | project_id     | 10          |
    | project_role   | Senior Dev  |
    | allocation_pct | 100         |
    | start_date     | 2026-06-01  |
    | end_date       | 2026-09-01  |
  Then the response status is 201
  And employee "Sneha Krishnan" has bench_status "ALLOCATED"
```

**Definition of Done:**
- [ ] API endpoint `/allocations` POST implemented and tested
- [ ] RBAC enforced (only RESOURCE_MANAGER can create)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Bench status auto-update logic
- [ ] Foreign key validation for employee and project

---

### Story ID: R360-008
**Epic:** Allocation Management  
**Title:** As a Resource Manager, I want to create partial allocations so that I can assign employees to multiple projects

**Priority:** Must Have  
**Story Points:** 3

**Acceptance Criteria:**
```gherkin
Scenario: Resource Manager creates a partial allocation (60%)
  Given employee "Sneha Krishnan" has no active allocations
  When I POST to "/allocations" with allocation_pct 60 for project 10
  Then the response status is 201
  And the employee total active allocation is 60

Scenario: Resource Manager adds a second partial allocation totalling 100%
  Given employee "Sneha Krishnan" has an active allocation of 60% on project 10
  When I POST to "/allocations" with allocation_pct 40 for project 11
  Then the response status is 201
  And the employee total active allocation is 100
```

**Definition of Done:**
- [ ] API endpoint supports partial allocations
- [ ] RBAC enforced (only RESOURCE_MANAGER can create)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Total allocation calculation logic
- [ ] Multi-project allocation validation

---

### Story ID: R360-009
**Epic:** Allocation Management  
**Title:** As a Resource Manager, I want the system to prevent over-allocation so that no employee is assigned more than 100% capacity

**Priority:** Must Have  
**Story Points:** 5

**Acceptance Criteria:**
```gherkin
Scenario: System blocks allocation that would exceed 100%
  Given employee "Arun Kumar" has active allocations totalling 75%
  When I POST to "/allocations" with allocation_pct 30 for project 12
  Then the response status is 422
  And the error code is "OVER_ALLOCATION"
  And the error message contains "would exceed 100% allocation"
  And no allocation record is created
```

**Definition of Done:**
- [ ] API endpoint validation prevents over-allocation
- [ ] RBAC enforced (only RESOURCE_MANAGER can create)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Real-time allocation percentage calculation
- [ ] Proper error handling and user feedback

---

### Story ID: R360-010
**Epic:** Allocation Management  
**Title:** As a Resource Manager, I want to update allocation end dates so that I can manage roll-offs

**Priority:** Must Have  
**Story Points:** 3

**Acceptance Criteria:**
```gherkin
Scenario: Resource Manager updates an allocation end date (roll-off)
  Given allocation with id 1 exists and is active
  When I PATCH "/allocations/1" with end_date "2026-07-15"
  Then the response status is 200
  And the allocation end_date is "2026-07-15"
```

**Definition of Done:**
- [ ] API endpoint `/allocations/{id}` PATCH implemented and tested
- [ ] RBAC enforced (only RESOURCE_MANAGER can update)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Date validation logic
- [ ] Bench status update when allocation ends

---

### Story ID: R360-011
**Epic:** Allocation Management  
**Title:** As a Resource Manager, I want to close allocations so that I can move employees back to bench

**Priority:** Must Have  
**Story Points:** 2

**Acceptance Criteria:**
```gherkin
Scenario: Resource Manager closes an allocation
  Given allocation with id 1 exists and is active
  When I PATCH "/allocations/1" with is_active false
  Then the response status is 200
  And the employee's bench_status updates to "BENCH" if no other active allocations exist
```

**Definition of Done:**
- [ ] API endpoint supports allocation closure
- [ ] RBAC enforced (only RESOURCE_MANAGER can update)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Automatic bench status calculation
- [ ] Audit trail for allocation changes

---

## Epic 3: Role-Based Access Control

### Story ID: R360-012
**Epic:** Role-Based Access Control  
**Title:** As the system, I want to enforce JWT authentication on all endpoints so that only authenticated users can access the system

**Priority:** Must Have  
**Story Points:** 3

**Acceptance Criteria:**
```gherkin
Scenario: Unauthenticated request is rejected
  Given no authentication token is provided
  When I GET "/employees"
  Then the response status is 401
  And the error code is "UNAUTHORIZED"
```

**Definition of Done:**
- [ ] JWT middleware implemented and tested on all endpoints
- [ ] Authentication required for all protected routes
- [ ] pytest passing with >80% coverage
- [ ] React authentication context implemented
- [ ] Token validation and error handling
- [ ] Logout functionality

---

### Story ID: R360-013
**Epic:** Role-Based Access Control  
**Title:** As the system, I want to validate JWT tokens and reject expired/invalid tokens so that security is maintained

**Priority:** Must Have  
**Story Points:** 3

**Acceptance Criteria:**
```gherkin
Scenario: Expired JWT token is rejected
  Given an expired JWT token
  When I GET "/employees"
  Then the response status is 401
  And the error code is "TOKEN_EXPIRED"

Scenario: JWT with invalid signature is rejected
  Given a JWT with tampered signature
  When I GET "/employees"
  Then the response status is 401
```

**Definition of Done:**
- [ ] JWT validation middleware implemented and tested
- [ ] Token expiration handling
- [ ] pytest passing with >80% coverage
- [ ] React token refresh logic
- [ ] Signature validation
- [ ] Proper error responses

---

### Story ID: R360-014
**Epic:** Role-Based Access Control  
**Title:** As the system, I want to enforce role-based permissions on all endpoints so that users can only access features appropriate to their role

**Priority:** Must Have  
**Story Points:** 5

**Acceptance Criteria:**
```gherkin
Scenario Outline: Each role can access only their permitted endpoints
  Given I am authenticated as a <role>
  When I <method> "<endpoint>"
  Then the response status is <expected_status>

  Examples:
    | role               | method | endpoint             | expected_status |
    | RESOURCE_MANAGER   | POST   | /employees           | 201             |
    | OPERATIONS_MANAGER | POST   | /employees           | 403             |
    | SOLUTION_OWNER     | POST   | /employees           | 403             |
```

**Definition of Done:**
- [ ] RBAC middleware implemented and tested on all endpoints
- [ ] Role permission matrix enforced
- [ ] pytest passing with >80% coverage
- [ ] React RoleGuard component implemented
- [ ] Comprehensive permission testing
- [ ] 403 error handling

---

### Story ID: R360-015
**Epic:** Role-Based Access Control  
**Title:** As a user, I want the React frontend to show/hide UI elements based on my role so that I only see features I can use

**Priority:** Must Have  
**Story Points:** 2

**Acceptance Criteria:**
```gherkin
# Derived from wireframe requirements
Given I am logged in as a SOLUTION_OWNER
When I view the main navigation
Then I should NOT see "Employee Management" options
And I should see "Demand Requests" options
And dashboard sections are hidden appropriately
```

**Definition of Done:**
- [ ] RoleGuard React component implemented and tested
- [ ] UI elements conditionally rendered based on role
- [ ] Frontend tests passing
- [ ] Component built to wireframe specs
- [ ] Navigation menu role-based filtering
- [ ] Accessibility compliance maintained

---

## Epic 4: Dashboards

### Story ID: R360-016
**Epic:** Dashboards  
**Title:** As an Operations Manager, I want a real-time metrics dashboard so that I can monitor bench health at a glance

**Priority:** Must Have  
**Story Points:** 3

**Acceptance Criteria:**
```gherkin
Scenario: Dashboard shows correct bench count
  When I GET "/dashboard/metrics"
  Then the response status is 200
  And the response field "bench_count" equals 14
  And the response field "rolling_off_30d" is a number
  And the response field "over_allocated_count" equals 4
  And the response field "open_demand_count" is a number
```

**Definition of Done:**
- [ ] API endpoint `/dashboard/metrics` implemented and tested
- [ ] RBAC enforced (RESOURCE_MANAGER and OPERATIONS_MANAGER only)
- [ ] pytest passing with >80% coverage
- [ ] React dashboard component built to wireframe specs
- [ ] Real-time data aggregation
- [ ] Performance optimized queries

---

### Story ID: R360-017
**Epic:** Dashboards  
**Title:** As a Resource Manager, I want a bench view showing all available employees so that I can see who is available for allocation

**Priority:** Must Have  
**Story Points:** 4

**Acceptance Criteria:**
```gherkin
Scenario: Bench view returns employees with BENCH status
  When I GET "/dashboard/bench"
  Then the response status is 200
  And all returned employees have bench_status "BENCH" or "ROLLING_OFF"
  And each employee record contains: id, name, grade, skills, bench_since, location, bench_status
```

**Definition of Done:**
- [ ] API endpoint `/dashboard/bench` implemented and tested
- [ ] RBAC enforced (RESOURCE_MANAGER and OPERATIONS_MANAGER only)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Bench duration calculation
- [ ] Employee data aggregation with skills

---

### Story ID: R360-018
**Epic:** Dashboards  
**Title:** As a Resource Manager, I want to filter the bench view by skills so that I can find employees with specific capabilities

**Priority:** Should Have  
**Story Points:** 2

**Acceptance Criteria:**
```gherkin
Scenario: Bench view can be filtered by skill
  When I GET "/dashboard/bench?skill=React"
  Then the response status is 200
  And all returned employees have at least one skill matching "React"
```

**Definition of Done:**
- [ ] API endpoint supports skill filtering
- [ ] RBAC enforced (RESOURCE_MANAGER and OPERATIONS_MANAGER only)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Skill-based search functionality
- [ ] Performance optimized filtering

---

### Story ID: R360-019
**Epic:** Dashboards  
**Title:** As an Operations Manager, I want an over-allocation panel so that I can identify and resolve capacity issues

**Priority:** Must Have  
**Story Points:** 3

**Acceptance Criteria:**
```gherkin
Scenario: Over-allocation panel returns employees with total > 100%
  When I GET "/dashboard/over-allocations"
  Then the response status is 200
  And all returned employees have total_allocation_pct greater than 100
  And each record contains: employee_id, name, total_allocation_pct, allocations list
```

**Definition of Done:**
- [ ] API endpoint `/dashboard/over-allocations` implemented and tested
- [ ] RBAC enforced (RESOURCE_MANAGER and OPERATIONS_MANAGER only)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Real-time allocation percentage calculation
- [ ] Warning indicators and action buttons

---

### Story ID: R360-020
**Epic:** Dashboards  
**Title:** As an Operations Manager, I want a roll-off tracker with 30/60/90 day views so that I can plan for upcoming capacity gaps

**Priority:** Must Have  
**Story Points:** 5

**Acceptance Criteria:**
```gherkin
Scenario: Roll-off tracker returns employees ending within 30 days
  When I GET "/dashboard/rolloffs?days=30"
  Then the response status is 200
  And all returned employees have an allocation ending within 30 days
  And each record contains: employee_name, project_name, end_date, days_remaining
```

**Definition of Done:**
- [ ] API endpoint `/dashboard/rolloffs` implemented and tested
- [ ] RBAC enforced (RESOURCE_MANAGER and OPERATIONS_MANAGER only)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Time window filtering (30/60/90 days)
- [ ] Days remaining calculation

---

### Story ID: R360-021
**Epic:** Dashboards  
**Title:** As an Operations Manager, I want dashboard data to exclude employees without end dates so that I see only actionable roll-offs

**Priority:** Should Have  
**Story Points:** 4

**Acceptance Criteria:**
```gherkin
Scenario: Employees with no end date (ongoing) are excluded from roll-off tracker
  Given employee 5 has an active allocation with no end_date
  When I GET "/dashboard/rolloffs?days=30"
  Then employee 5 is NOT in the response
```

**Definition of Done:**
- [ ] API endpoint filters null end_date allocations
- [ ] RBAC enforced (RESOURCE_MANAGER and OPERATIONS_MANAGER only)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Null date handling logic
- [ ] Clear data filtering rules

---

## Epic 5: Demand Request Workflow

### Story ID: R360-022
**Epic:** Demand Request Workflow  
**Title:** As a Solution Owner, I want to submit structured resource requests so that I can get staffing without chasing Resource Managers

**Priority:** Must Have  
**Story Points:** 4

**Acceptance Criteria:**
```gherkin
Scenario: Solution Owner raises a new demand request
  Given I am authenticated as a SOLUTION_OWNER
  When I POST to "/demand-requests" with:
    | project_name    | Project Alpha           |
    | required_role   | Senior React Developer  |
    | required_skills | ["React","TypeScript"]  |
    | start_date      | 2026-06-01              |
    | allocation_pct  | 100                     |
    | grade_required  | Senior                  |
    | priority        | Urgent                  |
  Then the response status is 201
  And the demand request status is "OPEN"
```

**Definition of Done:**
- [ ] API endpoint `/demand-requests` POST implemented and tested
- [ ] RBAC enforced (only SOLUTION_OWNER can create)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] JSON skills array validation
- [ ] Priority and grade enum validation

---

### Story ID: R360-023
**Epic:** Demand Request Workflow  
**Title:** As a Solution Owner, I want to view only my own demand requests so that I can track the status of my resource requests

**Priority:** Must Have  
**Story Points:** 3

**Acceptance Criteria:**
```gherkin
Scenario: Solution Owner can only view their own demand requests
  Given I am authenticated as a SOLUTION_OWNER with user_id 3
  And demand request 1 was raised by user_id 3
  And demand request 2 was raised by user_id 4
  When I GET "/demand-requests"
  Then the response status is 200
  And the response contains demand request 1
  And the response does NOT contain demand request 2
```

**Definition of Done:**
- [ ] API endpoint `/demand-requests` GET implemented and tested
- [ ] RBAC enforced (scoped by user for SOLUTION_OWNER)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Data scoping by authenticated user
- [ ] Status tracking UI

---

### Story ID: R360-024
**Epic:** Demand Request Workflow  
**Title:** As a Resource Manager, I want to fulfill demand requests by assigning employees so that Solution Owners get the resources they need

**Priority:** Must Have  
**Story Points:** 5

**Acceptance Criteria:**
```gherkin
Scenario: Resource Manager fulfils a demand request
  Given I am authenticated as a RESOURCE_MANAGER
  And demand request 1 is in status "OPEN" requiring 100% React developer
  And employee "Sneha Krishnan" is on bench with React skill
  When I POST to "/demand-requests/1/fulfil" with employee_id 1
  Then the response status is 200
  And demand request 1 status is "FULFILLED"
  And an allocation is created for employee 1 on the requested project
  And employee 1 bench_status changes to "ALLOCATED"
```

**Definition of Done:**
- [ ] API endpoint `/demand-requests/{id}/fulfil` POST implemented and tested
- [ ] RBAC enforced (only RESOURCE_MANAGER can fulfill)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Automatic allocation creation
- [ ] Bench status update automation

---

### Story ID: R360-025
**Epic:** Demand Request Workflow  
**Title:** As a Resource Manager, I want to decline demand requests with reasons so that Solution Owners understand why their request cannot be fulfilled

**Priority:** Must Have  
**Story Points:** 3

**Acceptance Criteria:**
```gherkin
Scenario: Resource Manager declines a demand request with reason
  Given I am authenticated as a RESOURCE_MANAGER
  And demand request 2 is in status "OPEN"
  When I POST to "/demand-requests/2/decline" with:
    | reason | No available candidates with required skills in next 30 days |
  Then the response status is 200
  And demand request 2 status is "DECLINED"
  And the decline_reason is recorded
```

**Definition of Done:**
- [ ] API endpoint `/demand-requests/{id}/decline` POST implemented and tested
- [ ] RBAC enforced (only RESOURCE_MANAGER can decline)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Decline reason capture and storage
- [ ] Status change workflow

---

### Story ID: R360-026
**Epic:** Demand Request Workflow  
**Title:** As the system, I want to validate demand request data so that invalid requests are rejected with clear error messages

**Priority:** Must Have  
**Story Points:** 3

**Acceptance Criteria:**
```gherkin
Scenario: Demand request with invalid allocation_pct is rejected
  Given I am authenticated as a SOLUTION_OWNER
  When I POST to "/demand-requests" with allocation_pct 150
  Then the response status is 422
  And the error field is "allocation_pct"

Scenario: Fulfilling a demand that is already FULFILLED is rejected
  Given demand request 1 is in status "FULFILLED"
  When I POST to "/demand-requests/1/fulfil" with employee_id 2
  Then the response status is 409
  And the error code is "DEMAND_ALREADY_FULFILLED"
```

**Definition of Done:**
- [ ] Input validation on all demand request endpoints
- [ ] RBAC enforced on all endpoints
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Comprehensive error handling
- [ ] State validation for workflow transitions

---

## Epic 6: AI-Powered Candidate Suggestions

### Story ID: R360-027
**Epic:** AI-Powered Candidate Suggestions  
**Title:** As a Resource Manager, I want AI-ranked candidate suggestions for open demand requests so that I can quickly identify the best available employees

**Priority:** Must Have  
**Story Points:** 5

**Acceptance Criteria:**
```gherkin
Scenario: AI returns ranked candidates for an open demand
  When I GET "/ai/suggestions/1"
  Then the response status is 200
  And the response is a list of candidates
  And each candidate contains: employee_id, employee_name, match_score, matched_skills, missing_skills, availability
  And candidates are ordered by match_score descending
  And the top candidate has the highest match_score
```

**Definition of Done:**
- [ ] API endpoint `/ai/suggestions/{demand_id}` implemented and tested
- [ ] RBAC enforced (only RESOURCE_MANAGER can access)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Claude API integration with candidate ranking
- [ ] Skill matching algorithm

---

### Story ID: R360-028
**Epic:** AI-Powered Candidate Suggestions  
**Title:** As a Resource Manager, I want AI-generated readiness summaries for specific candidates so that I can understand their fit for a role

**Priority:** Should Have  
**Story Points:** 3

**Acceptance Criteria:**
```gherkin
Scenario: AI readiness summary is generated for a specific candidate
  Given employee 1 has skills React, TypeScript, Node.js and is available
  When I GET "/ai/readiness/1/1"
  Then the response status is 200
  And the response contains a "summary" field with a non-empty string
  And the response contains "match_score" between 0 and 100
  And the response contains "skill_gaps" as a list
```

**Definition of Done:**
- [ ] API endpoint `/ai/readiness/{employee_id}/{demand_id}` implemented and tested
- [ ] RBAC enforced (only RESOURCE_MANAGER can access)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Claude API integration for natural language summaries
- [ ] Skill gap analysis logic

---

### Story ID: R360-029
**Epic:** AI-Powered Candidate Suggestions  
**Title:** As a Resource Manager, I want skill gap analysis to show which required skills are missing from the current bench so that I can plan recruitment

**Priority:** Should Have  
**Story Points:** 4

**Acceptance Criteria:**
```gherkin
Scenario: Skill gap analysis identifies missing skills
  Given demand request 1 requires ["React", "TypeScript", "GraphQL"]
  And no bench employee has GraphQL skill
  When I GET "/ai/suggestions/1"
  Then in the skill gap analysis, "GraphQL" is marked as unavailable
```

**Definition of Done:**
- [ ] Skill gap analysis integrated into AI suggestions endpoint
- [ ] RBAC enforced (only RESOURCE_MANAGER can access)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Bench-wide skill inventory analysis
- [ ] Missing skill identification algorithm

---

### Story ID: R360-030
**Epic:** AI-Powered Candidate Suggestions  
**Title:** As the system, I want to handle edge cases in AI suggestions so that the feature works reliably even when no matches are available

**Priority:** Must Have  
**Story Points:** 3

**Acceptance Criteria:**
```gherkin
Scenario: AI suggestion for a demand with no bench matches returns empty list
  Given all employees are at 100% allocation
  When I GET "/ai/suggestions/1"
  Then the response status is 200
  And the response is an empty list

Scenario: Requesting suggestions for a non-existent demand returns 404
  When I GET "/ai/suggestions/9999"
  Then the response status is 404

Scenario: Requesting suggestions for a FULFILLED demand returns 404
  Given demand request 2 is in status "FULFILLED"
  When I GET "/ai/suggestions/2"
  Then the response status is 404
  And the error code is "DEMAND_NOT_OPEN"
```

**Definition of Done:**
- [ ] Comprehensive error handling for AI endpoints
- [ ] RBAC enforced (only RESOURCE_MANAGER can access)
- [ ] pytest passing with >80% coverage
- [ ] React component built to wireframe specs
- [ ] Edge case handling (no candidates, invalid demands)
- [ ] Graceful degradation when Claude API unavailable

---

## Prioritization Notes

### Must Have (Sprint 1-3)
- All basic CRUD operations for employees, allocations, demand requests
- Core RBAC enforcement
- Essential dashboards (bench view, over-allocation alerts)
- Basic AI suggestions

### Should Have (Sprint 4-5)
- Advanced filtering and search
- AI readiness summaries
- Certification management
- Roll-off planning features

### Could Have (Future)
- Advanced skill gap analysis
- Historical reporting
- Performance optimizations
- Enhanced AI features

---

## Sprint Planning Recommendations

**Sprint 1 (21 points):** R360-001, R360-002, R360-004, R360-007, R360-012, R360-016  
**Sprint 2 (21 points):** R360-013, R360-014, R360-017, R360-022, R360-024  
**Sprint 3 (21 points):** R360-008, R360-009, R360-023, R360-025, R360-027  
**Sprint 4 (21 points):** R360-010, R360-019, R360-020, R360-026, R360-028  
**Sprint 5 (21 points):** R360-003, R360-005, R360-006, R360-011, R360-015, R360-018, R360-021, R360-029, R360-030

---

*Document owner: Architect | Total stories: 30 | Total points: 105 | Generated from .feature files and scope.md*