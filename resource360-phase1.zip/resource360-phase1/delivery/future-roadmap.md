# Future Roadmap — Resource 360
## Beyond Phase 1 Pilot

---

## Phase 2 — MVP (Post-Pilot)
**Target:** 6–8 weeks after pilot sign-off

- Email notifications (demand raised, fulfilled, roll-off alerts)
- SSO integration (Azure AD / Okta)
- PostgreSQL migration
- HRMS data sync (read-only employee import from Workday/SAP)
- CI/CD pipeline (GitHub Actions)
- Cloud deployment (AWS/Azure)
- Employee self-service portal (view own profile, certifications, allocation)

## Phase 3 — Production
**Target:** 3–4 months

- Multi-tenancy (multiple organisations with data isolation)
- Advanced skill taxonomy and ontology
- BI reporting and analytics dashboard
- Mobile-responsive design (progressive web app)
- Full audit trail and compliance logging
- Security pen test and GDPR/PDPA compliance sign-off

## Phase 4 — Scale
**Target:** 6–12 months

- Native mobile app (iOS / Android)
- AI-powered proactive bench utilisation recommendations
- Integration with project management tools (Jira, MS Project)
- Automated resource forecasting based on pipeline
- Learning and development module (upskilling path recommendations)

---

*Roadmap owner: Architect | Updated at each phase review*
