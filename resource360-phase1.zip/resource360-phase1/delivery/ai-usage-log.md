# AI Usage Log — Resource 360
## TEG AI Adoption Pilot | Phase 1 Running Record

> **Purpose:** Track every AI touchpoint, prompt used, outcome, and estimated time saving.
> This becomes Deliverable 06 (AI Usage Summary & Learnings) at project end.
> Update this file at the end of every working session using `/ai-boundary-check`.

---

## How to Use This Log

At the end of each session, run `/ai-boundary-check` in Claude Code.
It will prompt you to record:
- What AI generated autonomously
- What required architect judgement
- Time saved vs manual effort
- Key prompts worth keeping in the Prompt Library

---

## Session Log

### Day 1 — Phase 1 Discovery Setup
**Date:** 2026-05-20
**Session duration:** 3 hours
**Phase:** Phase 1 — Discovery & Definition

#### AI Did (Autonomous)
- Generated `CLAUDE.md` governance document from architect's verbal brief
- Generated `.claude/settings.json` with permissions and hooks
- Generated 3 custom slash commands (`/review-scope`, `/generate-feature`, `/ai-boundary-check`)
- Generated `problem-statement.md` from problem description
- Generated `scope.md` with in-scope / out-of-scope lists
- Generated `user-personas.md` — 3 personas
- Generated `user-workflows.md` — 3 role workflows + E2E cross-role flow
- Generated `architecture.md` with system diagram and ADRs
- Generated `schema.md` with ER diagram and full SQL DDL
- Generated `api-spec.yaml` — complete OpenAPI 3.0 spec (all endpoints)
- Generated `employee-profile.feature`, `allocation-management.feature`, `demand-request.feature`
- Generated `productionisation-considerations.md`
- Generated `wireframe.md`

#### Architect Decided (Human Judgement)
- Confirmed SQLite for pilot (not PostgreSQL) — cost/complexity trade-off
- Decided no SSO for pilot — JWT only
- Confirmed three-role RBAC model — rejected idea of a fourth "Admin" role
- Approved the allocation_pct ≤ 100 rule as a hard application-level constraint (not DB trigger)
- Defined soft-delete only policy for employee records
- Decided AI suggestions are advisory only — RM must confirm manually
- Signed off scope boundary: no email notifications, no HRMS integration, no multi-tenancy

#### Quality Gates
- Files reviewed by architect: all Phase 1 docs ✅
- No code generated yet (Phase 1 is documentation only)

#### Time Estimate
- Estimated time without AI: ~20 hours (problem statement, personas, workflows, schema, API spec, Gherkin)
- Actual time with AI: ~3 hours
- **Estimated saving: ~17 hours**

#### Key Prompts (Reusable — see Prompt Library)
```
1. "Create a CLAUDE.md for this project. Stack: FastAPI + React + SQLite + Claude API.
   Governance: always scope DB queries by employee_id, never expose PII in logs,
   run pytest after every backend change. Set permissions in .claude/settings.json —
   allow pytest, npm test, docker-compose, but never drop database tables."

2. "Convert the user workflows into Gherkin feature files for [module].
   Every scenario must have a RBAC negative test.
   Use exact field names from CLAUDE.md Section 5."

3. "Design the data model for Resource 360. Propose all entities,
   key attributes, relationships, and constraints.
   Wait for architect approval before proceeding."
```

---

## Running Totals

| Phase | Sessions | Hours (AI) | Est. Hours (Manual) | Saving |
|---|---|---|---|---|
| Phase 1 — Discovery | 1 | 3h | ~20h | ~17h |
| Phase 2 — Build | — | — | — | — |
| Phase 3 — UAT | — | — | — | — |
| **Total** | **1** | **3h** | **~20h** | **~17h** |

---

## Prompt Library (Growing)

> Reusable prompts from this engagement. Format for the final Prompt Library deliverable.

### GOVERNANCE
```
Create a CLAUDE.md for [project name].
Stack: [stack].
Governance: [key rules].
Set permissions in .claude/settings.json — allow [commands], deny [commands].
```

### REQUIREMENTS
```
Convert the following user workflows into Gherkin feature files.
Every scenario must include: happy path, edge case validation, and RBAC negative test.
Use exact field names from [schema reference].
```

### ARCHITECTURE
```
Plan the technical architecture for [use case] before generating any files.
Propose: data models and relationships, API endpoint structure, file layout.
Wait for architect review and approval before writing anything.
```

### AI FEATURE
```
Given this demand request: [JSON].
Given these bench employees: [JSON array of employees with skills and availability].
Rank the employees by fit for this demand.
Return: match_score (0–100), matched_skills, missing_skills, and a 2-sentence readiness summary.
Respond in JSON only.
```

---

*Updated by: Architect after each session | Format: append, never delete*
