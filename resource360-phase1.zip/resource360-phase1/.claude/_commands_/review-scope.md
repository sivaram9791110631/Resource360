# /review-scope — Check if a task is within Phase 1 scope

Read `docs/requirements/scope.md` and `CLAUDE.md` Section 8.

Then evaluate the following task against the in-scope list:

"$ARGUMENTS"

Respond with:
1. ✅ IN SCOPE or ❌ OUT OF SCOPE
2. Which in-scope item it maps to (or which out-of-scope item it violates)
3. If out of scope: suggest the minimum scoped alternative that IS within bounds
4. If in scope: confirm which Gherkin feature file covers this requirement

Do not generate any code. This is a scope validation only.
