# /ai-boundary-check — Classify what AI did vs what architect decided

For the work completed in this session, produce a structured summary:

## AI Did (Autonomous Execution)
List every file generated, code written, or test produced by Claude Code in this session.

## Architect Decided (Human Judgement Required)
List every decision that required architect input:
- Scope trade-offs
- Architecture choices
- RBAC rules
- Data model constraints
- Anything outside CLAUDE.md Section 2 (What AI Can Do)

## Quality Gates Passed
List automated checks that ran and their results (pytest, lint, type-check).

## Quality Gates Requiring Human Review
List anything that AI cannot validate — UX correctness, business logic edge cases, security review.

## Time Estimate
- Estimated time to produce this output without AI: [X hours]
- Actual time with AI assistance: [Y hours]
- Estimated saving: [Z hours]

## Prompts Used This Session
List the key prompts that produced the most value. These go into `delivery/ai-usage-log.md`.

Format as markdown. Append to `delivery/ai-usage-log.md`.
