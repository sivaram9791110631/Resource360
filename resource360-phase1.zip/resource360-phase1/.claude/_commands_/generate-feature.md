# /generate-feature — Generate a Gherkin feature file from a user story

Given this user story:
"$ARGUMENTS"

Generate a complete Gherkin `.feature` file following this structure:

```
Feature: [Feature name]
  As a [role from: Resource Manager | Operations Manager | Solution Owner]
  I want to [goal]
  So that [business value]

  Background:
    Given the system has seed data loaded
    And I am authenticated as [role]

  Scenario: [Happy path]
    Given ...
    When ...
    Then ...

  Scenario: [Edge case / validation]
    Given ...
    When ...
    Then ...

  Scenario: [RBAC — negative test]
    Given I am authenticated as [wrong role]
    When ...
    Then the system returns a 403 Forbidden response
```

Rules:
- Every scenario must have a RBAC negative test
- Use exact field names from CLAUDE.md Section 5
- Every `Then` must be verifiable by an automated test
- Reference the relevant API endpoint from `docs/architecture/api-spec.yaml`

Save the file to `features/[feature-name].feature`
