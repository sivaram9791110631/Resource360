# /generate-tests [feature-name]
# Usage: /generate-tests employee
# Usage: /generate-tests allocation
# Usage: /generate-tests demand
# Usage: /generate-tests ai-suggestions
# Usage: /generate-tests rbac
# Usage: /generate-tests all   ← generates tests for all features
#
# What it does: Reads the Gherkin .feature file and generates
# executable pytest-bdd step definitions. Every Given/When/Then
# becomes a test function. Every test links back to its Jira story.

---

Read these files:
- features/$ARGUMENTS.feature  (or all files in features/ if "all")
- backend/tests/conftest.py    (if it exists)
- docs/architecture/schema.md
- docs/architecture/api-spec.yaml
- CLAUDE.md

Generate pytest-bdd step definitions for every scenario
in features/$ARGUMENTS.feature

## Rules for every test file

### File naming
Save to: backend/tests/test_$ARGUMENTS.py

### Docstring format — every test must have this
```python
def test_resource_manager_creates_employee():
    """
    Jira: R360-[story number]
    Gherkin: features/employee-profile.feature
    Scenario: Resource Manager creates a new employee profile
    """
```

### Fixture usage
Use fixtures from backend/tests/conftest.py:
- test_db — in-memory SQLite session
- seed_data — pre-loaded test data
- rm_token — JWT for RESOURCE_MANAGER role
- om_token — JWT for OPERATIONS_MANAGER role
- so_token — JWT for SOLUTION_OWNER role
- test_client — FastAPI TestClient

### Every scenario needs 3 tests
1. Happy path — the scenario passes as expected
2. Validation — edge case or boundary condition
3. RBAC negative — wrong role gets 403

### Test structure
```python
# Given
response = client.post("/employees", ...)

# When
assert response.status_code == 201

# Then
data = response.json()
assert data["bench_status"] == "BENCH"
```

## After generating
Run: cd backend && pytest tests/test_$ARGUMENTS.py -v

Fix all failures before stopping.
Report: X passed, 0 failed.
