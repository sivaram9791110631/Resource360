# /standup
# Usage: /standup
#
# What it does: Reviews what was built today, what tests passed,
# what is next, and updates the AI usage log.
# Run at the END of each working day.

---

Read these files:
- delivery/ai-usage-log.md
- CLAUDE.md

Review everything done in this session.

Produce a standup report in this format:

## Today — [Day number and feature built]

### Files generated
List every file created or modified in this session
with the file path.

### Tests status
- pytest: X passed / Y failed
- tsc: X errors / 0 errors

### What AI did autonomously
List every file generated, every test written,
every bug fixed without architect input.

### What architect decided
List every decision that required human judgement:
- Architecture choices made
- Business rule clarifications
- Scope decisions
- Anything Claude asked and architect answered

### Time saved
- Estimated time to do this manually: X hours
- Actual time with Claude Code: Y hours
- Saving: Z hours

### Blockers
Anything that could not be completed and why.

### Tomorrow
What is the next step (next /plan-service or /plan-component call).

---
Append this report to delivery/ai-usage-log.md under today's date.
