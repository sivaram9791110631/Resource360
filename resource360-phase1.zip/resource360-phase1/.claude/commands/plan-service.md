# /plan-service [feature-name]
# Usage: /plan-service employee
# Usage: /plan-service allocation
# Usage: /plan-service demand
# Usage: /plan-service ai
#
# What it does: Reads Phase 1 docs and presents an implementation
# plan for a backend service BEFORE writing any code.
# Architect must approve the plan before running /build-service.

---

Read these files before doing anything:
- CLAUDE.md
- docs/architecture/schema.md
- docs/architecture/api-spec.yaml
- docs/requirements/scope.md
- features/$ARGUMENTS.feature

You are planning the **$ARGUMENTS** backend service.

Present your implementation plan in this exact format:

## Files I will create
List every file path you will create. Example:
- backend/models/$ARGUMENTS.py
- backend/schemas/$ARGUMENTS.py
- backend/services/$ARGUMENTS_service.py
- backend/routers/$ARGUMENTS.py
- backend/tests/test_$ARGUMENTS.py

## What each file contains
For every file, list:
- Every function / class name
- What it does in one sentence
- Which Gherkin scenario from features/$ARGUMENTS.feature it satisfies

## CLAUDE.md rules applied
List which CLAUDE.md rules are relevant to this feature.
Example: soft-delete only, no PII in logs, scoped DB queries.

## Business rules
List every business rule this feature must enforce.
Example: allocation_pct sum must never exceed 100.

## RBAC
Which roles can call each endpoint.
Reference CLAUDE.md Section 6 exactly.

## Test plan
List every pytest test function you will write.
Map each test to a Gherkin scenario.

---
DO NOT write any code.
DO NOT create any files.
Wait for the architect to type: Approved. Run /build-service $ARGUMENTS
