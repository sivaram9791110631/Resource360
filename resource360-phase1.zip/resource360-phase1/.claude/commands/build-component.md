# /build-component [component-name]
# Usage: /build-component Employee360
# Usage: /build-component BenchDashboard
# Usage: /build-component RolloffCalendar
# Usage: /build-component OpenDemand
# Usage: /build-component DemandForm
# Usage: /build-component AISuggestions
#
# IMPORTANT: Only run this AFTER /plan-component has been approved.
#
# What it does: Generates the React component, runs tsc after each
# file, fixes TypeScript errors before moving on.

---

The architect has approved the plan. Now execute it.

Read these files:
- CLAUDE.md
- docs/wireframes/wireframe.md
- docs/architecture/api-spec.yaml

Generate the **$ARGUMENTS** React component following these rules:

## CLAUDE.md rules — mandatory on every file
- Strict TypeScript — no "any" types anywhere
- All components must be functional with fully typed props
- Use React Query for all API calls — no raw fetch in components
- RBAC via RoleGuard component — every protected element wrapped
- Every interactive element must have aria-label for accessibility
- Use Tailwind CSS utility classes only — no inline style objects
- Use exact API endpoint paths from docs/architecture/api-spec.yaml
- Match the wireframe exactly — screen reference from wireframe.md

## File generation order
Generate files in this order. After EACH file:
1. Run: cd frontend && npx tsc --noEmit to check types
2. Fix any TypeScript errors before moving to the next file

Order:
1. frontend/src/types/[related].ts     — if new types needed
2. frontend/src/api/[related].ts       — React Query hooks
3. frontend/src/components/[path]/$ARGUMENTS.tsx — the component
4. frontend/src/pages/[related]Page.tsx — page that uses it (if needed)

## After all files are generated
Run: cd frontend && npx tsc --noEmit

If any TypeScript errors appear:
- Read the error message and line number
- Fix the source file
- Re-run tsc
- Repeat until 0 errors

Report the final tsc output when done.

## Visual check reminder
After building, the architect will visually compare the
component against wireframe screen in docs/wireframes/wireframe.md.
Make sure every panel, button, badge, and filter from that
screen description is present in the component.
