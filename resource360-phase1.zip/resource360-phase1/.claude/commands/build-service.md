# /build-service [feature-name]
# Usage: /build-service employee
# Usage: /build-service allocation
# Usage: /build-service demand
# Usage: /build-service ai
#
# IMPORTANT: Only run this AFTER /plan-service has been approved
# by the architect. Never run this cold.
#
# What it does: Generates all backend files for a service,
# runs pytest after each file, fixes failures before moving on.

---

The architect has approved the plan. Now execute it.

Read these files:
- CLAUDE.md
- docs/architecture/schema.md
- docs/architecture/api-spec.yaml
- features/$ARGUMENTS.feature

Generate the **$ARGUMENTS** backend service following these rules:

## CLAUDE.md rules — mandatory on every file
- Use exact table and column names from docs/architecture/schema.md
- Use exact endpoint paths from docs/architecture/api-spec.yaml
- All functions must have Python type hints
- All API endpoints must have docstrings
- Never log: email, phone, name, or any PII field
- Soft delete only — never hard delete employees or projects
- All DB queries must be scoped — never SELECT * without a WHERE clause
- Error responses must follow: {"error": "...", "code": "...", "field": null}
- Use Pydantic v2 for all request/response schemas
- RBAC enforced on every endpoint via JWT middleware

## File generation order
Generate files in this order. After EACH file:
1. Run: black [filename] to format
2. Run: cd backend && python -m py_compile [filename] to check syntax
3. Fix any errors before moving to the next file

Order:
1. backend/models/$ARGUMENTS.py        — SQLAlchemy models
2. backend/schemas/$ARGUMENTS.py       — Pydantic v2 schemas
3. backend/services/$ARGUMENTS_service.py — Business logic
4. backend/routers/$ARGUMENTS.py       — FastAPI router
5. backend/tests/test_$ARGUMENTS.py    — pytest tests

## After all files are generated
Run: cd backend && pytest tests/test_$ARGUMENTS.py -v

If any test fails:
- Read the failure message
- Fix the source file
- Re-run pytest
- Repeat until ALL tests pass

Do not stop until pytest shows 0 failures.
Report the final pytest output when done.
