# /fix-tests [feature-name]
# Usage: /fix-tests employee
# Usage: /fix-tests allocation
# Usage: /fix-tests all
#
# What it does: Runs pytest, reads failures, fixes them.
# Loops until all tests pass. Use this when tests are failing.

---

Read CLAUDE.md first.

Run: cd backend && pytest tests/test_$ARGUMENTS.py -v 2>&1

For every FAILED test:
1. Read the full error message and stack trace
2. Identify which source file caused the failure
3. Fix ONLY the minimal change needed — do not refactor
4. Re-run that specific test: pytest tests/test_$ARGUMENTS.py::test_name -v
5. Confirm it passes before moving to the next failure

## Rules when fixing
- Do not change test files to make tests pass
- Fix the source (models/, services/, routers/) not the tests
- If a test is genuinely wrong (tests wrong behaviour), flag it
  to the architect — do not silently delete or skip tests
- Never use pytest.skip() or pytest.mark.xfail to hide failures

## When all tests pass
Run the full suite: cd backend && pytest -v
Report: X passed, 0 failed, coverage %.
