# /plan-component [component-name]
# Usage: /plan-component Employee360
# Usage: /plan-component BenchDashboard
# Usage: /plan-component RolloffCalendar
# Usage: /plan-component OpenDemand
# Usage: /plan-component DemandForm
# Usage: /plan-component AISuggestions
#
# What it does: Plans a React component BEFORE writing any code.
# Architect must approve before running /build-component.

---

Read these files before doing anything:
- CLAUDE.md
- docs/wireframes/wireframe.md
- docs/architecture/api-spec.yaml
- docs/architecture/architecture.md

You are planning the **$ARGUMENTS** React component.

Present your component plan in this exact format:

## Component details
- File path: frontend/src/components/[path]/$ARGUMENTS.tsx
- Wireframe screen it maps to (e.g. Screen S05 from wireframe.md)
- Which roles can see this component (from CLAUDE.md Section 6)
- RoleGuard: what allowedRoles prop will be set

## Props interface
Write the full TypeScript interface for this component's props.
Use types from docs/architecture/architecture.md.
No "any" types — strict TypeScript only.

## API calls
List every React Query hook this component will use.
For each hook:
- Hook name (e.g. useEmployee)
- Endpoint it calls (from api-spec.yaml)
- What data it returns

## Component structure
List every sub-component or section inside this component.
Example:
- AllocationBar — shows allocation % with colour coding
- OverAllocationWarning — red banner if total > 100%
- SkillTags — renders skill chips

## States to handle
- Loading state: what shows while API call is in progress
- Error state: what shows if API call fails
- Empty state: what shows if no data returned
- Success state: the main rendered content

## RBAC in UI
Which buttons/sections are hidden for which roles.
Use RoleGuard component from frontend/src/components/RoleGuard.tsx

---
DO NOT write any code.
DO NOT create any files.
Wait for the architect to type: Approved. Run /build-component $ARGUMENTS
