# CLAUDE.md — Resource 360 · AI Governance Constitution
# TEG AI Adoption Pilot · Phase 1 Delivery
# Last updated: 2026-05-20 | Owner: Architect

---

## 1. Project Identity

| Field | Value |
|---|---|
| Use Case | Resource 360 — Employee Allocation Platform |
| Pilot Program | TEG AI Adoption Pilot — AI-DLC |
| Phase | Phase 1: Discovery & Definition |
| Stack | FastAPI (Python 3.11) · React 18 · SQLite (pilot) · Claude API (claude-sonnet-4-20250514) |
| Architect | [Your Name] |
| Delivery Window | 2 weeks · 3 hours/day |

---

## 2. What AI Can Do in This Project

These are **approved** Claude Code actions — execute autonomously without asking:

- Generate Python models, schemas, and Pydantic validators from approved data model designs
- Scaffold FastAPI routers and endpoint stubs from the approved API spec (`docs/architecture/api-spec.yaml`)
- Generate React components and pages from approved wireframes (`docs/wireframes/`)
- Write pytest unit tests for any module after backend changes
- Write Vitest/React Testing Library tests for any React component
- Generate Gherkin `.feature` files from documented user stories
- Run `pytest`, `npm test`, `npm run lint`, `docker-compose up` — read-only DB queries
- Read any file in the repository for context
- Generate `schema.sql` migrations using `ALTER TABLE ADD COLUMN` only
- Produce documentation: README updates, inline docstrings, API docs
- Refactor code within an existing approved file structure
- Generate seed data for the pilot environment (realistic but anonymised)

---

## 3. What AI Cannot Do — Hard Stops

These actions require **explicit architect approval before execution**:

- `DROP TABLE`, `DROP DATABASE`, `DELETE FROM` without a `WHERE` clause — NEVER
- Destructive database migrations (column removal, table rename) — NEVER without approval
- Expose `employee_id`, `email`, `salary`, or any PII in application logs — NEVER
- Add new third-party dependencies not listed in Section 7 — requires architect sign-off
- Create new API endpoints outside the approved `api-spec.yaml` — plan first, get approval
- Push to `main` branch directly — all changes via pull request
- Expand the in-scope feature list beyond what is listed in `docs/requirements/scope.md`
- Modify `.claude/settings.json` permissions without architect review
- Send real emails, SMS, or external API calls in the pilot environment
- Create multi-tenancy data isolation changes without explicit data model review

---

## 4. Coding Standards (Enforced on Every File)

### Python (Backend)
- PEP 8 strictly — run `black` formatter on save
- All functions must have type hints
- All API endpoints must have docstrings describing purpose, parameters, and response
- DB queries: always scope by `employee_id` or `org_id` — no unscoped `SELECT *`
- Never log: `email`, `phone`, `salary`, certification details, or any PII field
- Use Pydantic v2 models for all request/response schemas
- Error responses must follow the standard format: `{"error": "...", "code": "...", "field": null}`

### TypeScript / React (Frontend)
- Strict TypeScript — no `any` types
- All components must be functional with typed props
- Use React Query for all API calls — no raw `fetch` in components
- RBAC check on every protected route using `RoleGuard` component
- Accessibility: every interactive element must have `aria-label` or visible label

### General
- Commit message format: `[phase][type] description` — e.g. `[p1][feat] add employee profile schema`
- No hardcoded secrets, tokens, or passwords anywhere in code
- All environment variables via `.env` (never committed)

---

## 5. Data Model Constraints

```
Employee.allocation_percentage: sum across active projects must NEVER exceed 100
Employee.bench_status: enum — ALLOCATED | BENCH | ROLLING_OFF | ON_LEAVE
Allocation.percentage: integer 1–100, required
Project.status: enum — ACTIVE | COMPLETED | CANCELLED | ON_HOLD
DemandRequest.status: enum — OPEN | PENDING | FULFILLED | DECLINED
User.role: enum — RESOURCE_MANAGER | OPERATIONS_MANAGER | SOLUTION_OWNER
```

- Foreign key integrity must be enforced at DB level via SQLite `PRAGMA foreign_keys = ON`
- Soft-delete only (`is_deleted = true`) — no hard deletes on Employee or Project records

---

## 6. RBAC Rules (Non-Negotiable)

| Action | Resource Manager | Operations Manager | Solution Owner |
|---|---|---|---|
| Create/edit employee profile | ✅ | ❌ | ❌ |
| View employee profile | ✅ | ✅ | ✅ (limited) |
| Create/edit allocation | ✅ | ❌ | ❌ |
| View bench dashboard | ✅ | ✅ | ❌ |
| View roll-off dashboard | ✅ | ✅ | ❌ |
| Raise demand request | ❌ | ❌ | ✅ |
| View demand request status | ✅ | ✅ | ✅ (own only) |
| Confirm/reject AI suggestion | ✅ | ❌ | ❌ |
| View AI candidate suggestions | ✅ | ✅ | ❌ |
| Access settings / admin | ✅ | ✅ | ❌ |

---

## 7. Approved Dependencies

### Backend
```
fastapi==0.111.0
uvicorn==0.29.0
sqlalchemy==2.0.30
pydantic==2.7.1
anthropic==0.26.0
python-jose[cryptography]==3.3.0
passlib[bcrypt]==1.7.4
pytest==8.2.0
httpx==0.27.0
python-dotenv==1.0.1
```

### Frontend
```
react@18.3.1
react-dom@18.3.1
typescript@5.4.5
@tanstack/react-query@5.40.0
react-router-dom@6.23.1
axios@1.7.2
tailwindcss@3.4.4
vitest@1.6.0
@testing-library/react@16.0.0
```

---

## 8. Pilot Scope Boundary

**ALWAYS refer to `docs/requirements/scope.md` before generating any code.**

If a task appears outside the in-scope list, STOP and ask the architect before proceeding.

---

## 9. Architecture Decisions (Locked for Phase 1)

- Authentication: JWT-based, stored in httpOnly cookie — no OAuth for pilot
- Database: SQLite for pilot only. Schema must be cloud-DB compatible (no SQLite-specific syntax)
- AI Integration: Claude API via `anthropic` SDK — model `claude-sonnet-4-20250514` — candidate ranking and readiness summaries only
- File storage: local filesystem for pilot (profile pictures out of scope)
- No real email notifications in pilot — all alerts are in-app only

---

## 10. Phase Sign-Off Checklist

Before Phase 1 is considered complete, the following must exist and be reviewed by the architect:

- [ ] `docs/requirements/problem-statement.md` — complete
- [ ] `docs/requirements/scope.md` — in-scope and out-of-scope finalised
- [ ] `docs/requirements/user-personas.md` — 3 personas documented
- [ ] `docs/requirements/user-workflows.md` — all 3 role workflows documented
- [ ] `features/` — Gherkin `.feature` files for all in-scope stories
- [ ] `docs/architecture/architecture.md` — system design documented
- [ ] `docs/architecture/schema.md` — ER diagram and table descriptions
- [ ] `docs/architecture/api-spec.yaml` — OpenAPI spec for all endpoints
- [ ] `docs/wireframes/wireframe.md` — screen descriptions and flow
- [ ] `delivery/ai-usage-log.md` — AI touchpoints recorded from Day 1
- [ ] `delivery/productionisation-considerations.md` — gaps documented
- [ ] Architecture decisions appended to this CLAUDE.md
- [ ] Architect sign-off recorded in `delivery/phase1-signoff.md`
