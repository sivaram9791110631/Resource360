Feature: Bench Dashboard
  As an Operations Manager or Resource Manager
  I want a real-time dashboard showing bench health, over-allocations, and open demand
  So that I can make proactive resourcing decisions

  Background:
    Given the system has seed data with 14 bench employees and 4 over-allocated employees
    And I am authenticated as an OPERATIONS_MANAGER

  Scenario: Dashboard shows correct bench count
    When I GET "/dashboard/metrics"
    Then the response status is 200
    And the response field "bench_count" equals 14
    And the response field "rolling_off_30d" is a number
    And the response field "over_allocated_count" equals 4
    And the response field "open_demand_count" is a number

  Scenario: Bench view returns employees with BENCH status
    When I GET "/dashboard/bench"
    Then the response status is 200
    And all returned employees have bench_status "BENCH" or "ROLLING_OFF"
    And each employee record contains: id, name, grade, skills, bench_since, location, bench_status

  Scenario: Bench view can be filtered by skill
    When I GET "/dashboard/bench?skill=React"
    Then the response status is 200
    And all returned employees have at least one skill matching "React"

  Scenario: Over-allocation panel returns employees with total > 100%
    When I GET "/dashboard/over-allocations"
    Then the response status is 200
    And all returned employees have total_allocation_pct greater than 100
    And each record contains: employee_id, name, total_allocation_pct, allocations list

  Scenario: Roll-off data returns employees grouped by time window
    When I GET "/dashboard/rolloffs?days=30"
    Then the response status is 200
    And all returned allocations have end_date within 30 days of today
    And each record contains: employee_id, name, project_name, end_date, days_remaining

  # ── RBAC ──

  Scenario: Solution Owner cannot access bench dashboard
    Given I am authenticated as a SOLUTION_OWNER
    When I GET "/dashboard/bench"
    Then the response status is 403

  Scenario: Solution Owner cannot access over-allocation panel
    Given I am authenticated as a SOLUTION_OWNER
    When I GET "/dashboard/over-allocations"
    Then the response status is 403
