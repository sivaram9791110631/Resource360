Feature: Roll-off Tracker
  As an Operations Manager or Resource Manager
  I want to see upcoming project end dates grouped by 30 / 60 / 90 day windows
  So that I can plan re-allocation before resources go unassigned

  Background:
    Given the system has seed data with employees on projects with various end dates
    And I am authenticated as an OPERATIONS_MANAGER

  Scenario: Roll-off tracker returns employees ending within 30 days
    When I GET "/dashboard/rolloffs?days=30"
    Then the response status is 200
    And all returned employees have an allocation ending within 30 days
    And each record contains: employee_name, project_name, end_date, days_remaining

  Scenario: Roll-off tracker returns employees ending between 31–60 days
    When I GET "/dashboard/rolloffs?days=60"
    Then the response status is 200
    And all returned employees have an allocation ending between 31 and 60 days from today

  Scenario: Roll-off tracker returns empty list when no roll-offs in window
    Given no active allocations end within 90 days
    When I GET "/dashboard/rolloffs?days=90"
    Then the response status is 200
    And the response is an empty list

  Scenario: Employees with no end date (ongoing) are excluded from roll-off tracker
    Given employee 5 has an active allocation with no end_date
    When I GET "/dashboard/rolloffs?days=30"
    Then employee 5 is NOT in the response

  # ── RBAC ──

  Scenario: Solution Owner cannot access roll-off tracker
    Given I am authenticated as a SOLUTION_OWNER
    When I GET "/dashboard/rolloffs?days=30"
    Then the response status is 403
