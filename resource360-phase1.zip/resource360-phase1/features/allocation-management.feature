Feature: Allocation Management
  As a Resource Manager
  I want to allocate employees to projects with percentage-based assignments
  So that I can prevent over-allocation and maintain accurate bench status

  Background:
    Given the system has seed data loaded
    And I am authenticated as a RESOURCE_MANAGER

  # ── VALID ALLOCATIONS ──

  Scenario: Resource Manager allocates an employee at 100%
    Given employee "Sneha Krishnan" has no active allocations
    When I POST to "/allocations" with:
      | employee_id    | 1           |
      | project_id     | 10          |
      | project_role   | Senior Dev  |
      | allocation_pct | 100         |
      | start_date     | 2026-06-01  |
      | end_date       | 2026-09-01  |
    Then the response status is 201
    And employee "Sneha Krishnan" has bench_status "ALLOCATED"

  Scenario: Resource Manager creates a partial allocation (60%)
    Given employee "Sneha Krishnan" has no active allocations
    When I POST to "/allocations" with allocation_pct 60 for project 10
    Then the response status is 201
    And the employee total active allocation is 60

  Scenario: Resource Manager adds a second partial allocation totalling 100%
    Given employee "Sneha Krishnan" has an active allocation of 60% on project 10
    When I POST to "/allocations" with allocation_pct 40 for project 11
    Then the response status is 201
    And the employee total active allocation is 100

  Scenario: Resource Manager updates an allocation end date (roll-off)
    Given allocation with id 1 exists and is active
    When I PATCH "/allocations/1" with end_date "2026-07-15"
    Then the response status is 200
    And the allocation end_date is "2026-07-15"

  Scenario: Resource Manager closes an allocation
    Given allocation with id 1 exists and is active
    When I PATCH "/allocations/1" with is_active false
    Then the response status is 200
    And the employee's bench_status updates to "BENCH" if no other active allocations exist

  # ── OVER-ALLOCATION PREVENTION ──

  Scenario: System blocks allocation that would exceed 100%
    Given employee "Arun Kumar" has active allocations totalling 75%
    When I POST to "/allocations" with allocation_pct 30 for project 12
    Then the response status is 422
    And the error code is "OVER_ALLOCATION"
    And the error message contains "would exceed 100% allocation"
    And no allocation record is created

  Scenario: System blocks allocation that would reach exactly 101%
    Given employee "Arun Kumar" has active allocations totalling 100%
    When I POST to "/allocations" with allocation_pct 1 for project 13
    Then the response status is 422
    And the error code is "OVER_ALLOCATION"

  Scenario: System allows allocation that reaches exactly 100%
    Given employee "Arun Kumar" has active allocations totalling 80%
    When I POST to "/allocations" with allocation_pct 20 for project 14
    Then the response status is 201
    And the employee total active allocation is 100

  # ── RBAC — NEGATIVE TESTS ──

  Scenario: Operations Manager cannot create an allocation
    Given I am authenticated as an OPERATIONS_MANAGER
    When I POST to "/allocations" with valid allocation data
    Then the response status is 403

  Scenario: Solution Owner cannot create an allocation
    Given I am authenticated as a SOLUTION_OWNER
    When I POST to "/allocations" with valid allocation data
    Then the response status is 403

  Scenario: Solution Owner cannot update an allocation
    Given I am authenticated as a SOLUTION_OWNER
    When I PATCH "/allocations/1" with end_date "2026-08-01"
    Then the response status is 403
