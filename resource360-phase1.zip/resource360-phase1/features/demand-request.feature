Feature: Demand Request Workflow
  As a Solution Owner
  I want to raise structured resource requests and track their fulfilment
  So that I can staff my project without chasing Resource Managers by email

  Background:
    Given the system has seed data loaded

  # ── SOLUTION OWNER RAISES DEMAND ──

  Scenario: Solution Owner raises a new demand request
    Given I am authenticated as a SOLUTION_OWNER
    When I POST to "/demand-requests" with:
      | project_name    | Project Alpha           |
      | required_role   | Senior React Developer  |
      | required_skills | ["React","TypeScript"]  |
      | start_date      | 2026-06-01              |
      | allocation_pct  | 100                     |
      | grade_required  | Senior                  |
      | priority        | Urgent                  |
    Then the response status is 201
    And the demand request status is "OPEN"
    And the "raised_by_user_id" matches the authenticated user id

  Scenario: Solution Owner can only view their own demand requests
    Given I am authenticated as a SOLUTION_OWNER with user_id 3
    And demand request 1 was raised by user_id 3
    And demand request 2 was raised by user_id 4
    When I GET "/demand-requests"
    Then the response status is 200
    And the response contains demand request 1
    And the response does NOT contain demand request 2

  Scenario: Solution Owner sees status transition to FULFILLED
    Given I am authenticated as a SOLUTION_OWNER
    And demand request 1 is in status "OPEN"
    When a Resource Manager fulfils demand request 1
    And I GET "/demand-requests/1"
    Then the status is "FULFILLED"
    And "fulfilled_by_employee_id" is populated

  # ── RESOURCE MANAGER FULFILS DEMAND ──

  Scenario: Resource Manager fulfils a demand request
    Given I am authenticated as a RESOURCE_MANAGER
    And demand request 1 is in status "OPEN" requiring 100% React developer
    And employee "Sneha Krishnan" is on bench with React skill
    When I POST to "/demand-requests/1/fulfil" with employee_id 1
    Then the response status is 200
    And demand request 1 status is "FULFILLED"
    And an allocation is created for employee 1 on the requested project
    And employee 1 bench_status changes to "ALLOCATED"

  Scenario: Resource Manager declines a demand request with reason
    Given I am authenticated as a RESOURCE_MANAGER
    And demand request 2 is in status "OPEN"
    When I POST to "/demand-requests/2/decline" with:
      | reason | No available candidates with required skills in next 30 days |
    Then the response status is 200
    And demand request 2 status is "DECLINED"
    And the decline_reason is recorded

  # ── VALIDATION ──

  Scenario: Demand request with invalid allocation_pct is rejected
    Given I am authenticated as a SOLUTION_OWNER
    When I POST to "/demand-requests" with allocation_pct 150
    Then the response status is 422
    And the error field is "allocation_pct"

  Scenario: Fulfilling a demand that is already FULFILLED is rejected
    Given I am authenticated as a RESOURCE_MANAGER
    And demand request 1 is in status "FULFILLED"
    When I POST to "/demand-requests/1/fulfil" with employee_id 2
    Then the response status is 409
    And the error code is "DEMAND_ALREADY_FULFILLED"

  # ── RBAC — NEGATIVE TESTS ──

  Scenario: Solution Owner cannot fulfil a demand request
    Given I am authenticated as a SOLUTION_OWNER
    When I POST to "/demand-requests/1/fulfil" with employee_id 1
    Then the response status is 403

  Scenario: Solution Owner cannot decline a demand request
    Given I am authenticated as a SOLUTION_OWNER
    When I POST to "/demand-requests/1/decline" with reason "test"
    Then the response status is 403

  Scenario: Resource Manager cannot raise a demand request
    Given I am authenticated as a RESOURCE_MANAGER
    When I POST to "/demand-requests" with valid demand data
    Then the response status is 403

  Scenario: Operations Manager cannot raise a demand request
    Given I am authenticated as an OPERATIONS_MANAGER
    When I POST to "/demand-requests" with valid demand data
    Then the response status is 403
