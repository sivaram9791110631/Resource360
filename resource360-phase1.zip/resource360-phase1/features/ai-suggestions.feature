Feature: AI Candidate Suggestions
  As a Resource Manager
  I want AI-powered candidate suggestions ranked by fit for an open demand request
  So that I can quickly identify the best available employee without manual searching

  Background:
    Given the system has seed data loaded
    And I am authenticated as a RESOURCE_MANAGER
    And demand request 1 exists with required_role "Senior React Developer"
      and required_skills ["React", "TypeScript"] and grade_required "Senior"

  Scenario: AI returns ranked candidates for an open demand
    When I GET "/ai/suggestions/1"
    Then the response status is 200
    And the response is a list of candidates
    And each candidate contains: employee_id, employee_name, match_score, matched_skills, missing_skills, availability
    And candidates are ordered by match_score descending
    And the top candidate has the highest match_score

  Scenario: AI readiness summary is generated for a specific candidate
    Given employee 1 has skills React, TypeScript, Node.js and is available
    When I GET "/ai/readiness/1/1"
    Then the response status is 200
    And the response contains a "summary" field with a non-empty string
    And the response contains "match_score" between 0 and 100
    And the response contains "skill_gaps" as a list

  Scenario: Skill gap analysis identifies missing skills
    Given demand request 1 requires ["React", "TypeScript", "GraphQL"]
    And no bench employee has GraphQL skill
    When I GET "/ai/suggestions/1"
    Then in the skill gap analysis, "GraphQL" is marked as unavailable

  Scenario: AI suggestion for a demand with no bench matches returns empty list
    Given all employees are at 100% allocation
    When I GET "/ai/suggestions/1"
    Then the response status is 200
    And the response is an empty list

  # ── RBAC — NEGATIVE TESTS ──

  Scenario: Operations Manager cannot access AI suggestions
    Given I am authenticated as an OPERATIONS_MANAGER
    When I GET "/ai/suggestions/1"
    Then the response status is 403

  Scenario: Solution Owner cannot access AI suggestions
    Given I am authenticated as a SOLUTION_OWNER
    When I GET "/ai/suggestions/1"
    Then the response status is 403

  Scenario: Requesting suggestions for a non-existent demand returns 404
    When I GET "/ai/suggestions/9999"
    Then the response status is 404

  Scenario: Requesting suggestions for a FULFILLED demand returns 404
    Given demand request 2 is in status "FULFILLED"
    When I GET "/ai/suggestions/2"
    Then the response status is 404
    And the error code is "DEMAND_NOT_OPEN"
