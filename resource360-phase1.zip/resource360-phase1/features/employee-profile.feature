Feature: Employee Profile Management
  As a Resource Manager
  I want to create and maintain employee profiles with skills and certifications
  So that I have an accurate, up-to-date 360° view of every employee

  Background:
    Given the system has seed data loaded
    And I am authenticated as a RESOURCE_MANAGER

  # ── HAPPY PATH ──

  Scenario: Resource Manager creates a new employee profile
    When I POST to "/employees" with:
      | name       | Sneha Krishnan        |
      | email      | sneha.k@teg.com       |
      | grade      | Senior                |
      | department | Engineering           |
      | location   | Hyderabad             |
    Then the response status is 201
    And the response contains an "id" field
    And the employee "bench_status" is "BENCH"

  Scenario: Resource Manager adds a skill to an employee
    Given an employee with id 1 exists
    When I POST to "/employees/1/skills" with:
      | skill_name  | React     |
      | proficiency | Expert    |
    Then the response status is 201
    And the employee profile at "/employees/1" contains skill "React" with proficiency "Expert"

  Scenario: Resource Manager adds a certification to an employee
    Given an employee with id 1 exists
    When I POST to "/employees/1/certifications" with:
      | cert_name  | AWS Solutions Architect |
      | expires_on | 2026-12-31              |
      | status     | Active                  |
    Then the response status is 201
    And the employee profile shows certification "AWS Solutions Architect" as "Active"

  Scenario: Resource Manager views a full employee 360 profile
    Given employee "Arun Kumar" exists with 2 active allocations and 3 skills
    When I GET "/employees/1"
    Then the response status is 200
    And the response contains "allocations" with 2 items
    And the response contains "skills" with 3 items
    And the response contains "certifications"
    And the response contains "bench_status"

  Scenario: Resource Manager soft-deletes an employee
    Given an employee with id 5 exists with no active allocations
    When I DELETE "/employees/5"
    Then the response status is 204
    And a GET to "/employees/5" returns 404
    And the database record has "is_deleted" = true (not hard deleted)

  # ── VALIDATION EDGE CASES ──

  Scenario: Creating an employee with a duplicate email is rejected
    Given an employee with email "sneha.k@teg.com" already exists
    When I POST to "/employees" with email "sneha.k@teg.com"
    Then the response status is 422
    And the error code is "DUPLICATE_EMAIL"

  Scenario: Removing a skill that does not exist returns 404
    Given an employee with id 1 exists
    When I DELETE "/employees/1/skills/9999"
    Then the response status is 404

  # ── RBAC — NEGATIVE TESTS ──

  Scenario: Operations Manager cannot create an employee profile
    Given I am authenticated as an OPERATIONS_MANAGER
    When I POST to "/employees" with valid employee data
    Then the response status is 403
    And the error message contains "Forbidden"

  Scenario: Solution Owner cannot create an employee profile
    Given I am authenticated as a SOLUTION_OWNER
    When I POST to "/employees" with valid employee data
    Then the response status is 403

  Scenario: Solution Owner cannot edit an employee profile
    Given I am authenticated as a SOLUTION_OWNER
    When I PATCH "/employees/1" with grade "Principal"
    Then the response status is 403

  Scenario: Solution Owner cannot delete an employee
    Given I am authenticated as a SOLUTION_OWNER
    When I DELETE "/employees/1"
    Then the response status is 403
