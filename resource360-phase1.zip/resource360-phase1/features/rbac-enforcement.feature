Feature: RBAC Enforcement
  As the system
  I want to enforce role-based access control on every API endpoint
  So that no user can access data or perform actions outside their permitted role

  Background:
    Given the system has seed data loaded

  Scenario Outline: Each role can access only their permitted endpoints
    Given I am authenticated as a <role>
    When I <method> "<endpoint>"
    Then the response status is <expected_status>

    Examples:
      | role               | method | endpoint             | expected_status |
      | RESOURCE_MANAGER   | POST   | /employees           | 201             |
      | OPERATIONS_MANAGER | POST   | /employees           | 403             |
      | SOLUTION_OWNER     | POST   | /employees           | 403             |
      | RESOURCE_MANAGER   | POST   | /allocations         | 201             |
      | OPERATIONS_MANAGER | POST   | /allocations         | 403             |
      | SOLUTION_OWNER     | POST   | /allocations         | 403             |
      | SOLUTION_OWNER     | POST   | /demand-requests     | 201             |
      | RESOURCE_MANAGER   | POST   | /demand-requests     | 403             |
      | OPERATIONS_MANAGER | POST   | /demand-requests     | 403             |
      | RESOURCE_MANAGER   | GET    | /dashboard/bench     | 200             |
      | OPERATIONS_MANAGER | GET    | /dashboard/bench     | 200             |
      | SOLUTION_OWNER     | GET    | /dashboard/bench     | 403             |
      | RESOURCE_MANAGER   | GET    | /ai/suggestions/1    | 200             |
      | OPERATIONS_MANAGER | GET    | /ai/suggestions/1    | 403             |
      | SOLUTION_OWNER     | GET    | /ai/suggestions/1    | 403             |

  Scenario: Unauthenticated request is rejected
    Given no authentication token is provided
    When I GET "/employees"
    Then the response status is 401
    And the error code is "UNAUTHORIZED"

  Scenario: Expired JWT token is rejected
    Given an expired JWT token
    When I GET "/employees"
    Then the response status is 401
    And the error code is "TOKEN_EXPIRED"

  Scenario: JWT with invalid signature is rejected
    Given a JWT with tampered signature
    When I GET "/employees"
    Then the response status is 401
