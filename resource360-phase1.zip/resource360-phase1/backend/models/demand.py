"""Demand request models for resource allocation workflow.

This module defines the DemandRequest model and related enums for managing
resource demand requests from Solution Owners to Resource Managers.
"""

import enum
import json
from datetime import datetime, date
from typing import Optional, List

from sqlalchemy import String, Integer, Text, DateTime, Date, ForeignKey, func, CheckConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from database import Base


class DemandStatus(str, enum.Enum):
    """Demand request status enum matching CLAUDE.md Section 5 constraints."""

    OPEN = "OPEN"
    PENDING = "PENDING"
    FULFILLED = "FULFILLED"
    DECLINED = "DECLINED"


class DemandPriority(str, enum.Enum):
    """Demand request priority enum matching schema constraints."""

    URGENT = "Urgent"
    HIGH = "High"
    NORMAL = "Normal"


class DemandRequest(Base):
    """Demand request model for resource allocation workflow.

    Represents requests from Solution Owners for employee resources
    with specific skill requirements. Supports AI-powered candidate
    matching and fulfillment tracking.
    """

    __tablename__ = "demand_requests"

    # Primary key
    id: Mapped[int] = mapped_column(primary_key=True)

    # Project information
    project_name: Mapped[str] = mapped_column(String(255), nullable=False)
    required_role: Mapped[str] = mapped_column(String(100), nullable=False)
    required_skills: Mapped[str] = mapped_column(Text, nullable=False)  # JSON array

    # Timing and capacity
    start_date: Mapped[date] = mapped_column(Date, nullable=False)
    duration_months: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    allocation_pct: Mapped[int] = mapped_column(
        Integer,
        CheckConstraint("allocation_pct >= 1 AND allocation_pct <= 100"),
        nullable=False
    )

    # Requirements
    grade_required: Mapped[str] = mapped_column(String(50), nullable=False)
    priority: Mapped[DemandPriority] = mapped_column(
        nullable=False,
        default=DemandPriority.NORMAL
    )

    # Status and workflow
    status: Mapped[DemandStatus] = mapped_column(
        nullable=False,
        default=DemandStatus.OPEN
    )

    # Foreign keys
    raised_by_user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id"),
        nullable=False
    )
    fulfilled_by_employee_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("employees.id"),
        nullable=True
    )

    # Additional information
    decline_reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Audit fields
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        server_default=func.now()
    )

    # Relationships
    raised_by_user: Mapped["User"] = relationship(
        "User"
    )
    fulfilled_by_employee: Mapped[Optional["Employee"]] = relationship(
        "Employee",
        back_populates="demand_fulfillments"
    )

    def __repr__(self) -> str:
        """String representation."""
        return f"<DemandRequest(id={self.id}, project='{self.project_name}', role='{self.required_role}', status='{self.status}')>"

    @property
    def is_open(self) -> bool:
        """Check if demand request is open for fulfillment."""
        return self.status == DemandStatus.OPEN

    @property
    def is_pending(self) -> bool:
        """Check if demand request is pending approval."""
        return self.status == DemandStatus.PENDING

    @property
    def is_fulfilled(self) -> bool:
        """Check if demand request has been fulfilled."""
        return self.status == DemandStatus.FULFILLED

    @property
    def is_declined(self) -> bool:
        """Check if demand request has been declined."""
        return self.status == DemandStatus.DECLINED

    @property
    def is_urgent(self) -> bool:
        """Check if demand request has urgent priority."""
        return self.priority == DemandPriority.URGENT

    @property
    def is_high_priority(self) -> bool:
        """Check if demand request has high priority."""
        return self.priority == DemandPriority.HIGH

    def get_required_skills(self) -> List[str]:
        """Parse required skills from JSON string to list.

        Returns:
            List of required skill names.

        Raises:
            ValueError: If required_skills is not valid JSON.
        """
        try:
            return json.loads(self.required_skills)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in required_skills: {e}")

    def set_required_skills(self, skills: List[str]) -> None:
        """Set required skills from list to JSON string.

        Args:
            skills: List of skill names.
        """
        self.required_skills = json.dumps(skills)

    def fulfill_with_employee(self, employee_id: int) -> None:
        """Fulfill demand request with specific employee.

        Args:
            employee_id: ID of employee fulfilling the demand.

        Raises:
            ValueError: If demand is not in OPEN status.
        """
        if not self.is_open:
            raise ValueError(f"Cannot fulfill demand in {self.status} status")

        self.status = DemandStatus.FULFILLED
        self.fulfilled_by_employee_id = employee_id

    def decline_with_reason(self, reason: str) -> None:
        """Decline demand request with reason.

        Args:
            reason: Reason for declining the demand request.

        Raises:
            ValueError: If demand is not in OPEN status.
        """
        if not self.is_open:
            raise ValueError(f"Cannot decline demand in {self.status} status")

        self.status = DemandStatus.DECLINED
        self.decline_reason = reason

    def set_pending(self) -> None:
        """Set demand request to pending status.

        Raises:
            ValueError: If demand is not in OPEN status.
        """
        if not self.is_open:
            raise ValueError(f"Cannot set demand to pending from {self.status} status")

        self.status = DemandStatus.PENDING

    def reopen(self) -> None:
        """Reopen demand request (reset to OPEN status).

        Can be called from PENDING or DECLINED status.

        Raises:
            ValueError: If demand is already FULFILLED.
        """
        if self.is_fulfilled:
            raise ValueError("Cannot reopen fulfilled demand request")

        self.status = DemandStatus.OPEN
        self.fulfilled_by_employee_id = None
        self.decline_reason = None

    def days_until_start(self) -> int:
        """Calculate days until start date.

        Returns:
            Number of days until start date. Negative if start date has passed.
        """
        from datetime import date
        today = date.today()
        return (self.start_date - today).days

    def is_starting_soon(self, days_threshold: int = 14) -> bool:
        """Check if demand request is starting within threshold days.

        Args:
            days_threshold: Number of days to check against (default: 14).

        Returns:
            True if starting within threshold days.
        """
        return 0 <= self.days_until_start() <= days_threshold

    def matches_skill(self, skill_name: str) -> bool:
        """Check if demand request requires a specific skill.

        Args:
            skill_name: Name of skill to check.

        Returns:
            True if skill is in required skills list.
        """
        required_skills = self.get_required_skills()
        return skill_name.lower() in [skill.lower() for skill in required_skills]