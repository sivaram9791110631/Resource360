"""Employee models and related schemas.

This module defines the Employee model and related models for skills,
certifications, and bench status tracking in Resource 360.
"""

import enum
from datetime import datetime, date
from typing import Optional, List

from sqlalchemy import String, Boolean, DateTime, Date, ForeignKey, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from database import Base


class BenchStatus(str, enum.Enum):
    """Employee bench status enum matching CLAUDE.md Section 5 constraints."""

    ALLOCATED = "ALLOCATED"
    BENCH = "BENCH"
    ROLLING_OFF = "ROLLING_OFF"
    ON_LEAVE = "ON_LEAVE"


class SkillProficiency(str, enum.Enum):
    """Skill proficiency levels enum matching schema constraints."""

    BEGINNER = "Beginner"
    PROFICIENT = "Proficient"
    EXPERT = "Expert"


class CertificationStatus(str, enum.Enum):
    """Certification status enum matching schema constraints."""

    ACTIVE = "Active"
    EXPIRING = "Expiring"
    EXPIRED = "Expired"


class Employee(Base):
    """Employee model for profile and allocation management.

    Central model representing employees with their profile information,
    skills, certifications, and allocation status. Supports soft-delete only.
    """

    __tablename__ = "employees"

    # Primary key
    id: Mapped[int] = mapped_column(primary_key=True)

    # Profile fields
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    grade: Mapped[str] = mapped_column(String(50), nullable=False)
    department: Mapped[str] = mapped_column(String(100), nullable=False)
    location: Mapped[str] = mapped_column(String(100), nullable=False)

    # Status fields
    bench_status: Mapped[BenchStatus] = mapped_column(
        nullable=False,
        default=BenchStatus.BENCH
    )

    # Soft delete field - enforced by CLAUDE.md
    is_deleted: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    # Audit fields
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        server_default=func.now()
    )

    # Relationships
    skills: Mapped[List["Skill"]] = relationship(
        "Skill",
        back_populates="employee",
        cascade="all, delete-orphan"
    )

    certifications: Mapped[List["Certification"]] = relationship(
        "Certification",
        back_populates="employee",
        cascade="all, delete-orphan"
    )

    allocations: Mapped[List["Allocation"]] = relationship(
        "Allocation",
        back_populates="employee"
    )

    demand_fulfillments: Mapped[List["DemandRequest"]] = relationship(
        "DemandRequest",
        back_populates="fulfilled_by_employee"
    )

    def __repr__(self) -> str:
        """String representation without PII (no email)."""
        return f"<Employee(id={self.id}, name='{self.name}', grade='{self.grade}', status='{self.bench_status}')>"

    @property
    def is_active(self) -> bool:
        """Check if employee is active (not soft-deleted)."""
        return not self.is_deleted

    @property
    def is_available(self) -> bool:
        """Check if employee is available for allocation."""
        return self.is_active and self.bench_status in [BenchStatus.BENCH, BenchStatus.ROLLING_OFF]

    @property
    def is_on_bench(self) -> bool:
        """Check if employee is currently on bench."""
        return self.bench_status == BenchStatus.BENCH and self.is_active

    def soft_delete(self) -> None:
        """Soft delete employee (set is_deleted=True). Hard deletes are forbidden."""
        self.is_deleted = True

    def get_active_allocations(self) -> List["Allocation"]:
        """Get list of currently active allocations."""
        return [alloc for alloc in self.allocations if alloc.is_active]

    def get_total_allocation_percentage(self) -> int:
        """Calculate total allocation percentage across active projects."""
        return sum(alloc.allocation_pct for alloc in self.get_active_allocations())

    def can_allocate(self, percentage: int) -> bool:
        """Check if employee can be allocated to a project with given percentage.

        Business rule: total allocation must not exceed 100% (CLAUDE.md Section 5).
        """
        current_total = self.get_total_allocation_percentage()
        return (current_total + percentage) <= 100

    def get_skill_names(self) -> List[str]:
        """Get list of skill names for this employee."""
        return [skill.skill_name for skill in self.skills]


class Skill(Base):
    """Employee skill model with proficiency levels.

    Represents individual skills and their proficiency levels for employees.
    Used for skill-based matching in AI candidate suggestions.
    """

    __tablename__ = "skills"

    # Primary key
    id: Mapped[int] = mapped_column(primary_key=True)

    # Foreign key
    employee_id: Mapped[int] = mapped_column(
        ForeignKey("employees.id", ondelete="CASCADE"),
        nullable=False
    )

    # Skill fields
    skill_name: Mapped[str] = mapped_column(String(100), nullable=False)
    proficiency: Mapped[SkillProficiency] = mapped_column(
        nullable=False,
        default=SkillProficiency.PROFICIENT
    )

    # Audit fields
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        server_default=func.now()
    )

    # Relationships
    employee: Mapped["Employee"] = relationship(
        "Employee",
        back_populates="skills"
    )

    def __repr__(self) -> str:
        """String representation."""
        return f"<Skill(id={self.id}, employee_id={self.employee_id}, skill='{self.skill_name}', level='{self.proficiency}')>"

    @property
    def is_expert_level(self) -> bool:
        """Check if skill is at expert proficiency level."""
        return self.proficiency == SkillProficiency.EXPERT

    @property
    def is_proficient_or_higher(self) -> bool:
        """Check if skill is at proficient or expert level."""
        return self.proficiency in [SkillProficiency.PROFICIENT, SkillProficiency.EXPERT]


class Certification(Base):
    """Employee certification model with expiry tracking.

    Represents certifications held by employees with expiry date tracking
    and status management for compliance and skill verification.
    """

    __tablename__ = "certifications"

    # Primary key
    id: Mapped[int] = mapped_column(primary_key=True)

    # Foreign key
    employee_id: Mapped[int] = mapped_column(
        ForeignKey("employees.id", ondelete="CASCADE"),
        nullable=False
    )

    # Certification fields
    cert_name: Mapped[str] = mapped_column(String(200), nullable=False)
    expires_on: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    status: Mapped[CertificationStatus] = mapped_column(
        nullable=False,
        default=CertificationStatus.ACTIVE
    )

    # Audit fields
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        server_default=func.now()
    )

    # Relationships
    employee: Mapped["Employee"] = relationship(
        "Employee",
        back_populates="certifications"
    )

    def __repr__(self) -> str:
        """String representation."""
        return f"<Certification(id={self.id}, employee_id={self.employee_id}, cert='{self.cert_name}', status='{self.status}')>"

    @property
    def is_active(self) -> bool:
        """Check if certification is currently active."""
        return self.status == CertificationStatus.ACTIVE

    @property
    def is_expiring_soon(self) -> bool:
        """Check if certification is marked as expiring soon."""
        return self.status == CertificationStatus.EXPIRING

    @property
    def has_expired(self) -> bool:
        """Check if certification has expired."""
        return self.status == CertificationStatus.EXPIRED

    def is_valid_on(self, check_date: date) -> bool:
        """Check if certification is valid on a specific date."""
        if self.status == CertificationStatus.EXPIRED:
            return False

        if self.expires_on is None:
            return True  # No expiry date means permanent

        return check_date <= self.expires_on