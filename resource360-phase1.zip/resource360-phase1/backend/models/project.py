"""Project and allocation models.

This module defines the Project and Allocation models for managing
project information and employee allocations in Resource 360.
"""

import enum
from datetime import datetime, date
from typing import Optional, List

from sqlalchemy import String, Integer, Boolean, DateTime, Date, ForeignKey, func, CheckConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from database import Base


class ProjectStatus(str, enum.Enum):
    """Project status enum matching CLAUDE.md Section 5 constraints."""

    ACTIVE = "ACTIVE"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"
    ON_HOLD = "ON_HOLD"


class Project(Base):
    """Project model for tracking client projects and engagements.

    Represents client projects that employees can be allocated to.
    Projects have lifecycles and can have multiple employee allocations.
    """

    __tablename__ = "projects"

    # Primary key
    id: Mapped[int] = mapped_column(primary_key=True)

    # Project fields
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(String(1000), nullable=True)
    status: Mapped[ProjectStatus] = mapped_column(
        nullable=False,
        default=ProjectStatus.ACTIVE
    )

    # Date fields
    start_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    end_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True)

    # Audit fields
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        server_default=func.now()
    )

    # Relationships
    allocations: Mapped[List["Allocation"]] = relationship(
        "Allocation",
        back_populates="project"
    )

    def __repr__(self) -> str:
        """String representation."""
        return f"<Project(id={self.id}, name='{self.name}', status='{self.status}')>"

    @property
    def is_active(self) -> bool:
        """Check if project is currently active."""
        return self.status == ProjectStatus.ACTIVE

    @property
    def is_completed(self) -> bool:
        """Check if project is completed."""
        return self.status == ProjectStatus.COMPLETED

    @property
    def is_cancelled(self) -> bool:
        """Check if project is cancelled."""
        return self.status == ProjectStatus.CANCELLED

    @property
    def is_on_hold(self) -> bool:
        """Check if project is on hold."""
        return self.status == ProjectStatus.ON_HOLD

    def get_active_allocations(self) -> List["Allocation"]:
        """Get list of currently active allocations for this project."""
        return [alloc for alloc in self.allocations if alloc.is_active]

    def get_total_allocated_percentage(self) -> int:
        """Get total allocation percentage across all active allocations."""
        return sum(alloc.allocation_pct for alloc in self.get_active_allocations())

    def get_allocated_employee_count(self) -> int:
        """Get count of employees currently allocated to this project."""
        return len(self.get_active_allocations())


class Allocation(Base):
    """Employee allocation model for project assignments.

    Represents the assignment of an employee to a project with specific
    allocation percentage, dates, and role. Enforces business rules
    for allocation percentage limits.
    """

    __tablename__ = "allocations"

    # Primary key
    id: Mapped[int] = mapped_column(primary_key=True)

    # Foreign keys
    employee_id: Mapped[int] = mapped_column(
        ForeignKey("employees.id"),
        nullable=False
    )
    project_id: Mapped[int] = mapped_column(
        ForeignKey("projects.id"),
        nullable=False
    )

    # Allocation fields
    project_role: Mapped[str] = mapped_column(String(100), nullable=False)
    allocation_pct: Mapped[int] = mapped_column(
        Integer,
        CheckConstraint("allocation_pct >= 1 AND allocation_pct <= 100"),
        nullable=False
    )

    # Date fields
    start_date: Mapped[date] = mapped_column(Date, nullable=False)
    end_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True)

    # Status fields
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    # Audit fields
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        server_default=func.now()
    )

    # Relationships
    employee: Mapped["Employee"] = relationship(
        "Employee",
        back_populates="allocations"
    )
    project: Mapped["Project"] = relationship(
        "Project",
        back_populates="allocations"
    )

    def __repr__(self) -> str:
        """String representation."""
        return f"<Allocation(id={self.id}, employee_id={self.employee_id}, project_id={self.project_id}, {self.allocation_pct}%)>"

    @property
    def is_current(self) -> bool:
        """Check if allocation is currently active."""
        return self.is_active

    @property
    def is_ending_soon(self) -> bool:
        """Check if allocation is ending within next 30 days."""
        if not self.end_date or not self.is_active:
            return False

        from datetime import date, timedelta
        thirty_days_from_now = date.today() + timedelta(days=30)
        return self.end_date <= thirty_days_from_now

    @property
    def days_remaining(self) -> Optional[int]:
        """Calculate days remaining until allocation ends."""
        if not self.end_date or not self.is_active:
            return None

        from datetime import date
        today = date.today()
        if self.end_date <= today:
            return 0

        return (self.end_date - today).days

    def end_allocation(self, end_date: Optional[date] = None) -> None:
        """End the allocation by setting is_active=False and optional end_date."""
        self.is_active = False
        if end_date:
            self.end_date = end_date
        elif not self.end_date:
            from datetime import date
            self.end_date = date.today()

    def extend_allocation(self, new_end_date: date) -> None:
        """Extend allocation to a new end date."""
        if not self.is_active:
            raise ValueError("Cannot extend inactive allocation")

        self.end_date = new_end_date

    def is_overlapping_with(self, other: "Allocation") -> bool:
        """Check if this allocation overlaps with another allocation."""
        if not self.is_active or not other.is_active:
            return False

        # Same employee check
        if self.employee_id != other.employee_id:
            return False

        # Date overlap check
        self_end = self.end_date or date.max
        other_end = other.end_date or date.max

        return (self.start_date <= other_end and other.start_date <= self_end)