"""User model and authentication-related schemas.

This module defines the User model and related enums for authentication
and role-based access control in Resource 360.
"""

import enum
from datetime import datetime
from typing import Optional

from sqlalchemy import String, DateTime, func
from sqlalchemy.orm import Mapped, mapped_column

from database import Base


class UserRole(str, enum.Enum):
    """User roles enum matching CLAUDE.md Section 5 constraints."""

    RESOURCE_MANAGER = "RESOURCE_MANAGER"
    OPERATIONS_MANAGER = "OPERATIONS_MANAGER"
    SOLUTION_OWNER = "SOLUTION_OWNER"


class User(Base):
    """User model for authentication and RBAC.

    Represents system users with role-based permissions.
    Contains authentication credentials and role information.
    """

    __tablename__ = "users"

    # Primary key
    id: Mapped[int] = mapped_column(primary_key=True)

    # Authentication fields
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    password: Mapped[str] = mapped_column(String(255), nullable=False)  # Hashed password

    # Profile fields
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[UserRole] = mapped_column(nullable=False)

    # Audit fields
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        server_default=func.now()
    )

    def __repr__(self) -> str:
        """String representation without PII (no email/password)."""
        return f"<User(id={self.id}, name='{self.name}', role='{self.role}')>"

    @property
    def is_resource_manager(self) -> bool:
        """Check if user has resource manager role."""
        return self.role == UserRole.RESOURCE_MANAGER

    @property
    def is_operations_manager(self) -> bool:
        """Check if user has operations manager role."""
        return self.role == UserRole.OPERATIONS_MANAGER

    @property
    def is_solution_owner(self) -> bool:
        """Check if user has solution owner role."""
        return self.role == UserRole.SOLUTION_OWNER

    def has_permission(self, required_role: UserRole) -> bool:
        """Check if user has the required role permission."""
        return self.role == required_role

    def can_manage_employees(self) -> bool:
        """Check if user can create/edit employee profiles."""
        return self.role == UserRole.RESOURCE_MANAGER

    def can_manage_allocations(self) -> bool:
        """Check if user can create/edit allocations."""
        return self.role == UserRole.RESOURCE_MANAGER

    def can_view_dashboards(self) -> bool:
        """Check if user can view operational dashboards."""
        return self.role in [UserRole.RESOURCE_MANAGER, UserRole.OPERATIONS_MANAGER]

    def can_raise_demand(self) -> bool:
        """Check if user can raise demand requests."""
        return self.role == UserRole.SOLUTION_OWNER